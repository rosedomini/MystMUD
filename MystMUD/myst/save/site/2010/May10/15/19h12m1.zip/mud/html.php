<html>
<head>
	<script language=javascript src=shortcuts.js></script>
	<script language=javascript>
		var update = function(){ el('main').innerHTML = el('html').value }
		var set_update = function(){ setTimeout(update, 50) }
		function el(id){ return document.getElementById(id) }
		shortcut.add("backspace", set_update, {'disable_in_input':false, 'propagate':true})
	</script>
	<style>
		#main {
			width:512px;
			max-width:512px;
			background-color:#786;
			padding:20px;
		}
		body {
			background-color:rgb(4,16,8);
			font-family:Verdana, Arial, Helvetica, sans-serif;
			font-size:12px;
		}
	</style>
</head>
<body>

<textarea id=html style=width:100% rows=20 onkeypress=set_update()></textarea>
<br><br>
<table cellpadding=0 cellspacing=0 style="border-collapse:collapse;border:1px solid white"><tr>
	<td><div id=main></div></td>
</tr></table>

</body>
</html>