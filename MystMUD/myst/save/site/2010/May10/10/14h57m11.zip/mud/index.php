﻿<html xmlns=http://www.w3.org/1999/xhtml xml:lang=fr>
<head>
	<title>Myst</title>
	<meta http-equiv=content-type content=text/html;charset=UTF-8> 
	<link rel=icon type=image/png href=ico/map/d/d00.png><link rel=stylesheet href=style.css>
	<script language=javascript>var serverInfo = "<?php $file = __FILE__; $file = ($file[0] == 'C') ? "C:/var/cache/cache.php" : "/m/cache/cache.php"; include($file); $srv = explode(",", get_cache("server")); if(isset($srv[TIME], $srv[ONLINE_PLAYERS]) && $srv[TIME] > time() - 20){ ?><table class=default style=width:70%><tr><td><p>Serveur de jeu <b>actif</b><br>Joueurs en ligne : <b><?php echo $srv[ONLINE_PLAYERS] ?></b></p></td><td><p>Connexion en cours...</p><?php } else { ?> <table class=default style=width:70%><tr><td><p>Serveur de jeu <b>fermé</b></p></td><td> <?php } ?></td><td><a href=index.php>Actualiser</a><br><a href=login.php>Retour</a><br></td></tr></table>", host = "<?php echo ($file[0] == 'C') ? "127.0.0.1" : "62.193.219.166"; ?>"</script>
	<script language=javascript src=swfobject.js></script>
	<script language=javascript src=shortcuts.js></script>
	<script language=javascript src=script.js></script>
</head>

<body onresize=resize() onload=load() id=window>

<div id=socket_bridge style=position:absolute></div>

<table cellpadding=0 cellspacing=0 id=body align=center><tr>
	<td rowspan=3 width=9 background=design/left.png></td>
	<td id=maintd>
		<div id=main class=default>
			<p>Chargement de l'applet flash</p>
			<p><a target=_blanck href=http://get.adobe.com/fr/flashplayer/>Télécharger Flash Player</a></p>
			<p><a href="">Réessayer</a></p>
			<a href=login.php>Déconnexion</a>
		</div>
		<hr style=margin-bottom:0px;margin-top:0px>
		<div id=console style=visibility:hidden>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			
<?php

$world = explode(",", get_cache("world"));
	
echo '<u>_Le Monde de Myst_</u><pre>
 Zones		'.$world[ZONES].'
 Objets		'.$world[ITEMS].'
 Créatures 	'.$world[MOBS].'
 Héros		'.$world[HEROES].'
 Magasins 	'.$world[SHOPS].'
 Sorts		'.$world[SPELLS].'
 Skins		'.$world[SKINS].'
 Avatars	'.$world[AVATARS].'</pre>';

?>

<pre style=font-size:12pt;font-family:monospace;color:#3E6FB1>
 __  __           _
|  \/  |_   _ ___| |_
| |\/| | | | / __| __|
| |  | | |_| \__ \ |_
|_|  |_|\__, |___/\__|
        |___/
			</pre>
				Préparez vous à incarnez votre personnage (ou futur personnage).<br><br>Entrez son nom :
		</div>
	</td>
	<td rowspan=3 width=9 background=design/right.png></td>
</tr><tr>
	<td id=vmt height=25>
		<table cellpadding=0 cellspacing=0><tr>
			<td>
				<table cellpadding=0 cellspacing=5 class=default><tr>
					<td width=5></td>
					<td width=200 style="border:1px solid black;background-color:orange">
						<img id=v src=design/barre/v.png>
					</td>
					<td width=5><div id=vm style=font-size:13px>vie&nbsp;|&nbsp;magie</div></td>
					<td width=200 style="border:1px solid black;background-color:#3399cc">
						<img id=m src=design/barre/m.png>
					</td>
				</tr></table>
			</td>
			<td width=20></td>
			<td><div id=shortcuts></div></td>
		</tr></table>
	</td>
</tr><tr>
	<td id=input>
		<input type=text id=bar onkeypress=puts(event)>
	</td>
</tr></table>
</body>
</html>