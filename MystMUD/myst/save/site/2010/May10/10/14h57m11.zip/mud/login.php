<?php

session_start();
$_SESSION['name'] = $_SESSION['password'] = "";
$i = 1; $n = 0;

$msg = (isset($_GET['d']) and $_GET['d']) ? 'Connexion au serveur perdue.' : '';

if(isset($_POST['name1'], $_POST['password1'], $_POST['submit1'])){
	$db = mysql_connect("localhost", "root", "vesper007") or die(mysql_error());
	mysql_select_db('myst', $db) or die(mysql_error());
	$password = md5($_POST['password1']);
	$q = mysql_query("SELECT name, password FROM heroe WHERE name='$_POST[name1]' AND password='$password'");
	$p = mysql_fetch_object($q);
	if(is_object($p)){
		$_SESSION['name'] = $p->name;
		$_SESSION['password'] = $p->password;
		header("Location: index.php");
	} else { $msg .= "<br>Nom ou pass incorrect."; $n++; }
}

if(isset($_POST['name'], $_POST['password'], $_POST['submit'])){
	$db = mysql_connect("localhost", "root", "vesper007") or die(mysql_error());
	mysql_select_db('myst', $db) or die(mysql_error());
	$q = mysql_query("SELECT name FROM heroe WHERE name='$_POST[name]'");
	$p = mysql_fetch_object($q);
	if(!preg_match("#^[A-Z�]([a-z������������])*$#", $_POST['name'])){
		$msg .= "Un nom ne contient que des lettres et commence par une majuscule.<br>"; $i = 0;
	} if(strlen($_POST['name']) < 3 or strlen($_POST['name']) > 12){
		$msg .= "Le nom doit contenir entre 3 et 10 lettres.<br>"; $i = 0;
	} if(is_object($p)){
		$msg .= "Ce personnage existe d�j�.<br>"; $i = 0; $n++;
	} if(strlen($_POST['password']) < 5 or strlen($_POST['password']) > 10){
		$msg .= "Le mot de passe doit contenir entre 5 et 10 caract�res.<br>"; $i = 0;
	} if($i == 1){
		$msg = "Inscriptions ferm�es.";
		/*$time = time();
		$password = md5($_POST['password']);
		$sock = socket_create(AF_INET, SOCK_STREAM, 0);
		$cmd = "register.".$_POST['name'].".".$password.".";
		if(!@socket_connect($sock, "multi.servegame.com", 4000)){
			$msg .= "Erreur lors de la connexion au serveur du jeu.<br>";
		}
		if(!@socket_write($sock, $cmd, strlen($cmd))){
			$msg .= "Erreur lors de l'envoi d'une requ�te concernant la cr�ation du personnage.<br>";
		} else {
			$msg .= "C'est un gar�on ! Je dirais qu'il a une t�te � s'appeller ".$_POST['name'].".<br><br>Vous pouvez maintenant incarner ce personnage.";
		}
		socket_close($sock);*/
	}
}

if(isset($_GET['a'])){
	if($_GET['a'] == "restore") $msg .= "Si vous avez vraiment oubli� votre mot de passe, demandez en un nouveau : <a href='mailto:ofusiono@gmail.com'>ofusiono@gmail.com</a>";
}

?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
	<title>Myst</title>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" /> 
	<link rel="icon" type="image/png" href="ico/map/d/d00.png" />
	<link href="login.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript">
		function el(e){ return document.getElementById(e); }
		function show_stats(){
			el('stats').style.position = 'relative';
			el('stats').style.visibility = 'visible';
			el('stats_link').style.visibility = 'hidden';
			el('stats_link').style.position = 'absolute';
		}
		function start(){
			if(navigator.appVersion.indexOf("Chrome") > -1){
				el('chrome').style.visibility = "hidden";
				el('chrome').style.position = "absolute";
			}
		}
	</script>
</head>
<body class="default" onload="start(); el('<?php echo (isset($_GET['p']) && strlen($_GET['p']) > 0) ? 'password1' : 'name' ?>').focus()" style="margin: 0px">
<table cellpadding="0" width="100%" style="border-collapse: collapse;"><tr>
	<td height="70" colspan="2" style="background-image: url(design/top.jpg); background-repeat: repeat-x">
		<br><img src="design/logo.png" style="position:absolute;top:20" />
	</td>
</tr></table>

<div style="margin-left: 50px"><?php echo $msg; ?></div><br><br>

<table style="margin-left: 70" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<table width="140" style="border: 1px solid white" cellpadding="2" cellspacing="0">
				<tr>
					<td height="22" bgcolor="#2980A9" class="default">Se connecter</td>
				</tr><tr>
					<td bgcolor="#7DBFDF" style=padding:5px>
						<form action="login.php" method="post" name="log">
							<span class="default">Nom</span>
							<input name="name1" id="name" type="text"
							<?php if(isset($_GET['p'])) echo " value='$_GET[p]'"; ?> size="15" />
							<br><span class="default">Pass</span><br>
							<input name="password1" type="password" size="15" /><br>
							<input name="submit1" type="submit" value="Connexion" /><br>
							<div align="center"><br>
								<a href="?a=restore" class="whiteLink">Pass perdu ?</a>
							</div>
						</form>
					</td>
				</tr>
			</table>
		</td><td width="70"></td><td valign="top">
			<table width="160" style="border: 1px solid white" cellpadding="2" cellspacing="0">
				<tr>
					<td height="22" bgcolor="#7DBFDF" class="default">Cr�er un personnage</td>
				</tr><tr>
					<td bgcolor="#2980A9" style=padding:5px>
						<form action="login.php" method="post" name="log">
							<span class="default">Nom</span><br>
							<input name="name" type="text" size="15" /><br>
							<span class="default">Pass</span><br>
							<input name="password" type="password" size="15" /><br>
							<input name="submit" type="submit" value="Inscription" /><br>
						</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<br><br><br><div style="margin-left: 90px">

<?php

include("c:/www/cache/cache.php");
$srv = explode(",", get_cache("server"));
if(isset($srv[TIME], $srv[ONLINE_PLAYERS]) && $srv[TIME] > time() - 20){
	echo "Serveur de jeu <b>actif</b>"
		."<br>Joueurs en ligne : <b>".$srv[ONLINE_PLAYERS]."</b>";
} else {
	echo "Serveur de jeu <b>ferm�</b>";
}

?>

<br><br><a id="stats_link" href="javascript:show_stats()">Statistiques</a>
<div id="stats" style="position:absolute; visibility: hidden">

<?php

$world = explode(",", get_cache("world"));
	
echo '<u>_Le Monde de Myst_</u><pre>
 Zones		'.$world[ZONES].'
 Objets		'.$world[ITEMS].'
 Cr�atures 	'.$world[MOBS].'
 H�ros		'.$world[HEROES].'
 Magasins 	'.$world[SHOPS].'
 Sorts		'.$world[SPELLS].'
 Skins		'.$world[SKINS].'
 Avatars	'.$world[AVATARS].'</pre>';

?>

</div>

</div><br><?php /*
<table style="margin-left: 50px; border: 1px solid white" bgcolor="#2980A9">
	<tr>
		<td class="whitelink">
			<div style="margin: 8px; width: 432px">
				<span id="chrome"><a href="http://www.google.fr/chrome">T�l�charger Google Chrome</a> pour un jeu beaucoup plus fluide. <br><br></span>Le jeu est pour l'instant incompatible avec Linux et Internet Explorer et n'est pas h�berg� sur un serveur d�di�.
			</div>
		</td>
	</tr>
</table> */ ?>
</body>
</html>