<?PHP

echo "?char=&x=&y=&tileset=<br><br><br>";

$count = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
	
$n = 0;
$tileset = imagecreatefrompng("../tileset/".$_GET['tileset']."/tileset.png");

for($y=0; $y < $_GET['y']; $y++){
	$y1 = $y * 32;
	for($x=0; $x < $_GET['x']; $x++){
		$new = imagecreatetruecolor(32, 32);
		$x1 = $x * 32;
		imagecopyresampled($new, $tileset, 0, 0, $x1, $y1, 32, 32, 32, 32);
		$i = $_GET['char'].$count[$y].$count[$x];
		$file = "../tileset/".$_GET['tileset'].'/'.$i.'.png';
		$black = imagecolorallocate($new, 0, 0, 0);
		imagecolortransparent($new, $black);
		echo 'Saving to : '.$file."<br>";
		imagepng($new, $file);
		$n++;
	}
}

?>