var margintop = 0, ss = "", toAdd = "<br>", port = 6022
var m = new Array(), typed = new Array(), typedCurrentId = 0, shortcuts = new Array(), lists = new Array()

var so = new SWFObject("bridge.swf", "flash", "1", "1", "9", "#ffffff")
so.addParam("allowNetworking", "all")

function load(){ so.write("socket_bridge"); resize() }

function resize(){
	el("main").style.maxHeight = el("window").clientHeight - 200
	el("console").style.height = el("window").clientHeight - el("main").clientHeight - 57
	el('body').style.height = el("window").clientHeight
	el('console').scrollTop = 90000
}

function del_el(n){ if(el(n) != null) el(n).parentNode.removeChild(el(n)) }

function backCmd(){
	typedCurrentId--
	if(typeof typed[typedCurrentId] == 'undefined') typedCurrentId++
	else el('bar').value = typed[typedCurrentId]
}

function nextCmd(){
	typedCurrentId++
	if(typeof typed[typedCurrentId] == 'undefined'){ typedCurrentId = typed.length ; el('bar').value = "" }
	else el('bar').value = typed[typedCurrentId]
}

function puts(e){
	if(e.keyCode == 13){
		if(el('bar').value.length == 0){ el("console").innerHTML += "<p>&nbsp;</p>" ; resize() }
		else {
			var s = el('bar').value
			show_print('<font color=black># '+s.substring(0, 30)+"</font><br>")
			time1 = new Date().getTime()
			p(s)
			typedCurrentId = typed.length
			if(s != typed[typedCurrentId - 1]){ typed[typedCurrentId] = s ; typedCurrentId++ }
			el('bar').value = "" ; el('bar').focus()
		}
	}
	else if(el('bar').value.length == 0){
		switch(e.keyCode){
			case 38: n = 1; break
			case 233: n = 2; break
			case 34: n = 3; break
			case 39: n = 4; break
			case 40: n = 5; break
			case 45: n = 6; break
			case 232: n = 7; break
			case 95: n = 8; break
			case 231: n = 9; break
			case 224: n = 10; break
			default: n = 0
		}
		if(n != 0){ p(shortcuts[n])
		show_print('# '+shortcuts[n].substring(0, 30)+"<br>")
		setTimeout(function(){ el('bar').value = "" }, 0) }
	}
}

function str_replace(str1, str2, text){
	var new_text = "", arr = text.split(str1)
	for(var i in arr) new_text += arr[i] + str2
	return new_text
}

function el(id){ return document.getElementById(id) }

function elh(ele){
	if(el(ele).style.visibility == 'hidden') return
	el(ele).style.visibility = "hidden" ; el(ele).style.position = "absolute"
}

function elhh(ele){
	if(el(ele).style.visibility != 'hidden'){ el(ele).style.visibility = "hidden" ; el(ele).style.position = "absolute" }
	else { el(ele).style.visibility = "visible" ; el(ele).style.position = "" }
	resize()
}

function els(ele){
	if(el(ele).style.visibility != 'hidden') return
	el(ele).style.visibility = "visible" ; el(ele).style.position = ""
}

function addHTML(element, HTML) {
	var o = document.createElement("htmlSection"); o.innerHTML = HTML; element.appendChild(o)
}

function nreplace(s){ return s.replace(new RegExp("\n", "g"), ";") }

function pray_replace(s){ return s.replace(new RegExp("\n", "g"), "<br>") }

function show_add(listname, id, name){ if(lists[listname] && el('list_'+listname)) lists[listname].add(id, name) }

function show_alert(msg){ alert(msg) }

function show_avatar(you, avatar){ if(you == 'y') el('avatar').src = 'ico/avatar/'+avatar+'.png' }

function show_box(msg){ toAdd += "<br>"+msg }

function show_chat(color, msg){ toAdd += '<br><font color='+color+'> &nbsp;'+msg+'</font>' }
		
function show_del(listname, id){ if(lists[listname] && el('list_'+listname)) lists[listname].del(id) }
		
function show_main(s){ el("main").innerHTML = (s==undefined)? "" : s }

function show_main2(html){ el('secondary').innerHTML = html }

function show_msg(txt){ el('msg').innerHTML = txt }

function show_obj(html){ el('obj').innerHTML = html }

function show_print(msg){ toAdd += msg }
		
function show_quit(){ document.location.href = 'index.php' }

function show_text(html){ el("main").innerHTML += html }

function show_top(){ document.body.scrollTop = 0 }

function show_shortcuts(s){
	sdiv = el("shortcuts") ; sdiv.innerHTML = ""
	s = s.split(";")
	for(i in s){
		sh = s[i].split(",")
		if(typeof sh[1] == "undefined") continue
		shortcuts[i] = sh[1]
		sdiv.innerHTML += "<img height=20 onclick=\"javascript:p('!"+sh[1]+"')\" src='ico/shortcuts/"+sh[0]+".png' title='"+sh[1]+" ("+i+")'>"
	}
}

function show_health(vie, VM, magie, MM){
	var vpc = Math.round(vie / VM * 200), mpc = Math.round(magie / MM * 200), vc = 'red', mc = 'red'
	
	if(vpc < 0) vpc = 0; if(mpc < 0) mpc = 0;
	if(vpc > 200) vpc = 200; if(mpc > 200) mpc = 200;
	
	el("v").style.width = vpc
	el("m").style.width = mpc
	
	if(vpc >= 20) vc = 'yellow'
	if(vpc >= 40) vc = 'brown'
	if(vpc >= 60) vc = 'green'
	if(vpc >= 80) vc = '#0066FF'
	if(vpc == 100) vc = '#DDDDDD'
	if(mpc	>= 20) mc = 'yellow'
	if(mpc	>= 40) mc = 'brown'
	if(mpc	>= 60) mc = 'green'
	if(mpc	>= 80) mc = '#0066FF'
	if(mpc	== 100) mc = '#C0C0C0'
	
	el("vm").innerHTML = '<font color='+vc+'>'+vie+'</font>&nbsp;|&nbsp;<font color='+mc+'>'+magie+'</font>'
}

function p(s){ el("flash").write(s) }

function spread(s){
	//flash_alert(s)
	s = s.replace(/::\(([^-]+)-([^\)]+)\)/g, "<a href=\"javascript:p($1)\">$2</a>").replace(/::\[([^-]*)-([^\]]+)\]/g, "<a href=\"javascript:p('$1')\">$2</a>").split("::")
	func = this["show_"+(fu = s[0])]
	s.shift()
	if(typeof func == "function") func.apply(null, s)
	else show_chat("red", "Erreur ! ("+fu+")")
}

function flash_alert(s){ el("console").innerHTML += "<textarea cols=150 rows=1>"+s+"</textarea><br>" ; resize() }

function sock_loaded(){ show_main(serverInfo) ; el("flash").connect(host, port); resize() }

function sock_connected(){
	el("console").style.visibility='visible'
	show_main()
	el('bar').focus()
	shortcut.add("space", function(){ el('bar').focus() }, {'disable_in_input':true})
	shortcut.add("Up", backCmd) ; shortcut.add("Down", nextCmd)
	resize()
}

function sock_receive(s){
	if(s.substring(0, 5) == "<?xml" || typeof s == "undefined" ) return
	s = ss + s ; ss = ""
	var a = s.split("::_")
	if(s.substring(s.length - 3, s.length) != "::_"){ ss = a[a.length - 1] ; a.pop() }
	for(var i in a) if(a[i].length > 0) spread(a[i])
	addHTML(el("console"), toAdd) ; toAdd = "<br>"
	resize()
	el("bar").focus()
}

function sock_disconnected(){ document.location.href="index.php" }

function sock_close(){ el("flash").close() }