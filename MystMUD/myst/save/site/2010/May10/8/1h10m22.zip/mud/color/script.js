var last = 0

function el(id){ return document.getElementById(id) }

function display(id){
	el('active').innerHTML = el('content'+id).innerHTML
	el('tab'+last).style.backgroundColor= 'white'
	el('tab'+last).style.fontWeight= 'normal'
	last = id
	el('tab'+id).style.backgroundColor= '#D8DFEA'
}