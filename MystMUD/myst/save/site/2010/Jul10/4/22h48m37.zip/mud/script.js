﻿var margintop = 0, ss = '', buffer = '<br>', port = 6021, box_updated = false, HP, HPM, HPA, MP, MPM, MPA
var m = new Array(), typed = new Array(), typedCurrentId = 0, shortcuts = new Array(), lists = new Array()
var regen_active = false, adv_hide_timeout

var so = new SWFObject('bridge.swf', 'flash', '1', '1', '9', '#FFFFFF')
so.addParam('allowNetworking', 'all')

function load(){ resize() }

function resize(){
	el('main').style.maxHeight = (document.documentElement.clientHeight - 200)+'px'
	el('console').style.height = (document.documentElement.clientHeight - el('main').clientHeight - 54)+'px'
	el('console').scrollTop = 90000
}

function refresh(){
	resize()
	setTimeout(function(){ resize() }, 500)
}

function del_el(n){ if(el(n) != null) el(n).parentNode.removeChild(el(n)) }

function backCmd(){
	typedCurrentId--
	if(typeof typed[typedCurrentId] == 'undefined') typedCurrentId++
	else el('bar').value = typed[typedCurrentId]
}

function nextCmd(){
	typedCurrentId++
	if(typeof typed[typedCurrentId] == 'undefined'){ typedCurrentId = typed.length ; el('bar').value = '' }
	else el('bar').value = typed[typedCurrentId]
}

function puts(e){
	if(e.keyCode == 13){
		if(el('bar').value.length == 0){ el('console').innerHTML += '<p>&nbsp;</p>' ; resize() }
		else {
			var s = el('bar').value; show_echo(s)
			time1 = new Date().getTime(); c(s); typedCurrentId = typed.length
			if(s != typed[typedCurrentId - 1]){ typed[typedCurrentId] = s ; typedCurrentId++ }
			el('bar').value = '' ; el('bar').focus()
		}
	}
	else if(el('bar').value.length == 0){
		switch(e.keyCode == 0 ? e.which : e.keyCode){
			case 38: n = 1; break
			case 233: n = 2; break
			case 34: n = 3; break
			case 39: n = 4; break
			case 40: n = 5; break
			case 45: n = 6; break
			case 232: n = 7; break
			case 95: n = 8; break
			case 231: n = 9; break
			case 224: n = 10; break
			default: n = 0
		}
		if(n != 0){ c(shortcuts[n]); show_echo(shortcuts[n]); setTimeout(function(){ el('bar').value = '' }, 0) }
	}
}

function str_replace(str1, str2, text){
	var new_text = '', arr = text.split(str1)
	for(var i in arr) new_text += arr[i] + str2
	return new_text
}

function show_echo(echo){ show_print('<font color=#676767># '+echo.substring(0, 30)+'</font><br>') }
function replacen(s){ return s.replace("\n", '<br>') }
function el(id){ return document.getElementById(id) }
function elh(ele){ el(ele).style.display='none'; resize() }
function els(ele){ el(ele).style.display='block'; resize() }
function elhh(ele){ el(ele).style.display = (el(ele).style.display=='none') ? 'block' : 'none'; resize() }

function update_console(html){
	if(box_updated) el('console').innerHTML += '<br>';
	el('console').innerHTML += html
}

function nreplace(s){ return s.replace(new RegExp("\n", 'g'), ';') }
function pray_replace(s){ return s.replace(new RegExp("\n", 'g'), '<br>') }
function show_add(listname, id, name){ if(lists[listname] && el('list_'+listname)) lists[listname].add(id, name) }
function show_alert(msg){ alert(msg) }
function show_avatar(you, avatar){ if(you == 'y') el('avatar').src = 'ico/avatar/'+avatar+'.png' }
function show_box(msg){ buffer += '<br>'+msg; box_updated = true }
function show_chat(color, msg){ buffer += '<br><font color='+color+'> &nbsp;'+msg+'</font>' }
function show_del(listname, id){ if(lists[listname] && el('list_'+listname)) lists[listname].del(id) }
function show_main(s){ el('main').innerHTML = (s==undefined)? '' : s }
function show_main2(html){ el('secondary').innerHTML = html }
function show_msg(txt){ el('msg').innerHTML = txt }
function show_obj(html){ el('obj').innerHTML = html }
function show_print(msg){ buffer += msg }
function show_quit(){ document.location.href = 'index.php' }
function show_text(html){ el('main').innerHTML += html }
function show_top(){ document.body.scrollTop = 0 }

function show_adv(name, hppc){
	clearTimeout(adv_hide_timeout)
	el('adv_name').innerHTML=name
	el('adv').style.visibility='visible'
	el('adv_v').style.width=Math.round(hppc*2.31)+'px'
	el('adv1').style.backgroundColor='white'
	el('adv2').style.backgroundColor='orange'
	adv_hide_timeout = setTimeout(function(){hide_adv()}, 2200)
}

function hide_adv(){
	el('adv1').style.backgroundColor=el('adv2').style.backgroundColor='black'
	el('adv').style.visibility='hidden'
}

function show_shortcuts(s){
	sdiv = el('shortcuts')
	sdiv.innerHTML=''
	s=s.split(';')
	for(i in s){
		sh = s[i].split(',')
		if(typeof sh[1] == 'undefined') continue
		shortcuts[i] = sh[1]
		sdiv.innerHTML += '<img height="20" onclick="javascript:p(\'!shortcut edit '+(i-1)+'\')\" src="ico/shortcuts/'+sh[0]+'.png" title="'+sh[1]+' ('+i+')">'
	}
}

function show_reset_bars(){
	regen_active = false
	el('left_hp_arrows').innerHTML=''
	el('right_hp_arrows').innerHTML=''
	el('left_mp_arrows').innerHTML=''
	el('right_mp_arrows').innerHTML=''
	el('v').style.width = 250+'px'
	el('hp').innerHTML = 'vie'
	el('m').style.width = 250+'px'
	el('mp').innerHTML = 'magie'
}

function regen(){
	if(!regen_active) return; var vpx, mpx
	HP=Math.round(HP+HPA*(HPM/800)); MP=Math.round(MP+MPA*(MPM/800))
	if(HP>HPM){HP=HPM; vpx=250} else if(HP<0){HP=0; vpx=0} else vpx=Math.round(HP/HPM*250)
	if(MP>MPM){MP=MPM; mpx=250} else if(MP<0){MP=0; mpx=0} else mpx=Math.round(MP/MPM*250)
	el('v').style.width=vpx+'px'; el('hp').innerHTML=HP
	el('m').style.width=mpx+'px'; el('mp').innerHTML=MP
	setTimeout(function(){ regen() }, 150)
}

function show_health(vie, VM, magie, MM, hp_arrows, mp_arrows){
	var vpx, mpx, i, s= ''
	HP=vie=parseInt(vie); HPM=VM=parseInt(VM); HPA=hp_arrows=parseInt(hp_arrows)
	MP=magie=parseInt(magie); MPM=MM=parseInt(MM); MPA=mp_arrows=parseInt(mp_arrows)
	if(HP>HPM){HP=HPM; vpx=250} else if(HP<0){HP=0; vpx=0} else vpx=Math.round(HP/HPM*250)
	if(MP>MPM){MP=MPM; mpx=250} else if(MP<0){MP=0; mpx=0} else mpx=Math.round(MP/MPM*250)
	el('v').style.width=vpx+'px'; el('hp').innerHTML=HP
	el('m').style.width=mpx+'px'; el('mp').innerHTML=MP
	el('left_hp_arrows').innerHTML=''; el('right_hp_arrows').innerHTML=''
	el('left_mp_arrows').innerHTML=''; el('right_mp_arrows').innerHTML=''
	if(hp_arrows < 0){
		for(i=0; i>hp_arrows; i--) s+= '&lsaquo;'; el('left_hp_arrows').innerHTML=s}
	else if(hp_arrows > 0){
		for(i=0; i<hp_arrows; i++) s+= '&rsaquo;'; el('right_hp_arrows').innerHTML=s}; s=''
	if(mp_arrows < 0){
		for(i=0; i>mp_arrows; i--) s+= '&lsaquo;'; el('left_mp_arrows').innerHTML=s}
	else if(mp_arrows > 0){
		for(i=0; i<mp_arrows; i++) s+= '&rsaquo;'; el('right_mp_arrows').innerHTML=s}
	if(!regen_active){setTimeout(function(){regen()}, 500); regen_active=true}
}

function c(s){ while(s[0] == '!') s = s.substring(1, s.length); p(s) }
function p(s){ el('flash').write(s) }

function spread(s){
	//flash_alert(s)
	s = s.replace(/::\(([^-]+)-([^\)]+)\)/g, '<a href="javascript:p($1)">$2</a>').replace(/::\[([^-]*)-([^\]]+)\]/g, '<a href="javascript:p(\'$1\')">$2</a>').split('::')
	if(s[0] == '-->box') s[0] = 'box'
	func = this['show_'+(fu = s[0])]
	s.shift()
	if(typeof func == 'function') func.apply(null, s)
	else show_chat('red', 'Erreur ! ('+fu+')')
}

function flash_alert(s){
	el('console').innerHTML += '<textarea cols="150" rows="1">'+s+'</textarea><br>'
	resize()
}

function sock_loaded(){ show_main(serverInfo) ; el('flash').connect(host, port); resize() }

function sock_connected(){
	el('console').style.visibility='visible'
	show_main()
	el('bar').focus()
	shortcut.add('space', function(){ el('bar').focus() }, {'disable_in_input':true})
	shortcut.add('Up', backCmd) ; shortcut.add('Down', nextCmd)
	resize()
}

function sock_receive(s){
	if(s.substring(0, 5) == '<?xml') s = s.split('<!--')[1]
	s = ss + s ; ss = ''
	var a = s.split('::_')
	box_updated = false
	if(s.substring(s.length - 3, s.length) != '::_'){ ss = a[a.length - 1]; a.pop() }
	for(var i in a) if(a[i].length > 0) spread(a[i])
	update_console(buffer); buffer = ''; refresh()
	el('bar').focus()
}

function sock_disconnected(){
	buffer += '<br><b><i>Déconnecté du serveur.</i></b>'
	update_console('<br>'+buffer) ; buffer = ''; resize()
	show_reset_bars()
}

function sock_close(){ el('flash').close() }

function show_list(name, acts, items){
	lists[name] = new list(name)
	lists[name].acts = acts.split(';')
	items = items.split(';;')
	items.shift()
	for(i in items){ if(items[i].length < 1) continue; var e = items[i].split(','); lists[name].items[e[1]] = e[0] }
	lists[name].build()
}

var list = function(name){
	this.name = name
	this.items = new Array()
	this.acts = new Array()
	this.last = 0
	this.actions = ''
	this.div = 'list_'+this.name
}

list.prototype = {
	translate: {drop: 'poser', get: 'ramasser', examine_item: 'examiner', examine_body: 'examiner', wear: 'équiper', remove: 'retirer', kill: 'attaquer', look: 'regarder', get_from: 'ramasser', moveup: 'permuter vers le haut', movedown: 'permuter vers le bas', edit: 'modifier'},

	build: function(){
		this.actions = '<table class="compact"><tr>'
		for(i in this.acts){
			a = this.acts[i].split(',')[0]
			this.actions += '<td><a href="javascript:lists[\''+this.name+'\'].act(\''+this.acts[i]+'\')" title="'+this.translate[a]+'"><img class="list-ico" src="ico/actions/'+a+'.png"></a></td>'
		}
		this.actions += '</tr></table>'
		this.display()
	},
	
	display: function(){
		s = '<table class="list">'
		for(id in this.items){
			s += '<tr><td onmouseover="lists.'+this.name+'.on('+id+')" onmouseout="lists.'+this.name+'.off()"><table><tr><td onclick="lists[\''+this.name+'\'].act(\''+this.acts[0]+'\')\">'+this.items[id]+'</td><th id=act_'+this.name+id+'>'+this.actions+'</th></tr></table></td></tr>'
		}
		el(this.div).innerHTML = s+'</table>'
	},
	
	del: function(id){ if(!this.items[id]) return ; delete this.items[id] ; this.display() },
	add: function(id, name){ this.items[id] = name ; this.display() },
	on: function(id){ el('act_'+this.name+id).style.visibility = 'visible' ; this.last = id },
	off: function(){ el('act_'+this.name+this.last).style.visibility = 'hidden' },
	
	act: function(a){
		switch(a.split(',')[0]){
			case 'drop': p('drop * '+this.last) ; break
			case 'get': p('get * '+this.last) ; break
			case 'examine_item': p('examine item '+this.last) ; break
			case 'examine_body': p('examine body '+this.last) ; break
			case 'wear': p('wear '+this.last) ; break
			case 'remove': p('remove '+this.last) ; break
			case 'kill': p('kill '+this.last) ; break
			case 'look': p('look '+this.last) ; break
			case 'get_from': p('get * '+this.last+' '+el('bid').value) ; break
			case 'moveup': p('!shortcut moveup '+(this.last - 1)) ; break
			case 'movedown': p('!shortcut movedown '+(this.last - 1)) ; break
			case 'edit': p('!shortcut edit '+(this.last - 1)) ; break
		}
	}
}