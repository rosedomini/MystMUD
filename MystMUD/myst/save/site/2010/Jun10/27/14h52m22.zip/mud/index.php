﻿<?PHP

$file = __FILE__;
if($file[0] == 'C') include 'C:/var/cache/cache.php';
else include '/m/cache/cache.php';
$srv = explode(',', get_cache('server'));
$active = (isset($srv[TIME], $srv[ONLINE_PLAYERS]) && $srv[TIME] > time() - 20)

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml xml:lang=fr">
<head>
	<title>Myst</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
	<link rel="icon" type="image/png" href="design/spiral.png">
	<link rel="stylesheet" href="style.css">
	<script language="Javascript">
		var serverInfo = '<?php if($active){ ?><table class="default" style="width:70%"><tr><td><p>Serveur de jeu <b>actif</b><br>Joueurs en ligne : <b><?php echo $srv[ONLINE_PLAYERS] ?></b></p></td><td><p>Connexion en cours...</p><?php } else { ?><table class="default" style="width:70%"><tr><td><p>Serveur de jeu <b>fermé</b></p></td><td> <?php } ?></td><td><a href="index.php">Actualiser</a><br><a href="login.php">Retour</a><br></td></tr></table>', host='<?php echo ($file[0] == 'C') ? '127.0.0.1' : '62.193.219.166'; ?>'
	</script>
	<script language="Javascript" src="swfobject.js"></script>
	<script language="Javascript" src="shortcuts.js"></script>
	<script language="Javascript" src="script.js"></script>
</head>

<body onresize="resize()" onload="load()">

<div id="socket_bridge" style="position:absolute"></div>

<script type="text/javascript">so.write('socket_bridge')</script>

<table id="body" cellpadding="0" cellspacing="0" align="center"><tr>
	<td rowspan="3" width="9" background="design/left.png"></td>
	<td id="maintd">
		<div id="main" class="default">
			<p>Flash Player est requis pour vous connecter au jeu (si possible la dernière version).</p>
			<p><a target="_blanck" href="http://get.adobe.com/fr/flashplayer/">Télécharger Flash Player</a></p>
			<p><a href="index.php">Réessayer</a></p>
		</div>
		<hr style="margin-bottom:0px;margin-top:0px">
		<div id="console">
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php /*
	$world = explode(",", get_cache("world"));
	echo '<u>_Le Monde de Myst_</u><pre>
	Salles		'.$world[ROOMS].'
	Zones		'.$world[AREAS].'
	Objets		'.$world[ITEMS].'
	Créatures 	'.$world[MOBS].'
	Héros		'.$world[HEROES].'
	Magasins 	'.$world[SHOPS].'
	Sorts		'.$world[SPELLS].'
	Skins		'.$world[SKINS].'
	Avatars	'.$world[AVATARS].'</pre>'; */
 ?>
		</div>
	</td>
	<td rowspan="3" width="9" background="design/right.png"></td>
</tr><tr>
	<td id="vmt" height="25">
		<table cellpadding="0" cellspacing="0"><tr>
			<td>
				<table cellpadding="0" cellspacing="5" class="default"><tr>
					<td width="5"></td>
					<td width="200" style="border:1px solid black;background-color:orange">
						<img id="v" src="design/barre/v.png">
					</td>
					<td width="5"><div id="vm" style="font-size:13px">vie&nbsp;|&nbsp;magie</div></td>
					<td width="200" style="border:1px solid black;background-color:#3399CC">
						<img id="m" src="design/barre/m.png">
					</td>
				</tr></table>
			</td>
			<td width="20"></td>
			<td><div id="shortcuts"></div></td>
		</tr></table>
	</td>
</tr><tr>
	<td id="input">
		<input type="text" id="bar" onkeypress="puts(event)" />
	</td>
</tr></table>
</body>
</html>