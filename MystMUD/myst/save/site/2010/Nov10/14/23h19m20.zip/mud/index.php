﻿<?PHP

$file = __FILE__;
if($file[0] == 'C') include 'C:/var/cache/cache.php';
else include '/m/cache/cache.php';
$srv = explode(',', get_cache('server'));
$active = (isset($srv[TIME], $srv[ONLINE_PLAYERS]) && $srv[TIME] > time() - 20)

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml xml:lang=fr">
<head>
	<title>Myst</title>
	<meta http-equiv=content-type content=text/html;charset=UTF-8> 
	<link rel=icon type=image/png href=design/spiral.png>
	<link rel=stylesheet href=style.css>
	<script language=Javascript>
		var serverInfo = '<?php if($active){ ?><table class="default" style="width:70%"><tr><td><p>Serveur de jeu <b>actif</b><br>Joueurs en ligne : <b><?php echo $srv[ONLINE_PLAYERS] ?></b></p></td><td><p>Connexion en cours...</p><?php } else { ?><table class="default" style="width:70%"><tr><td><p>Serveur de jeu <b>fermé</b></p></td><td> <?php } ?></td><td><a href="index.php">Actualiser</a><br></td></tr></table>', host='<?php echo ($file[0] == 'C') ? '127.0.0.1' : '62.193.219.166'; ?>'
	</script>
	<script language=Javascript src=swfobject.js></script>
	<script language=Javascript src=shortcuts.js></script>
	<script language=Javascript src=script.js></script>
</head>

<body onresize=resize() onload=load()>

<div id=socket_bridge style=position:absolute></div>

<script type=text/javascript>so.write('socket_bridge')</script>

<table id=team_w cellpadding=0 cellspacing=0 style=border-collapse:collapse;position:fixed;top:50px;left:20px;display:none><tr background=design/w_top.png>
	<td height=24 onmousedown=tw_down() onmouseup=tw_up() style=border-right:none>
		<font color=#496690><b>&nbspÉquipe</b></font>
	</td><td width=14 style=padding:4px;border-left:none>
		<img src=design/close.png onclick=team_w_close()>
	</td>
</tr><tr>
	<td colspan=2 bgcolor=white>
		<div id=team_w_content style=padding:4px;color:black>
			Pas d'équipe. <a href="javascript:p('aide team')">Former une équipe</a>
		</div>
	</td>
</tr></table>

<table id=body cellpadding=0 cellspacing=0 align=center><tr>
	<td rowspan=3 width=9 background=design/left.png></td>
	<td id=maintd>
		<div id=main class=default>
			<p>Flash Player est requis pour vous connecter au jeu (si possible la dernière version).</p>
			<p><a target=_blanck href=http://get.adobe.com/fr/flashplayer/>Télécharger Flash Player</a></p>
			<p><a href=index.php>Réessayer</a></p>
		</div>
		<hr style=margin-bottom:0px;margin-top:0px>
		<div id=console>Si un problème d'affichage survient ou si le jeu n'est pas fluide, <a href=configuration.html target=_blank>cliquez ici</a>.
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			Si un problème d'affichage survient ou si le jeu n'est pas fluide, <a href=configuration.html target=_blank>cliquez ici</a>.<br>
<?php /*
	$world = explode(",", get_cache("world"));
	echo '<u>_Le Monde de Myst_</u><pre>
	Salles		'.$world[ROOMS].'
	Zones		'.$world[AREAS].'
	Objets		'.$world[ITEMS].'
	Créatures 	'.$world[MOBS].'
	Héros		'.$world[HEROES].'
	Magasins 	'.$world[SHOPS].'
	Sorts		'.$world[SPELLS].'
	Skins		'.$world[SKINS].'
	Avatars	'.$world[AVATARS].'</pre>'; */
 ?>
		</div>
	</td>
	<td rowspan=3 width=9 background=design/right.png></td>
</tr><tr>
	<td id=vmt height=20 valign=bottom>
		<table cellpadding=0 cellspacing=0><tr>
			<td width=250 bgcolor=orange>
				<span id=left_hp_arrows class=leftarrows></span>
				<span id=hp class=centernumber>Vie</span>
				<span id=right_hp_arrows class=rightarrows></span>
				<img id=v src=design/barre/v.png>
			</td>
			<td width=8 bgcolor=white></td>
			<td width=250 bgcolor=#3399CC>
				<span id=left_mp_arrows class=leftarrows></span>
				<span id=mp class=centernumber>Magie</span>
				<span id=right_mp_arrows class=rightarrows></span>
				<img id=m src=design/barre/m.png>
			</td>
			<td id=adv1 width=8></td>
			<td id=adv2 width=229><div id=adv>
				<span id=adv_name class=centernumber>Adversaire</span>
				<img id=adv_v src=design/barre/v.png>
			</div></td>
		</tr></table>
	</td>
</tr><tr>
	<td id=input>
		<div id=shortcuts></div>
		<input type=text id=bar onkeypress=puts(event) />
	</td>
</tr></table>
</body>
</html>