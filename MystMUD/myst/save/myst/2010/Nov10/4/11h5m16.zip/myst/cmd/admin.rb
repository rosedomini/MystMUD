﻿
class Heroe < Actor
	def cmd_help command
		if command = $command[command]
				wiz "<font color=orange>Syntaxe: </font>#{command.syntax}<br> ¤ #{command.help}"
		else
			s = '<br><u>Commandes des immortels :</u><br><br><table style=width:80%;border:none><tr>'
			i = 0
			$command.each do |name, command|
				next if command.authlevel.zero?
				i += 1
				s << '</tr><tr>' if (i%4).zero?
				s << "<td width=25%>::[help #{name}-#{name}]</td>"
			end
			echo "main::#{s}</tr></table>"
		end
	end
	
	def rcreate direction
		x, y, z = @room.x, @room.y, @room.z
		
		direction = case direction
			when :n then y += 1; :nord
			when :s then y -= 1; :sud
			when :o then x -= 1; :ouest
			when :e then x += 1; :est
			when :h then z += 1; :haut
			when :b then z -= 1; :bas
		end
		
		if $w[x, y, z] then wiz 'Il existe déjà une salle à cet endroit.'
		else
			$w.create_room x, y, z
			move direction
		end
	end
	
	def redit close = false
		return @redit = false if close
		
		s = "main::<p><a href=\"javascript:el('main').innerHTML='';p('redit close')\">fermer</a> - Créer une salle : ::[rcreate n-n]::[rcreate s-s]::[rcreate o-o]::[rcreate e-e]::[rcreate h-h]::[rcreate b-b] - ::[delete room #{@room.id}-supprimer]</p><p><font color=black>room[#{@room.id}] :</b> #{@room}</font></p><br><table style=width:100%;border:none class=default><tr><td align=center width=100><b><font color=black>Variable<br></font></b></td><td width=100% align=center><b><font color=black>Valeur<br></font></td><td width=30 align=center></td><td align=center width=100><b><font color=black>Type<br></font></b></td>"
		
		[:name, :desc, :x, :y, :z, :items, :exits].each do |var|
			v, type = $data[:Room].to_olc(var, @room.instance_variable_get("@#{var}"))
			rows = 1
			v_rows = v.split("\n")
			v_rows.each{ |row| rows += row.length / 70 }
			rows = 5 if var == :desc
			s << "</tr><tr><td align=right>#{var}</td><td><textarea rows=#{rows} id=olcv_#{var} cols=70>#{v}</textarea></td><td>::('set Room #{@room.id} #{var} '+replacen(el('olcv_#{var}').value)-OK)</td><td align=center>#{type}</td>"
		end
		
		echo "#{s}</tr></table>"
		@redit = true
	end
	
	def goto room = nil
		if room
			@room = room
			look_around
			redit if @redit
		else
			s = 'main::<p>Aller à :</p><br>'
			
			$room.each_value do |room|
				s << "<p>#{room.id} - ::[goto #{room.id}-#{room}]</p>"
			end
			
			echo s
		end
	end

	def ruby script = nil
		if script
			begin
				begin
					eval script
					wiz 'Terminé'
				rescue SyntaxError
					wiz 'Syntax Error.'
				end
			rescue
				wiz "exécution échouée : #{CGI.escapeHTML $!.to_s}"
			end
		else
			echo "main::<u>Script multi lignes</u><br><br><textarea id=ruby style=width:80%;height:200px></textarea><br><a href=\"javascript:p('ruby '+nreplace(el('ruby').value))\">Exécuter</a>"
		end
	end
end