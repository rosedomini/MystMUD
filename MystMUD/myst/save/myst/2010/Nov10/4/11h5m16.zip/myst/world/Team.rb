﻿
class Team < Array
	attr_reader :leader
	attr_writer :leader
	
	def initialize leader
		super 0
		self << @leader = leader
	end
end