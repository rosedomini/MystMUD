﻿class Fight
	Hit = {
		:cognant => ['cogne', 'cognez'],
		:frappant => ['frappe', 'frappez'],
		:tapant => ['tape', 'tapez'],
		:tranchant => ['tranche', 'tranchez']
	}

	def self.fighters
		fighters = []
		$actor.each_value do |actor|
			if target = actor.target and target.online? and actor.room == target.room
				target.target = actor
				fighters << actor unless fighters.index actor
				fighters << target unless fighters.index target
		end end
		fighters
	end
	
	@@round_calls = 3
	Round_timestart = Time_start

	def self.round
		$task.repeat = Round_timestart + (@@round_calls+=1) - Time.now.to_f
		
		(fighters = Fight.fighters).each do |actor|
			next unless target = actor.target
			
			actor.weapons.each do |hand, weapon|
				next if weapon.is_a? Fist and !actor.weapons[hand == :left ? :right : :left].is_a? Fist
				
				weapon.update if weapon.is_a? Fist
				hit_type = Hit[weapon.stats[:damage_type]]
				hit = weapon.stats[:damage] * (actor.str.to_f / target.con) - target.armor
				hit = 0 if hit < 0
				hit = (hit * 0.7 + rand(hit * 0.6)).to_i
				
				# >>>>>>>>> Application et affichage d'un potentiel coup critique >>>>>>>>>
				if rand(9).zero?
					hit = (hit * 2.5).to_i
					
					actor.wiz "* Vous réalisez un coup critique sur #{target.sb? actor, nil} !", :red
					target.wiz "* #{actor.sb? target} vous inflige un coup critique !", :red
					
					actor.each_witness_heroe do |heroe|
						next if heroe == target
						heroe.wiz "* #{actor.sb? heroe} inflige un coup critique à #{target.sb? heroe, nil} !", :red
				end end
				# <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
				
				actor.wiz "Vous #{hit_type[1]} #{target.sb? actor, nil} ~ #{hit} points."
				target.wiz "#{actor.sb? target, nil} vous #{hit_type[0]} ~ #{hit} points."

				actor.each_witness_heroe do |x|
					if x != target
						x.wiz "#{actor.sb? x} #{hit_type[0]} #{target.sb? x} ~ #{hit} points."
				end end
				
				target.hurt hit, actor # Blesse la cible et si mort : renvoi les xp
				break unless actor.target == target
			end
		end
	end
end
