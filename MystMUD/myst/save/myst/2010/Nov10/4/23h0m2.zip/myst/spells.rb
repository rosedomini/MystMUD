﻿
class Actor
	def cast_boule_de_feu power, target
		if target or (target = @target and can_reach? target)
			dmg = (power+4*@wis) /2
			
			wiz "Vous envoyez une boule de feu sur #{target.sb? self} ~ #{dmg} points."
			target.wiz "#{sb? target} vous envoie une boule de feu ~ #{dmg} points."
			target.kill self unless target.target
			
			@room.actors.each do |actor|
				if actor.room == @room and actor != self and actor != target
					actor.wiz "#{sb? actor} envoie une boule de feu sur #{target.sb? actor} ~ #{dmg} points."
				end
			end
				
			target.hurt dmg, self
		else wiz 'Lancer sur qui ?' end
	end
	
	def cast_bouclier power, target = nil
		if target
			wiz "Vous invoquez un bouclier magique sur #{target}."
			target.wiz "#{sb? target} invoque un bouclier magique autours de vous."
			each_close_heroe do |heroe|
				if heroe != target
					heroe.wiz "#{@name} invoque un bouclier magique autours de #{target.sb? heroe}."
				end
			end
			target.affect :bouclier, power, power /2
		else
			wiz 'Vous vous encerclez d\'un bouclier magique de couleur nacre.'
			each_close_heroe do |heroe|
				heroe.wiz "#{@name} s'entoure d'un bouclier magique de couleur nacre."
			end
			affect :bouclier, power, power /2
		end
	end
	
	def cast_soin power, target = nil
		if target
			wiz "Vous mumblez une incantation et #{target} récupère ses forces. ~ #{power} points"
			target.wiz "#{sb? target} vous soigne. ~ #{power} points"
			each_close_heroe do |heroe|
				if heroe != target
					heroe.wiz "#{@name} mumble une incantation et soigne #{target.sb? heroe, nil}. ~ #{power} points"
				end
			end
			target.heal power
		else
			wiz 'Vous mumblez une incantation et récupérez vos forces.'
			each_close_heroe do |heroe|
				heroe.wiz "#{@name} mumble une incantation et se soigne. ~ #{power} points"
			end
			heal power
		end		
	end
end