
class Fist
	attr_reader :stats, :actor, :hand
	
	def initialize actor, hand
		@actor = actor
		@hand = hand
	end
	
	def update
		damage_type = case rand(100)
			when 0..50 then :cognant
			when 51..85 then :frappant
			else :tapant
		end
		@stats = {
			:damage => @actor.str * 3,
			:damage_type => damage_type
		}
	end
	
	def type; :arme end
end