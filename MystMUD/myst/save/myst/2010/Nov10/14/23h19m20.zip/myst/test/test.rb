﻿
class Task
	attr_accessor :name
	
	def initialize name
		@name = name
		Task.current = self
	end
end

class << Task
	attr_accessor :current
end

Task.new 'Elea'

p Task.current