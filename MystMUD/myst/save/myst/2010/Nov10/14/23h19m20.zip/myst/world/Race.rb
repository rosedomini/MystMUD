﻿
class Race
	attr_reader :id, :name, :description, :skill_points, :spell_points, :skill, :spell, :power
	alias to_s name
	
	def initialize id; @id = id end
end