﻿
class Shop
	attr_reader :id, :name, :keeper, :room, :inv
	alias to_s name
	
	def initialize id; @id = id end
end