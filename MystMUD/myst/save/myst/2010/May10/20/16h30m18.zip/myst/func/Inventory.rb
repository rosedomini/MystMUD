﻿
class Inventory < Hash
	def << items
		if items.is_a? Hash
			items.each do |key, value|
				if self[key]
					self[key] += value
				else
					store key, value
				end
			end
		elsif items.is_a? Fixnum
			self[items] = if self[items] then self[items] + 1 else 1 end
		else
			raise ArgumentError
		end
		self
	end
	
	def add item, number
		self[item] = if self[item] then self[item] + number else number end
	end
end