﻿
class Race
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :description
	attr_accessor :skill, :spell
	attr_accessor :skill_points, :spell_points
	attr_accessor :power
	
	def initialize id
		@id = id
	end
end

		# id < 1 and return
		# q = $db.query "SELECT * FROM race WHERE id='#{id}'"
		# f = q.fetch_object

		# @id = f['id'].to_i
		# @name = f['name']
		# @description = f['description']
		# @skill_points = f['skill_points'].to_i
		# @spell_points = f['spell_points'].to_i
		
		# @power = eval(f['power'])
		# unless @power.is_a?(Hash) then @power = {} end
		
		# @sk = eval(f['skills'])
		# unless @sk.is_a?(Hash) then @sk = {} end
		
		# @sp = eval(f['spells'])
		# unless @sp.is_a?(Hash) then @sp = {} end