﻿
# fonctions des commandes admin diverses

class Cmd
	def Cmd.dump var = nil
		unless var
			wiz "Affichage des envois #{($dump = $dump ? false : true) ? "" : "dés"}activé."
		else
			echo "main::<pre>#{CGI.escapeHTML(eval(var).inspect.gsub(/::/, ": :"))}</pre>"
		end
	end
	
	def Cmd.help command
		if c = $command[command]
			echo "main::::[help-liste des commandes]<br><br>#{c.syntax}<br><br>#{c.help}"
			return
		end
		
		s = "<u>Liste des commandes :</u><br><br><table style=width:80%;border:none><tr>"
		i = 0
		$command.each do |name, cmd|
			i += 1
			if (i%4).zero?
				s << "</tr><tr>"
			end
			s << "<td width=25%>::[help #{name}-#{name}]</td>"
		end
		echo "main::#{s}</tr></table>"
	end
	
	def Cmd.include path
		begin
			File.open(path, "r+") do |file|
				eval(file.read)
			end
			wiz "Contenu du fichier exécuté."
		rescue
			wiz "Erreur : #{$!}"
		end
	end

	def Cmd.ruby script = nil
		if script
			begin
				eval script
				wiz "Script exécuté avec succès !"
			rescue
				wiz "exécution échouée : #{CGI.escapeHTML $!.to_s}"
			end
		else
			echo "main::<u>Script multi lignes</u><br><br><textarea id=ruby style=width:80%;height:200px></textarea><br><a href=\"javascript:p('ruby '+nreplace(el('ruby').value))\">Exécuter</a>"
		end
	end
end
