﻿
class Fight
	def self.fighters
		fighters = []
		$actor.each_value do |actor|
			if target = actor.target and target.online? and actor.room == target.room
				target.target = actor
				fighters << actor unless fighters.index actor
				fighters << target unless fighters.index target
			end
		end
		fighters
	end

	def self.round
		(fighters = Fight.fighters).each do |actor|
			target = actor.target
			if arme = actor.equip[:main_gauche]
				dmg = 0 unless dmg = arme.stats[:damage]
				if arme.stats[:damage_type]
					dmg_type = $dmg_types[arme.stats[:damage_type]]
				else
					dmg_type = $dmg_types[:tappant]
				end
			else
				dmg = 3*actor.str
				dmg_type = $dmg_types[:frappant]
			end

			dmg += actor.str * dmg / 100 - target.con
			dmg = 0 if dmg < 0
			dmg = (dmg * 0.7 + rand(dmg * 0.6)).to_i
			
			# <<<<<<<<< Application et affichage d'un potentiel coup critique <<<<<<<<
			if rand(9).zero?
				dmg = (dmg * 2.5).to_i
				
				actor.wiz "* Vous réalisez un coup critique sur #{target.sb? actor, nil} !", :red
				target.wiz "* #{actor.sb? target} vous inflige un coup critique !", :red
				
				actor.witness_heroes.each do |heroe|
					next if heroe == target
					heroe.wiz "* #{actor.sb? heroe} inflige un coup critique à #{target.sb? heroe, nil} !", :red
				end
			end
			# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	
			
			actor.wiz "Vous #{dmg_type[1]} #{target.sb? actor, nil}. (<font color=#3366CC>#{dmg}</font>)"
			target.wiz "#{actor.sb? target, nil} vous #{dmg_type[0]}. (<font color=#3366CC>#{dmg}</font>)"
			
			if targer.hp -= dmg and actor.heroe?	#
				actor.add_xp target.xp_gives			# Blesse la cible et si mort : renvoi les xp 
			end														#

			actor.witness_heroes.no(target).each do |x|
				x.wiz "#{actor.sb? x} #{dmg_type[0]} #{target.sb? x}. (#{dmg})"
			end
		end
		
		Fight.send_all fighters
		$task.timestamp = Time.now.to_f + 1.5
	end
	
	def self.send_all fighters
		fighters.each do |x|
			if fighters.index(y = x.target)
				x.wiz "<br><span style=margin-left:25px>Vie : #{x.hp}/#{x.maxhp} &nbsp; Magie : #{x.mp}/#{x.maxmp} &nbsp; Adv. : <font color=#3366CC>#{(100 * y.hp / y.maxhp).to_i}%</font></span>"
			end
		end
	end
end
