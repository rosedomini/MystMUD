﻿
class Heroe < Actor
	def rcreate direction
		x, y, z = @room.x, @room.y, @room.z
		
		case direction
			when :n then y += 1
			when :s then y -= 1
			when :o then x -= 1
			when :e then x += 1
			when :h then z += 1
			when :b then z -= 1
		end
		
		if $w[x, y, z]
			wiz "Il existe déjà une salle à cet endroit."
		else
			move_to $w.create_room(x, y, z)
			redit
			look_around
		end
	end
	
	def redit close = false
		if close
			return @redit = false
		end
		
		s = "main::<p><a href=\"javascript:el('main').innerHTML='';p('redit close')\">fermer</a> - Créer une salle : ::[rcreate n-n]::[rcreate s-s]::[rcreate o-o]::[rcreate e-e]::[rcreate h-h]::[rcreate b-b]</p><p><font color=black>room[#{@room.id}] :</b> #{@room}</font></p><br><table style=width:100%;border:none class=default><tr><td align=center width=100><b><font color=black>Variable<br></font></b></td><td width=100% align=center><b><font color=black>Valeur<br></font></td><td width=30 align=center></td><td align=center width=100><b><font color=black>Type<br></font></b></td>"
		
		[:name, :desc, :x, :y, :z, :items, :exits].each do |var|
			v, type = $data[:Room].to_olc(var, @room.send(var))
			rows = 1
			v_rows = v.split("\n")
			v_rows.each{ |row| rows += row.length / 70 }
			rows = 5 if var == :desc
			s << "</tr><tr><td align=right>#{var}</td><td><textarea rows=#{rows} id=olcv_#{var} cols=70>#{v}</textarea></td><td>::('set Room #{@room.id} #{var} '+el('olcv_#{var}').value-OK)</td><td align=center>#{type}</td>"
		end
		
		echo "#{s}</tr></table>"
		@redit = true
	end
	
	def goto room = nil
		if room
			@room = room
			look_around
			redit if @redit
		else
			s = "main::<p>Aller à :</p><br>"
			
			$room.each_value do |room|
				s << "<p>#{room.id} - ::[goto #{room.id}-#{room}]</p>"
			end
			
			echo s
		end
	end
end