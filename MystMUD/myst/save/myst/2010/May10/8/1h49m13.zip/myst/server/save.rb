﻿
class Save
	@@file = ""
	
	def Save.file
		@@file
	end

	def Save.world
		time = Time.now.to_f
		
		if time - $srv.lastsave < 2
			return nil
		end
		
		begin
			$db = Mysql.real_connect(Db_server, Db_login, Db_pwd, Db_name)
		rescue
			Error.warning "Reconnexion a la base de donnees impossible, le monde n'a pas ete sauvegarde !\nNouvel essai dans 3 minutes"
			if $task then $task.timestamp = time + 300 end
			return
		end
		
		$srv.lastsave = time
		
		puts "\t__Recuperation des donnees de l'ancien monde__\n"
		
		begin
			Save.createBackup
		rescue
			Error.display
			puts "Erreur lors de la creation du backup. Sauvegarde annulee. Nouvel essai dans 3 minutes."
			if $task then $task.timestamp = time + 180 end
			$db.close
			return
		end
		
		print "\t__Sauvegarde de l'instance actuelle du monde__\n"
		
		begin
			$sys['world_time'].value = wtime
			
			queries = []
			
			classes = [:Area, :Body, :Heroe, :Item, :Mob, :Room, :Shop, :Spell, :System, :World]
		
			classes.each do |class_|
				queries << $data[class_].save
			end
			
			print "\n - Execution de #{queries.flatten!.size} requetes SQL... "
			
			# puts "SAUVEGARDE DÉSACTIVÉE"
			
			queries.each do |query|
				$db.query query
				# puts query
			end
			
			queries.clear
		rescue
			Error.display
			puts "Sauvegarde echouee. Nouvel essai dans 3 minutes."
			if $task then $task.timestamp = time + 180 end
			$db.close
			return
		end
		
		print "\n* Termine en #{((Time.now.to_f - time) * 1000).round}ms\n\n"
		
		if $task then $task.timestamp = time + 1200 end
		
		$db.close
	end

	def Save.createBackup
		my = Date::ABBR_MONTHNAMES[Date.today.mon]+Date.today.year.to_s[2..4]
		unless File.exists?(dir = "#{Mud_path}/save/db/#{my}") then Dir.mkdir(dir) end
		unless File.exists?(dir << "/#{Date.today.day}") then Dir.mkdir(dir) end
		tn = "#{(t = Time.now).hour}h#{t.min}m#{t.sec}"
		
		File.open(@@file = "#{dir}/#{tn}.sql", "w+") do |file|
			$data.each_key do |table|
				file.puts "TRUNCATE TABLE #{table};"
				q = $db.query "SELECT * FROM #{table} WHERE 1"
				q.each do |line|
					file.puts "INSERT INTO #{table} VALUES ('#{line.map{|e| e.gsub "'", "''"}.join("','")}', "[0..-3]+");"
				end
			end
		end
	end
	
	def Save.restoreBackup
		if @@file.length == 0 then return end
		
		begin
			$db = Mysql.real_connect(Db_server, Db_login, Db_pwd, Db_name)
			
			data = ""
			File.open(@@file, "r+") do |file|
				loop do
					begin line = file.readline rescue break end
					if line[-4..-2] == "');" or line[0..14] == "TRUNCATE TABLE " then line << "*query_splitter*" end
					data << line
				end
			end

			data.split(";\n*query_splitter*").each do |line|
				$db.query line
			end
		rescue
			Error.display
			puts "Echec de la restauration du backup\n"
		ensure
			$db.close
		end
	end
end
