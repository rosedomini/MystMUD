﻿
class Actor	
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :room
	attr_accessor :level
	attr_reader :hp
	attr_accessor :maxhp, :mp, :maxmp
	attr_accessor :str, :con, :wis, :dex
	attr_accessor :skin, :avatar
	attr_accessor :status
	attr_accessor :target
	attr_accessor :spell, :inv, :equip
	
	include Receive
	
	def new_actor id
		@id = id
		@maxhp = 100000
		@maxmp = 100000
	end
	
	def at_login
		look_around
		show_shortcuts
	end
	
	def cleardiv
		@msg << "main::::_"
	end

	def cmd arg
		$p = self
			
		if arg =~ /^(!)?(\p{L}+) *(.*\S+)? *$/
			$link = $1
			$cmd = $2
			$_ = $3
		else
			return
		end
		
		if $cmd =~ /^[nsoebh]$/
			@room.exits.each_key do |exit_name|
				if $cmd == exit_name.to_s[0]
					move exit_name
					return
				end
			end
			wiz "Vous ne pouvez pas aller par là."
			return
		end
		
		unless $_ or $link
			@room.exits.each_key do |exit_name|
				if $cmd == exit_name.to_s[0, $cmd.length]
					move exit_name
					return
				end
			end
		end
		
		cmd = nil
		
		if $link
			if cmd = $command[$cmd] and cmd.link
				nil
			else
				Log.write :file=>link_errors, :player=>name, :command=>$cmd
				wiz "Lien brisé : l'erreur vient d'être enregistrée.", :red
				return
			end
		elsif $keyboard_cmd =~ /;(#{$cmd}\p{L}*);/
			cmd = $command[$1]
		elsif immortal? and $keyboard_admin_cmd =~ /;(#{$cmd}\p{L}*);/
			cmd = $command[$1]
		else
			wiz "Commande inconnue : #{$cmd}", :red
			return
		end
		
		if @status == :dead and !command.ko
			wiz "Vous n'êtes pas en état de faire celà... vous êtes mort#{e} !"
		elsif mob? and !command.mob
			say_to_master "Je ne peux pas faire ça, maître#{"sse" if @master and @master.female?}."
			return
		elsif @authlevel < cmd.authlevel
			wiz "Vos pouvoirs ne vous permettent pas de faire cela."
		else
			send "check_#{cmd}".to_sym
		end
	end
	
	def e
		"e" if @desc and @desc[:sex] == 2
	end
	
	def hp= new_hp
		if 0 > @hp = new_hp
			killed
			true
		elsif @hp > @maxhp
			@hp = @maxhp
		end
	end
	
	def hp_percent
		(  hp / maxhp * 100 ).round
	end
	
	def immortal?
		@authlevel > 0
	end
	
	def name_for actor
		actor.sees(self) ? name : "quelqu'un"
	end
	
	def nameFor actor
		actor.sees(self) ? name : "Quelqu'un"
	end
	
	def move_to new_room
		@room.actors.delete self
		@room = new_room
		@room.actors << self
	end
	
	def mp= new_mp
		@mp = new_mp > @maxmp ?  @maxmp : new_mp
	end
	
	def sb? actor, maj=true
		if actor.sees self
			name
		else
			"#{maj ? "Q" : "q"}uelqu'un"
		end
	end
	
	def sees a
		true
	end
	
	def retrieve id, number = 1
		if @inv[id] and @inv[id] >= number
			@inv[id] -= number
			ret = @inv[id]
			if @inv[id].zero?
				@inv.delete id
			end
			ret
		end
	end
	
	def up_spell id, points = 1
		if spell = @spell[id]
			spell += points
		else
			@spell[id] = points
		end
	end
	
	def female?
		true if @desc and @desc[:sex] == 2
	end
	
	def xp_gives
		((115 - rand(31))*(@level**2)*(@level+50)*(1+0/3) / 1000).round # replace 0 with @ren
	end
end