﻿
class Mob < Actor
	attr_accessor :lastRepop

	def initialize id
		new_actor id
		
		@lastRepop = 0
		@authlevel = 0
	end
	
	def after_load
		@status = :none
	end

	def echo sth
	end
	
	def heroe?
		false
	end
	
	def inspect
		"$mob[#{@id}]"
	end
	
	def killed
		case rand 3
			when 0 then s = "#{@name} tombe raide mort."
			when 1 then s = "#{@name} expire son dernier souffle."
			else s = "#{@name} s'écroule dans une marre de sang."
		end
		
		room_heroes.each{ |heroe| heroe.wiz s }
		
		body = $body << Body.new($body.new_id).create(@id, 720, @room)
		
		inventory = body.inv
		
		@equip.each_value do |id|
			if inventory[id]
				inventory[id] += 1
			else
				inventory[id] = 1
			end
		end
		
		inventory |= @inv
		
		@room.actors.delete self
		$actor.delete @id
		
		$actor.each_value do |actor|
			if actor.target and actor.target.id == @id 
				actor.target = nil
			end
		end
	end
	
	def mob?
		true
	end
	
	def repop
		mins = wtime()
		if mins - @lastRepop > 120 and $actor[@id].nil?
			@lastRepop = mins
			actor = $actor[@id] = $data[:Mob].copy_from($mob[@id])
			actor.room.actors << actor
		end
	end
	
	def s sth, color=nil
	end
	
	def wiz sth, color=nil
	end
end