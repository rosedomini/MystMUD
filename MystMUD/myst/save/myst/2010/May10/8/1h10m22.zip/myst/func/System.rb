﻿
class System
	
	attr_accessor :id, :name
	attr_accessor :value
	
	def initialize id
		@id = id
	end
end
