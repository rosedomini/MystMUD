﻿
# fonctions globales

def wiz sth, color=nil
	if color
		$p.msg << "box::<font color=#{color}>#{sth}</font>::_"
	else
		$p.msg << "box::#{sth}::_"
	end
end

def echo sth, color=nil
	if color
		$p.msg << "<font color=#{color}>#{sth}</font>::_"
	else
		$p.msg << "#{sth}::_"
	end
end