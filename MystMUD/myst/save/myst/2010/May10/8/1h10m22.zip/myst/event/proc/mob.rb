﻿
# def ($mob[1000001]).onmove room
	
# end