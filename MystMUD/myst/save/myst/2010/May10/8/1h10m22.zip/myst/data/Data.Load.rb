﻿
class Data::Load
	def self.array value
		a = eval value
		if a.is_a? Array
			a
		else
			{}
		end
	end
	
	def self.bool value
		value.to_b
	end
	
	def self.equipement value
		equip = eval value
		if equip.is_a? Hash
			equip
		else
			{}
		end
	end
	
	def self.hash value
		h = eval value
		if h.is_a? Hash
			h
		else
			{}
		end
	end
	
	def self.help value
		value.gsub(/\n/, "<br>")
	end
	
	def self.int value
		value.to_i
	end
	
	def self.inventory value
		inv = eval value
		if inv.is_a? Hash
			inv
		else
			{}
		end
	end
	
	def self.nil value
		nil
	end
	
	def self.sym value
		value.to_sym
	end
	
	def self.shortcut value
		s = eval value
		if s.is_a? Array and s[0].is_a? Array and s[1].is_a? Array and s.size==2 and s[0].size==10 and s[1].size==10
			s
		else
			$default_shortcuts
		end
	end
	
	def self.string value
		value
	end
end