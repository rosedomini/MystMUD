﻿# Vérification des arguments pour les commandes admin

class Actor
	def check_clone
		if ~/^(\p{L}+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				Cmd.clone $1, $2.to_i
			else
				Error.olc_class
			end
		elsif ~/^(\p{L}+) (\p{L}+)$/
			if $olc[$1] and $classhash[$1][$2]
				Cmd.clone $1, $2
			else
				Error.olc_class
			end
		else
			Cmd.help "clone"
		end
	end
	
	def check_dump
		begin
			if $_
				Cmd.dump $_
			else
				Cmd.dump
			end
		rescue
			wiz "Erreur : #{$!}"
		end
	end

	def check_edit
		if ~/^(\p{L}+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				Cmd.edit $1, $classhash[$1][$2.to_i]
			else
				Error.olc_class
			end
		elsif ~/^(\p{L}+) (\p{L}+)$/
			if $olc[$1] and $classhash[$1][$2]
				Cmd.edit $1, $classhash[$1][$2]
			else
				Error.olc_class
			end
		else
			Cmd.help "clone"
		end
	end

	def check_force
		if ~/^(\p{L}+) to (.+)$/
			room_actors.each do |actor|
				if actor.name.contains $1
					actor.cmd "!#{$2}"
					return
				end
			end
			echo "Cette personne n'est pas là"
		else
			Cmd.help "force"
		end
	end

	def check_giveXp
		if ~/^([\p{L} ]+) (\d+)$/
			if (amount = $2) > 0
				$guest.each do |guest|
					if heroe = guest.h and heroe.name.same $1
						Cmd.giveXp heroe, amount
						return
					end
				end
				wiz "Cette personne n'existe pas."
			else
				wiz "l'expérience acquise ne peut pas être retirée !"
			end
		else
			Cmd.help "giveXp"
		end
	end

	def check_goto
		if $_ and room = $room[$_.to_i]
			goto room
		else
			goto
		end
	end

	def check_help
		if $_ and $command[$_]
			Cmd.help $command[$_]
		else
			Cmd.help nil
		end
	end
	
	def check_include
		Cmd.include $_
	end

	def check_lvUp
		unless $_
			Cmd.help "lvUp"
			return
		end
		$guest.each do |guest|
			if heroe = guest.h and heroe.name.same $1
				Cmd.lvUp heroe
				return
			end
		end
		wiz "Cette personne n'existe pas."
	end
   
	def check_olc
		if $_.nil?
			Cmd.olc
		elsif $olc[$_]
			Cmd.olc $_
		else
			Error.olc_class
		end
	end

	def check_olcShow
		if ~/^(\p{L}+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				Cmd.olcShow $1, $classhash[$1][$2.to_i]
			else
				Error.olc_class
			end
		elsif ~/^(\p{L}+) (\p{L}+)$/
			if $olc[$1] and $classhash[$1][$2]
				Cmd.olcShow $1, $classhash[$1][$2]
			else
				Error.olc_class
			end
		else
			Cmd.help "olcShow"
		end
	end
	
	def check_rcreate
		if ~/^[bonseh]$/
			rcreate $_.to_sym
		else
			wiz "Les directions possibles sont n-s, o-e, h-b"
		end
	end

	def check_redit
		redit($_ == "close")
	end

	def check_ruby
		if $_
			Cmd.ruby CGI.unescapeHTML $_
		else
			Cmd.ruby
		end
	end

	def check_set
		if ~/^(\p{L}+) (\p{L}+) (\p{L}+) (.+)$/
			if a = $classhash[cls = $1] and $olc[cls].find_index(var = $3)
				if o = a[$2.to_i] or o = a[$2]
					Cmd.set cls, o, var, CGI.unescapeHTML($4)
				end
			else
				Error.olc_class
			end
		else
			Cmd.help "set"
		end
	end

	def check_summonItem
		if ~/^(\d+) (\d+)$/
			if item = $item[$1.to_i] and (number = $2.to_i) > 0
				Cmd.summonItem item, number
			else
				wiz "Cet objet n'existe pas."
			end
		else
			Cmd.help "summonItem"
		end
	end
end