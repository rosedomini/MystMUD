﻿
# add values in SQL table order
	 
class Dat
	def self.define
		Dat.Avatar
		Dat.Body
		Dat.Command
		Dat.Heroe
		Dat.Item
		Dat.Mob
		Dat.Room
		Dat.Shop
		Dat.Skin
		Dat.Spell
		Dat.System
		Dat.World
		Dat.Zone
		
		Dat.OLC :Body, :Heroe, :Item, :Mob, :Room, :Shop, :World, :Zone
		
		$clonable = [:Item]
	end
	
	def self.OLC *classnames
		classnames.each do |classname|
			
			a = $olc[classname.to_s] = []
			
			(data = $data[classname]).data.each do |var|
				a << var[:name].to_s
			end
			
			$classhash[classname.to_s] = data.hash
		end
	end
	
	def self.Avatar
	
		data = $data[:Avatar] = Dat.new(:Avatar, $avatar, Avatar)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :source,
			:load	=> :string
		}]
	end
	
	def self.Body
		data = $data[:Body] = Dat.new(:Body, $body, Body)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :aid,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :expire,
			:load	=> :int
		},{
			:name	=> :inv,
			:load	=> :inventory,
			:change=> :inventory
		},{
			:name	=> :room,
			:load	=> :int,
			:save	=> :room,
			:change=> :room
		}]
	end
	
	def self.Command
		data = $data[:Command] = Dat.new(:Command, $command, Command)
		
		data.make [{
			:name	=> :id,
			:load	=> :string
		},{
			:name	=> :name,
			:load	=> :string,
		},{
			:name	=> :type,
			:load	=> :sym,
			:save	=> :sym_to_s
		},{
			:name	=> :mob,
			:load	=> :bool
		},{
			:name	=> :ko,
			:load	=> :bool
		},{
			:name	=> :authlevel,
			:load	=> :int
		},{
			:name	=> :keyboard,
			:load	=> :bool
		},{
			:name	=> :link,
			:load	=> :bool
		},{
			:name	=> :syntax,
			:load	=> :string
		},{
			:name	=> :help,
			:load	=> :help
		}]
	end
	
	def self.Heroe
		data = $data[:Heroe] = Dat.new(:Heroe, $heroe, Heroe)
		
		data.make [{
			:name	=> :id,
			:load	=> :int,
			:default	=> 0
		},{
			:name	=> :name,
			:load	=> :string,
			:default	=> 1
		},{
			:name	=> :password,
			:load	=> :string,
			:default	=> 2
		},{
			:name	=> :authlevel,
			:load	=> :int,
			:default	=> "0"
		},{
			:name	=> :desc,
			:load	=> :hash,
			:save	=> :inspect,
			:default	=> "{}"
		},{
			:name	=> :room,
			:load	=> :int,
			:save	=> :room,
			:change=> :room,
			:default	=> "1"
		},{
			:name	=> :xp,
			:load	=> :int,
			:default	=> "0"
		},{
			:name	=> :level,
			:load	=> :int,
			:default	=> "1"
		},{
			:name	=> :hp,
			:load	=> :int,
			:default	=> "20"
		},{
			:name	=> :maxhp,
			:load	=> :int,
			:default	=> "20"
		},{
			:name	=> :mp,
			:load	=> :int,
			:default	=> "20"
		},{
			:name	=> :maxmp,
			:load	=> :int,
			:default	=> "20"
		},{
			:name	=> :str,
			:load	=> :int,
			:default	=> "5"
		},{
			:name	=> :con,
			:load	=> :int,
			:default	=> "5"
		},{
			:name	=> :wis,
			:load	=> :int,
			:default	=> "5"
		},{
			:name	=> :dex,
			:load	=> :int,
			:default	=> "5"
		},{
			:name	=> :skin,
			:load	=> :string,
			:default	=> "default"
		},{
			:name	=> :avatar,
			:load	=> :string,
			:default	=> "default"
		},{
			:name	=> :target,
			:load	=> :nil,
			:save	=> :zero,
			:default	=> "nil"
		},{
			:name	=> :spell,
			:load	=> :hash,
			:default	=> "{}"
		},{
			:name	=> :inv,
			:load	=> :inventory,
			:change=> :inventory,
			:default	=> "{}"
		},{
			:name	=> :equip,
			:load	=> :equipement,
			:change=> :equipement,
			:default	=> "{}"
		},{
			:name	=> :shortcut,
			:load	=> :shortcut,
			:save	=> :inspect,
			:default	=> :default_shortcuts
		},{
			:name	=> :hunger,
			:load	=> :int,
			:default	=> "0"
		}]
	end
	
	def self.Item
		data = $data[:Item] = Dat.new(:Item, $item, Item)
		
		data.make [{
			:name	=> :id,
			:load	=> :int,
			:default	=> 0
		},{
			:name	=> :name,
			:load	=> :string,
			:default	=> 1,
		},{
			:name	=> :type,
			:load	=> :sym,
			:save	=> :sym_to_s,
			:default	=> "divers",
		},{
			:name	=> :weight,
			:load	=> :int,
			:default	=> "1"
		},{
			:name	=> :wearon,
			:load	=> :array,
			:default	=> "[]",
		},{
			:name	=> :desc,
			:load	=> :string,
			:default	=> "",
		},{
			:name	=> :stats,
			:load	=> :hash,
			:default	=> "{}",
		},{
			:name	=> :power,
			:load	=> :hash,
			:default	=> "{}",
		},{
			:name	=> :required,
			:load	=> :hash,
			:default	=> "{}",
		},{
			:name	=> :value,
			:load	=> :int,
			:default	=> "1"
		}]
	end
	
	def self.Mob
		data = $data[:Mob] = Dat.new(:Mob, $mob, Mob)
		
		data.make [{
			:name	=> :id,
			:load	=> :int,
			:default	=> 0
		},{
			:name	=> :name,
			:load	=> :string,
			:default	=> "une créature mystérieuse"
		},{
			:name	=> :room,
			:load	=> :int,
			:save	=> :room,
			:change=> :room,
			:default	=> "1"
		},{
			:name	=> :level,
			:load	=> :int,
			:default	=> "1"
		},{
			:name	=> :hp,
			:load	=> :int,
			:default	=> "10"
		},{
			:name	=> :maxhp,
			:load	=> :int,
			:default	=> "10"
		},{
			:name	=> :mp,
			:load	=> :int,
			:default	=> "10"
		},{
			:name	=> :maxmp,
			:load	=> :int,
			:default	=> "10"
		},{
			:name	=> :str,
			:load	=> :int,
			:default	=> "10"
		},{
			:name	=> :con,
			:load	=> :int,
			:default	=> "10"
		},{
			:name	=> :wis,
			:load	=> :int,
			:default	=> "10"
		},{
			:name	=> :dex,
			:load	=> :int,
			:default	=> "10"
		},{
			:name	=> :skin,
			:load	=> :string,
			:default	=> "mob/default"
		},{
			:name	=> :avatar,
			:load	=> :string,
			:default	=> "mob/default"
		},{
			:name	=> :target,
			:load	=> :nil,
			:save	=> :zero
		},{
			:name	=> :spell,
			:load	=> :hash,
			:default	=> "{}"
		},{
			:name	=> :inv,
			:load	=> :inventory,
			:change=> :inventory,
			:default	=> "{}"
		},{
			:name	=> :equip,
			:load	=> :equipement,
			:change=> :equipement,
			:default	=> "{}"
		}]
	end
	
	def self.Room
		data = $data[:Room] = Dat.new(:Room, $room, Room)
		
		data.make [{
			:name	=> :id,
			:load	=> :int,
			:default	=> 0
		},{
			:name	=> :name,
			:load	=> :string,
			:default	=> "Nouvelle salle"
		},{
			:name	=> :desc,
			:load	=> :string,
			:default	=> "Cette salle est bien éclairée et sent bon la peinture fraîche."
		},{
			:name	=> :x,
			:load	=> :int,
			:default	=> "0"
		},{
			:name	=> :y,
			:load	=> :int,
			:default	=> "0"
		},{
			:name	=> :z,
			:load	=> :int,
			:default	=> "-1"
		},{
			:name	=> :inv,
			:load	=> :inventory,
			:change=> :inventory,
			:default	=> "{}"
		},{
			:name	=> :items,
			:load	=> :inventory,
			:change=> :inventory,
			:default	=> "{}"
		},{
			:name	=> :exits,
			:load	=> :hash,
			:save	=> :exits,
			:change=> :exits,
			:set	=> :exits,
			:default	=> "{}"
		}]
	end
	
	def self.Shop
		data = $data[:Shop] = Dat.new(:Shop, $shop, Shop)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :keeper,
			:load	=> :int
		},{
			:name	=> :room,
			:load	=> :int,
			:save	=> :room,
			:change=> :room
		},{
			:name	=> :inv,
			:load	=> :inventory,
			:change=> :inventory
		}]
	end
	
	def self.Skin
		data = $data[:Skin] = Dat.new(:Skin, $skin, Skin)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :source,
			:load	=> :string
		}]
	end
	
	def self.Spell
		data = $data[:Spell] = Dat.new(:Spell, $spell, Spell)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :desc,
			:load	=> :string
		},{
			:name	=> :min_cost,
			:load	=> :int
		},{
			:name	=> :max_cost,
			:load	=> :int
		},{
			:name	=> :school,
			:load	=> :string
		},{
			:name	=> :func,
			:load	=> :sym,
			:save	=> :sym_to_s
		}]
	end
	
	def self.System
		data = $data[:System] = Dat.new(:System, $sys, System)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :value,
			:load	=> :eval,
			:save	=> :inspect
		}]
	end
	
	def self.World
		data = $data[:World] = Dat.new(:World, $world, World)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :zones,
			:load	=> :array,
			:save	=> :inspect
		}]
	end
	
	def self.Zone
		data = $data[:Zone] = Dat.new(:Zone, $zone, Zone)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :x1,
			:load	=> :int
		},{
			:name	=> :y1,
			:load	=> :int
		},{
			:name	=> :z1,
			:load	=> :int
		},{
			:name	=> :x2,
			:load	=> :int
		},{
			:name	=> :y2,
			:load	=> :int
		},{
			:name	=> :z2,
			:load	=> :int
		}]
	end
end
