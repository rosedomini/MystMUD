﻿
class Area
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :x1, :y1, :z1, :x2, :y2, :z2
	
	def initialize id
		@id = id
	end
end