﻿
class Actor
	def room_actors
		@room.actors.select{ |actor| actor != self }
	end
	
	def room_heroes
		@room.actors.select{ |actor| actor.heroe? and actor != self }
	end
	
	def seen_bodies
		# @room.bodies.select{ |body| sees body }
		@room.bodies
	end
	
	def seen_heroes
		@room.actors.select{ |actor| actor.heroe? and sees actor and actor != self }
	end
	
	def seen_actors
		@room.actors.select{ |actor| sees actor and actor != self }
	end
	
	def witness_heroes
		@room.actors.select{ |actor| actor.heroe? and actor.sees self and actor != self }
	end
	
	def witnesses
		@room.actors.select{ |actor| actor.sees self and actor != self }
	end
	
	def area_heroes
		area = @room.area
		$actor.collect{ |id, actor| actor if actor.heroe? and actor.room.area == area and actor != self }
	end
	
	def area_actors
		area = @room.area
		$actor.collect{ |id, actor| actor if actor.room.area == area and actor != self }
	end
end