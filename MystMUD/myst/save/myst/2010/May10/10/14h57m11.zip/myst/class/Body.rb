﻿
class Body
	attr_accessor :id, :aid, :actor, :name
	alias to_s name
	attr_accessor :room
	attr_accessor :expire
	attr_accessor :inv
	
	def create aid, expire, room
		@aid = aid
		
		if @actor = $actor[aid]
			n = @actor.name
		else
			n = (@actor = $mob[aid]).name
		end
		
		@name = (n[0..2] == 'un') ? "#{n} mort#{(n[2] == "e") ? "e" : ""}" : "le corps d'#{n}"
		
		@expire = wtime + expire
		@inv = {}
		@room = room
		@room.bodies << self
		
		self
	end
	
	def initialize id
		@id = id
	end
	
	def after_load
		@actor = $actor[@aid]
	end
	
	def move_to new_room
		@room.bodies.delete self
		@room = new_room
		@room.bodies << self
	end
	
	def over
		@room.inv |= @inv
		
		@room.heroes.each do |heroe|
			heroe.wiz "#{@name} se désagrège."
		end
		
		@room.bodies.delete self
		$body.delete @id
	end
end
