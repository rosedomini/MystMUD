﻿
class Room
	attr_accessor :id, :name, :desc
	alias to_s name
	attr_accessor :x, :y, :z, :area
	attr_accessor :inv, :items # items est la liste d'objets qui sont par défaut dans cette salle
	attr_accessor :exits
	
	# à mettre à jour à chaque déplacement, connexion ou déconnexion d'un Joueur ou d'une Créature
	attr_accessor :actors, :bodies
	
	include Receive # permet de recevoir des objects
	
	def initialize id
		@id = id
	end
	
	# permet de mettre à jour les listes actors ou bodies
	def << object
		if object.kind_of? Actor
			@actors << object
		elsif object.kink_of? Body
			@bodies << Body
		else
			$! = "Room#<< only accepts Actors or Bodies."
			Error.display
		end
	end
	
	# permet de mettre à jour les listes actors ou bodies
	def >> object
		if object.kind_of? Actor
			@actors.delete object
		elsif object.kink_of? Body
			@bodies.delete Body
		else
			$! = "Room#>> only accepts Actors or Bodies."
			Error.display
		end
	end
	
	# crée une nouvelle salle à l'emplacement voulu
	def self.create_to x, y, z
		room = $data[:Room].create
		room.x, room.y, room.z = x, y, z
		room.actors, room.bodies = [], []
		$area.each_value do |a|
			if x>=a.x1 and x<=a.x2 and y>=a.y1 and y<=a.y2 and z>=a.z1 and z<=a.z2
				room.area = a; break
			end
		end
		room
	end
	
	def after_load
		$area.each_value do |a|
			if @x>=a.x1 and @x<=a.x2 and @y>=a.y1 and @y<=a.y2 and @z>=a.z1 and @z<=a.z2
				@area = a; break
			end
		end
		@actors = []
		@bodies = $body.collect{|id, body| body if body.room == self}
	end
	
	def heroes
		@actors.select{|actor| actor.heroe?}
	end
	
	def inspect
		"$room[#{@id}]"
	end
	
	# réapparition des objects par défaut de la salle s'ils ont disparus
	def item_repop
		@items.each do |item, number|
			if num = @inv[item]
				@inv[item] = number if num < number
			else
				@inv[item] = number
			end
		end
	end
end
