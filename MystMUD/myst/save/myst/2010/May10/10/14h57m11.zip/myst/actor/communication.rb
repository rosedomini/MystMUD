﻿
class Actor
	def chat sth
		$actor.wiz "#{@name} : #{sth}", :blue
	end
	
	def pray sth
		$pray_history << sth
		wiz "Message reçu !"
		$actor.select{|x| x.immortal? }.wiz "#{@name} prie : #{sth}", :yellow
	end
	
	def say sth
		@room.actors.each do |x|
			x.wiz "#{x==self ? "Vous dites" : "#{sb? x} dit"} : #{sth}", :green
		end
	end
	
	def shout sth
		wiz "Vous criez : #{sth}", Lightblue
		$actor.no(self).wiz "#{@name} crie : #{sth}", Lightblue
	end
	
	def tell heroe, sth
		heroe.wiz "#{@name} vous dit : #{sth}", :pink
		wiz "Vous dites à #{heroe} : #{sth}", :pink
	end
end