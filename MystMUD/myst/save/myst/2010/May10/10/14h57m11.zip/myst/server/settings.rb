﻿
Remote = (__FILE__ == "/m/myst/server/settings.rb")

if Remote
	Website_directory = "/m/mud"
	Include_path = "/m/myst"
	Cache_dir = "/m/cache/cache"
	Hostname = "62.193.219.166"
	Mysql_gem = "module/mysql_api.so"
	Db_login = "admin"
	Mud_path = "/m"
else
	Website_directory = "c:/var/mud"
	Include_path = "c:/var/myst"
	Cache_dir = "c:/var/cache/cache"
	Hostname = "127.0.0.1"
	Mysql_gem = "mysql"
	Db_login = "root"
	Mud_path = "c:/var"
end

Db_server =	"localhost"
Db_pwd = "vesper007"
Db_name = "myst"
Port = 6022
Max_clients = 20
FloodLimit = 8