﻿
# Vérification des arguments pour chaque commande

class Actor
	#check_affections@gestion
	
	def check_aide
		if $x
			if command = $command[$x] and command.keyboard and command.authlevel <= @authlevel
				cmd_aide $x
			elsif $x == 'move' or $x == 'shortcuts' then cmd_aide $x
			else echo 'main::Cette commande n\'existe pas.' end
		else cmd_aide end
	end
	
	def check_cast
		if $x =~ /^(\d+ *)?([\w ,]+)$/
			if $1 then power = $1.to_i else power = 100 end
			power = 1 if power.zero?
			
			if (name = $2) =~ /^([\w ]+)(( +to +)|(, *))(\D+)( *\d+)?$/
				unless target = seen_actors.seek($5, $6)
					wiz 'Je ne vois pas cette cible.'
					return
				end
				name = $1
			else target = nil end
			
			@spell.each do |spell, pow|
				if spell.name.contains name
					power = pow if power > pow
					cast spell, power, target
					return
				end
			end
			wiz 'Je ne connais pas ce sort.'
		else
			cmd_aide 'cast'
		end
	end
	
	def check_chat
		if $x then chat $x else cmd_aide 'chat' end
	end
	
	def check_drag
		if $x =~ /^(\D+)( *\d+)?(( +to +)|(, *))([\w-]+)$/ # drag body [number] to direction
			if body = seen_bodies.seek($1, $2)
				@room.exits.each_key do |exit_name|
					if $6 == exit_name.to_s[0, $6.length]
						drag body, exit_name
						return
					end
				end
				wiz 'Vous ne pouvez pas aller par là.'	
			else wiz 'Je ne vois pas ce corps.' end
		else cmd_aide 'drag' end
	end

	def check_drop
		if $x == '*' then @inv.each{|item, number| drop item, number}
		elsif (match = $x =~ /^(\*|\d+) *([\w ]+)$/) or $x
			needle = match ? $2 : $x
			@inv.each do |item, number|
				if item.name.contains needle
					num = match ? ($1 == '*' ? number : $1.to_i) : 1
					if num.zero? then @inv.delete item
					else
						drop item, num
						return
					end
				end
			end
			wiz 'Je ne trouve pas cet objet.'
		else cmd_aide 'drop' end
	end
	
	def check_eat
		if $x
			msg = nil
			@inv.each do |item, number|
				if item.name.contains $x
					if item.type == :nourriture and (item.stats[:rassasiment] or item.power[:eat])
						eat item
					else wiz 'Un ogre affamé n\'oserait pas !' end
					return
				end
			end
			wiz 'Je ne trouve pas cet objet.'
		else cmd_aide 'eat' end
	end

	# check_equipement@gestion

	def check_examine
		if $x =~ /^(\D+)( *\d+)?$/
			if body = seen_bodies.seek($1, $2) then examine body
			elsif item = @inv.keys.seek($1, $2) then examine item
			else wiz 'Vous ne possédez pas cet objet et n\'apercevez pas ce corps.' end
		else cmd_aide 'examine' end
	end

	def check_get
		if $x == '*' # get *
			if @room.inv.empty? then wiz 'Il n\'y a rien à prendre ici.'
			else @room.inv.each{|item, number| get item, number} end
		elsif $x =~ /^(\*|\d+) *([\w ]+)(( +from +)|(, *))(\D+)( *\d+)?$/ # get [number] sth from body [no]
			unless $2 or $1 == '*' then return cmd_aide 'get' end
			
			if body = seen_bodies.seek($6, $7)
				if $1
					body.inv.each do |item, number|
						if item.name.contains $2
							to_pick = $1 ? ($1 == '*' ? number : $1.to_i) : 1
							get_from body, item, to_pick
							return
						end
					end
				else
					if body.inv.empty? then wiz 'Vous n\'y trouvez rien à prendre.'
					else body.inv.each{|item, number| get_from body, item, number} end
					return
				end
				wiz 'Je ne trouve pas cet objet.'
			else wiz 'Ce corps n\'est pas là.' end
		elsif $x =~ /^(\*|\d+) *([\w ]+)$/ # get [number] sth
			@room.inv.each do |item, number|
				if item.name.contains $2
					number = $1 ? ($1 == '*' ? number : $1.to_i) : 1
					get item, number
					return
				end
			end
			wiz 'Je ne trouve pas cet objet.'
		else cmd_aide 'get' end
	end

	def check_give
		if $x =~ /^(\*|\d+) *([\w ]+)(( +to +)|(, *))(\D+)( *\d+)?$/
			if actor = seen_actors.seek($6, $7)
				@inv.each do |item, number|
					if item.name.contains $2
						num = $1 ? ($1 == '*' ? number : $1.to_i) : 1
						give actor, item, num
						return
					end
				end
				wiz 'Je ne trouve pas cet objet.'
			else wiz 'Je ne vois pas cette personne.' end
		else cmd_aide 'give' end
	end

	# check_inventory@gestion

	def check_kill
		if $x =~ /^(\D+)( *\d+)?$/
			if actor = seen_actors.seek($1, $2) then kill actor
			else wiz 'Je ne le vois pas.' end
		else cmd_aide 'kill' end
	end

	def check_look
		if $x.nil? then look_around
		elsif $x =~ /^(\D+)( *\d+)?$/
			if actor = seen_actors.seek($1, $2) then look_actor actor
			elsif @name.contains $x then look_actor self
			else wiz 'Cette personne n\'est pas là.' end
		else cmd_aide 'look' end
	end

	def check_option
		cmd_option $x
	end

	def check_pray
		if $x then pray $x
		else
			wiz 'Vous n\'avez pas entré de message. Vous pouvez l\'écrire là-haut.'
			echo 'main::<u>Faire une demande ou signaler un problème quelconque :</u><br><br><textarea id=pray style=width:300px;height:100px></textarea><br>::("pray "+pray_replace(el("pray").value)-Envoyer)'
		end
	end

	def check_remove
		if $x =~ /^(\D+)( *\d+)?$/
			if item = @equip.values.seek($1, $2) then remove @equip.key item
			else wiz 'Vous ne portez pas cet objet.' end
		else cmd_aide 'remove' end
	end
	
	def check_reply
		if $x
			if @last_teller
				if @last_teller.online? then reply $x
				else
					wiz "#{@last_teller} n'est plus là.", :red
					@last_teller = nil
				end
			else
				wiz 'Répondre... mais à qui ? Utilisez la commande tell si personne ne vous a encore parlé.'
			end
		else cmd_aide 'reply' end
	end

	def check_say
		if $x then say $x else cmd_aide 'say' end
	end
	
	# check_score@gestion
	
	def check_spell
		if $x
			$spell.each_value do |spell|
				if spell.name.contains $x
					cmd_spell spell
					return
				end
			end
			wiz 'Ce sort n\'existe pas.'
		else cmd_aide 'spell' end
	end
	
	# check spells@gestion
	
	def check_selectAvatar!
		if $x and avatar = $avatar[$x]
			@avatar = avatar.source
			echo 'top::_box::<b>Avatar mis à jour.</b>'
		end
	end

	def check_selectSkin!
		if $x and skin = $skin[$x]
			echo "top::_skin::#{@skin = skin.source}::_box::<b>Skin mis à jour.</b>"
		end
	end
	
	def check_special!
		# unused
	end
	
	def check_shortcut!
		if $x =~ /^(\w+) (\d) ?(.+)?$/ and (no = $2.to_i) >= 0 and no < 10
			cmd_shortcut $1, no, $3
		else Error.cmd_hack 'shortcut' end
	end

	def check_shout
		if $x then shout $x else cmd_aide 'shout' end
	end

	def check_tell
		if $x =~ /^(\w+) (.+)$/
			sth = $2
			if ";#{$actor.collect{|k, x| "#{k}#{x}"}*';'};" =~ /;(\d+)#{$1}\w*;/i
				tell $actor[$1.to_i], sth
			else
				wiz 'Cette personne n\'existe pas.'
			end
		else
			cmd_aide 'tell'
		end
	end

	#check_time@divers
	
	def check_wear
		if $x =~ /^(\D+)( *\d+)?$/
			if item = @inv.keys.seek($1, $2) then wear item
			else wiz 'Vous ne possédez pas ou plus cet objet.' end
		else cmd_aide 'wear' end
	end

	def check_who
		if $x and $x =~ /\*/ then cmd_who true else cmd_who end
	end
end