
class Log
	def self.link_error
		file = Log.open 'link_errors'
		file.puts "#{Log.time} #{$p} tried to execute `!#{$cmd} #{$x}`"
		file.close
	end
	
	def self.cmd_error error, arg, heroe = nil
		file = Log.open 'cmd_errors'
		file.puts "#{Log.time} #{heroe or 'A guest'} sent `#{arg}` resulting in:\n#{error}\n*******"
		file.close
	end
	
	def self.open name
		File.open "#{Logpath}/#{name}.log", 'a'
	end
	
	def self.time
		now = Time.now
		"#{now} =>"
	end
end