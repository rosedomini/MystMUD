﻿
class Dat
	attr_accessor :name
	attr_accessor :hash
	attr_accessor :class
	attr_accessor :table
	attr_accessor :data
	
	def initialize name, hash, class_, table = nil
		@name = name
		@class = class_
		@table = table ? table : name
		@hash = hash
		@data = []
		@queries = []
	end
	
	def add var
		var[:set] = var[:load] unless var[:set]
		var[:save] = var[:load] unless var[:save]
		var[:olc] = var[:save] unless var[:olc]
		var[:clone] = var[:load] unless var[:clone]
		@data << var
	end
	
	def change
		print "#{@name}, "
		
		hash.each_value do |object|
			@data.each do |var|
				name, change_method = var[:name], var[:change]
				
				if change_method
					object.instance_variable_set "@#{name}", Data::Change.send(change_method, object.send(name))
				end
			end
			
			object.after_load if object.respond_to? :after_load
		end
	end
	
	def copy_from object
		new_object = @class.new(object.id)
		
		@data.each do |var|
			new_var = Data::Clone.send var[:clone], object.send(var[:name])
			new_object.instance_variable_set "@#{var[:name]}", new_var
		end
		
		return new_object
	end
	
	def create
		values = {}
		
		@data.each do |var|
			name, load_method, default_value = var[:name], var[:load], var[:default]
			if default_value
				values[name] = Data::Load.send load_method, default_value
			end
		end
		
		object = @class.new(@hash.new_id)
		
		values.each do |name, value|
			object.instance_variable_set "@#{name}", value
		end
		
		object.id = @hash.new_id
		@hash << object
		return object
	end
	
	def from_olc var, value
		@data.each do |data|
			if data[:name] == var.to_sym
				return Data::LoadOLC.send(data[:set], value)
			end
		end
		return 'nil'
	end
	
	def load
		print "#{@name}, "
		
		q = $db.query "SELECT * FROM #{@table} WHERE 1"
		
		q.each_hash do |d|
			values = {}
			
			@data.each do |var|
				name, load_method = var[:name], var[:load]
				values[name] = Data::Load.send load_method, d[name.to_s]
			end
			
			if @name == :System or @name == :Command # exeptions: $sys and $command sort by name
				id = values[:name]
			else
				id = values[:id]
			end
			
			object = @hash[id] = @class.new(id)
			
			values.each do |name, value|
				object.instance_variable_set "@#{name}", value
			end
		end
	end
	
	def make to_add
		to_add.each do |var_data| add var_data end
	end
	
	def save
		print "#{@name}, "
		
		@queries.clear
		@queries << "TRUNCATE table #{@table}"
	
		@hash.each do |id, object|
			query = "INSERT INTO #{@table} VALUES("
		
			@data.each do |var|
				name, save_method = var[:name], var[:save]
				
				value = object.send name
				
				query << "'#{Data::Save.send(save_method, value).gsub "'", "''"}',"
			end
			
			@queries << "#{query[0..-2]})"
		end
		
		return @queries
	end
	
	def to_olc var, value
		@data.each do |data|
			return Data::Save.send(data[:olc], value), data[:olc] if data[:name] == var
		end
		"Error: #{__FILE__}:#{__LINE__}"
	end
end
