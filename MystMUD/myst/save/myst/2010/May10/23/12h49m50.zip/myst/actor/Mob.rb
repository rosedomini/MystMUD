﻿
class Mob < Actor
	attr_accessor :lastRepop

	def initialize id
		new_actor id
		
		@lastRepop = 0
		@authlevel = 0
	end
	
	def after_load
		@status = :none
	end

	def echo sth
	end
	
	def heroe?
		false
	end
	
	def inspect
		if $mob.key self
			"$mob[#{@id}]"
		else
			"$mob[#{@id}].clone"
		end
	end
	
	def killed actor = nil		
		case rand 3
			when 0 then s = "#{@name} tombe raide mort."
			when 1 then s = "#{@name} expire son dernier souffle."
			else s = "#{@name} s'écroule dans une marre de sang."
		end
		
		room_heroes.each{ |heroe| heroe.wiz s }
		actor.add_xp xp_gives if actor and actor.heroe?
		
		body = $body << Body.new($body.new_id).create(@id, 720, @room)
		inventory = body.inv = @inv
		
		@equip.each_value do |id|
			if inventory[id]
				inventory[id] += 1
			else
				inventory[id] = 1
			end
		end
		
		@room >> self
		$actor.delete @id
		@target = nil
		
		$actor.each_value{|x| x.target = nil if x.target == self}
	end
	
	def mob?
		true
	end
	
	def online?
		self != $mob[@id]
	end
	
	def repop
		mins = wtime()
		if mins - @lastRepop > 120 and $actor[@id].nil?
			@lastRepop = mins
			actor = $actor[@id] = $data[:Mob].copy_from($mob[@id])
			actor.room << actor
			actor.room.heroes.wiz "#{actor} arrive de nulle part."
		end
	end
	
	def s sth, color=nil
	end
	
	def wiz sth, color=nil
		# if @master
			# @master.wiz "&gt; #{sth.gsub "<br>", "<br>&gt; "}"
		# end
	end
end