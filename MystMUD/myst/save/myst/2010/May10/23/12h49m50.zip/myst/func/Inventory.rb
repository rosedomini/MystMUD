﻿
class Inventory < Hash
	def initialize hash = {}
		hash.each do |key, value| store key, value end
	end
	
	def << items
		if items.is_a? Hash
			items.each do |key, value|
				if self[key]
					self[key] += value
				else
					store key, value
				end
			end
		elsif items.is_a? Fixnum
			self[items] = if self[items] then self[items] + 1 else 1 end
		else
			raise ArgumentError
		end
		self
	end
	
	def add item, number
		self[item] = if self[item] then self[item] + number else number end
	end
	
	def >> item
		if self[item]
			if self[item] == 1 then delete item else self[item] -= 1 end
		end
	end
	
	def give item, number, inv
		if number >= self[item]
			inv.add item, self[item]
			delete item
		else
			self[item] -= number
			inv.add item, number
		end
	end
end