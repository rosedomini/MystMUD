﻿
# fonctions des commandes admin diverses

class Cmd
	def self.dump var = nil
		unless var
			wiz "Affichage des envois #{($dump = $dump ? false : true) ? "" : "dés"}activé."
		else
			echo "main::<pre>#{CGI.escapeHTML(eval(var).inspect.gsub(/::/, ": :"))}</pre>"
		end
	end
	
	def self.include path
		path << '.rb' if path[-3..-1] != '.rb'
		begin
			load path
			wiz "Fichier chargé."
		rescue LoadError
			wiz "Erreur : #{$!}"
		end
	end
end
