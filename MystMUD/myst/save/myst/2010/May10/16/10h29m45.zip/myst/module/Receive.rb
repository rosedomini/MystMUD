﻿
module Receive
	def receive item, number = 1
		if @inv[item]
			@inv[item] += number
		else
			@inv[item] = number
		end
	end
end