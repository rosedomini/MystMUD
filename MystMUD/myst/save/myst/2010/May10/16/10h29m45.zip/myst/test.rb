﻿
require "server/settings"



t = Time.now.to_f
1000.times do |i|

end
puts "#{((Time.now.to_f - t)*1000*(Remote ? 1000 : 1)).round}t"










__END__


# require "cmd/command"
# require "func/modifications"
# require "server/settings"
# require "server/globals"
# require "server/guest"
# require "server/load"
# require "socket"
# require "mysql"
# require "benchmark"

# Benchmark.bm do |b| b.report "A   " do
	# (10**1).times do

	# end
	# GC.enable; GC.start; GC.disable
# end end

# $db = Mysql.real_connect(Db_server, Db_login, Db_pwd, Db_name)

# require "net/ssh"
# include Net

# SSH.start '62.193.219.166', 'root', '' do |ssh|
	# puts ssh.exec! "wget "
# end

# GC.start
# GC.disable