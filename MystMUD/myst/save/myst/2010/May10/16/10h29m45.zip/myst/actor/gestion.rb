﻿
class Actor
	def cmd_shortcut action, id, value
		case action
		when "cmd"
			@shortcut[1][id] = value
			wiz "Commande modifiée pour le raccourcis N°#{id+1}"
			show_shortcuts
		when "ico"
			if $icon.index value
				@shortcut[0][id] = value
				wiz "Icône modifiée pour le raccourcis N°#{id+1}"
				show_shortcuts
			else
				Error.cmd_hack "shortcut"
			end
		when 'edit'
			s = ''
			$icon.each_with_index do |ico, i|
				s << "<td><img src='ico/shortcuts/#{ico}.png' onclick=\"p('!shortcut ico #{id} #{ico}')\"></td>"
				s << '</tr><tr>' if ((i+1)%20).zero?
			end
			
			echo "main::<u>Configuration du raccourcis N°#{id+1} :</u><br><br><p>Choix de l'icône :</p><table cellpadding=0 style=border-collapse:collapse><tr>#{s}</tr></table>
<p>Commande(s) associée(s) (une par ligne) : </p><br>
<input type=text style=width:90% id=shcmd>::('!shortcut cmd #{id} '+el('shcmd').value-OK)"

		when "moveup"
			if id == 0
				wiz "Permutation impossible car ce raccourcis est en tête de liste."
			else
				2.times do |i|
					array = @shortcut[i]
					x, array[id - 1] = array[id - 1], array[id]
					array[id] = x
				end
				Cmd.option "shortcut"
				show_shortcuts
			end
		when "movedown"
			if id == 9
				wiz "Permutation impossible car ce raccourcis est en fin de liste."
			else
				2.times do |i|
					array = @shortcut[i]
					x, array[id + 1] = array[id + 1], array[id]
					array[id] = x
				end
				Cmd.option "shortcut"
				show_shortcuts
			end
		else
			Error.cmd_hack "shortcut"
		end
	end
	
	def eat item
		if @inv[item] == 1
			@inv.delete item
			echo "del::inv::#{item.id}"
		else
			echo "add::inv::#{item.id}::#{item.x (@inv[item] -= 1)}"
		end
		self.hunger += item.stats[:rassasiment] if heroe?
		witness_heroes.each do |heroe|
			heroe.wiz "#{@name.capitalize} mange #{item}."
		end
		wiz "Vous mangez #{item}."
	end
	
	def show_equipement
		s = "Vous êtes équipé#{e} par :"
		
		@equip.each do |on, item|
			s << "<br> - #{$wears[on]} : #{item}"
		end
		
		cleardiv
		wiz s
	end
	
	def show_inventory
		s = "Vous avez :"
		
		@inv.each do |item, number|
			s << "<br>- #{item.x number}"
		end
		
		cleardiv
		wiz s
	end
	
	def remove on # place where item to remove is
		item = @equip[on]
		number = receive item
		@equip.delete on
		wiz "Vous enlevez #{item}."
		
		room_heroes.each do |heroe|
			heroe.wiz "#{nameFor heroe} enlève #{item}."
		end
	end

	def wear item
		if item.wearon.empty?
			wiz "Cet objet ne peut pas être équipé."
			return
		end
		wearon, msg1, msg2 = nil, nil
		
		item.wearon.each do |on|
			unless @equip[on]
				msg1, msg2 = "équipe #{item}.", "Vous équipez #{item}."
				wearon = on
				break
			end
		end
		
		unless msg1
			wearon = item.wearon[0]
			last = @equip[wearon]
			number = receive last
			
			msg1, msg2 = "remplace #{last} par #{item}.", "Vous remplacez #{last} par #{item}."
		end
		
		@equip[wearon] = item
		
		wiz msg2
		
		room_heroes do |heroe|
			heroe.wiz "#{nameFor heroe} #{msg1}"
		end
	end
end