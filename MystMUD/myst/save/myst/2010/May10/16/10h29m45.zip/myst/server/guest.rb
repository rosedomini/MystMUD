﻿
module Guest
	attr_accessor :h, :flood, :control
	
	def new_guest
		@flood = 0
		@control = :start
		# set_encoding "UTF-8"
		# set_encoding "ISO-8859-1"
	end
	
	def eject reason = nil
		wiz reason if reason
		
		if @h
			@h.msg = ""
			@h.room >> @h
			$actor.delete @h.id
		end
		
		$guest.delete self
		close
	end
	
	def off
		begin
			eof
		rescue
			Kernel.puts "server/guest.rb:#{__LINE__} #{$!.inspect}"
			true
		end
	end
	
	def wiz sth, color=nil
		if color
			sth = "box::<font color=#{color}>#{sth}</font>::_"
		else
			sth = "box::#{sth}::_"
		end
		
		if sth.length > 2048
			sth.scan(/.{1,2048}/).each{|x| write x}
		else
			write sth
		end
	end
	
	def start arg
		return if arg == "&lt;policy-file-request/&gt;"
		@login_heroe = $heroe.each_value{|heroe| break heroe if heroe.name.same arg}
		if @login_heroe.is_a? Heroe
			@control = :login_password
			wiz "Entrez un mot de passe pour #{@login_heroe} :"
		else @login_heroe = nil
			if arg =~ /^\w{3,10}$/
				if arg == arg.downcase.capitalize
					wiz "Bienvenue #{@name = arg}. Quel sera votre mot de passe ?"
					@control = :register_password
				else
					wiz "Votre nom aura la forme ::[#{arg = arg.downcase.capitalize}-#{arg}]. Cliquez pour accepter ou entrez un autre nom."
				end
			else
				wiz "Merci d'entrer un nom de 3 à 10 lettres :<br>"
			end
		end
	end
	
	def login_password arg
		if @login_heroe.password == Digest::MD5.hexdigest(arg)
		
			$guest.select{|guest| guest.h == @login_heroe}.each do |guest|
				guest.eject "Une autre instance réclame ce personnage. Déconnexion forcée."
			end
			
			@h = @login_heroe
			@h.room << $actor[@h.id] = @h
			@control = :normal
			
			Kernel.puts "login: #{@h.name}\n"
			
			@h.onlogin
		else
			wiz "Mot de passe erroné.<br><br>Entrez votre nom :"
			@control = :start
		end
	end
	
	def register_password arg
		if arg =~ /^(\w|\d){5,13}$/
			wiz "Votre mot de passe est <b>#{arg}</b>. Vous pourrez le changer via la commande <b>account</b>.<br><br>Une voix mystérieuse saisit votre conscience : <font color=green>\"serez-vous un ::[1-homme] ou une ::[2-femme] ?\"</font>"
			@desc = {}
			@password = Digest::MD5.hexdigest(arg)
			@control = :desc_sex
		else
			wiz "Le mot de passe doit être formé par 5 à 13 caractères <b>alphanumériques</b>."
		end
	end
	
	def desc_sex arg
		if (arg = arg.to_i).zero? or arg > 2
			wiz "Cliquez sur un des liens !", :red
		else
			wiz case @desc[:taille] = arg
				when 1 then '"Vous serez un homme !"'
				when 2 then '"Vous serez une femme !"'
			end, Lightblue
			wiz "Votre conscience, toujours emparée par cette voix, perçoit maintenant des echos de l'écriture d'une plume, sur ce qui pourrait-être un parchemin d'une qualité inestimable.<br><br><font color=green>\"De quelle hauteur sera votre corps ?\"</font><br>::[1-petit] - ::[2-moyen] - ::[3-grand] - ::[4-immense !]"
			@control = :desc_height
		end
	end
	
	def desc_height arg
		if (arg = arg.to_i).zero? or arg > 4
			wiz "Cliquez sur un des liens !", :red
		else
			wiz case @desc[:taille] = arg.to_i
				when 1 then '"Je vois que vous n\'êtes pas difficile. Petit vous vivrez !"'
				when 2 then '"Moyen... bien."'
				when 3 then '"Je prends note. Ce sera tout ?"'
				when 4 then '"Immense ! Cela pourrait vous servir... pour jouer au basket, ou simplement sauter sur la tête d\'un ver des sables."'
			end, Lightblue
			wiz "<br><br><font color=green>\"De quelle couleur seront vos cheveux ?\"</font><br>::[1-roux] - ::[2-blonds] - ::[3-blonds cendrés] - ::[4-bruns] - ::[5-noirs] - ::[6-brons?]"
			@control = :desc_haircolor
		end
	end
	
	def desc_haircolor arg
		if (arg = arg.to_i).zero? or arg > 6
			wiz "Cliquez sur un des liens !", :red
		elsif arg == 6
			wiz '"Désolé mais... vous ne méritez pas cette couleur ! Choisissez-en une autre."', :red
			@bron = true
		else
			wiz case @desc[:haircolor] = arg
				when 1 then '"Vos cheveux seront roux."'
				when 2 then '"Vos cheveux seront blonds."'
				when 3 then '"Vos cheveux seront de couleur blond cendré (excellent choix)."'
				when 4 then '"Vos cheveux seront bruns."'
				when 5 then '"Vos cheveux seront noirs."'
			end, Lightblue
			wiz "<br><br><font color=green>\"De quelle longueur les voulez-vous ?\"</font><br>::[1-chauves] - ::[2-très courts] - ::[3-courts] - ::[4-de longueur moyenne] - ::[5-mi-longs] - ::[6-longs] - ::[7-très longs]."
			@control = :desc_hairlength
		end
	end
	
	def desc_hairlength arg
		if (arg = arg.to_i).zero? or arg > 7
			wiz "Cliquez sur un des liens !", :red
		else
			wiz case @desc[:hairlength] = arg
				when 1 then @bron ? '"Finalement bron je peux vous le faire sur cette longueur..."' : '"Je vous ai accordé une couleur, et vous la refusez ?!"'
				when 2 then '"Vos cheveux seront très courts."'
				when 3 then '"Vos cheveux seront courts."'
				when 4 then '"Vos cheveux seront de taille moyenne."'
				when 5 then '"Vos cheveux seront moyennement longs."'
				when 6 then '"Vos cheveux seront longs."'
				when 7 then '"Vos cheveux seront très longs."'
			end, Lightblue
			wiz "<br><br><font color=green>\"De quelle couleur seront vos yeux ?\"</font><br>::[1-bleus] - ::[2-verts] - ::[3-jaunes] - ::[4-roses] - ::[5-violets] - ::[6-marrons]"
			@control = :desc_eyecolor
		end
	end
	
	def desc_eyecolor arg
		if (arg = arg.to_i).zero? or arg > 6
			wiz "Cliquez sur un des liens !", :red
		else
			@desc[:eyecolor] = arg
			@h = $heroe[id = $heroe.new_id] = Heroe.new(id)
			$actor[id] = @h
			@h.name, @name = @name, nil
			@h.password = @password
			@h.authlevel = 0
			@h.desc, @desc = @desc, nil
			(@h.room = $room[1]).actors << @h
			@h.xp = 0
			@h.level = 1
			@h.hp = 20
			@h.maxhp = 20
			@h.mp = 10
			@h.maxmp = 10
			@h.str = 5
			@h.con = 5
			@h.wis = 5
			@h.dex = 5
			@h.skin = "default"
			@h.avatar = "default"
			@h.target = nil
			@h.spell = {}
			@h.inv = {}
			@h.equip = {}
			@h.shortcut = $default_shortcuts
			@h.hunger = 0
			wiz "<font color=#3399CC>\"Voilà qui est réglé. Je vous ai trouvé le corps adéquat. Au revoir noble âme. Puisses-tu prendre soin de ce nouveau né.\"</font><br><br>Votre personnage se contrôle à l'aide d'ordres donnés au clavier. On appelera commandes le premier mot de ces ordres, qui peut être écrit partiellement. S'il y a une ambiguïté entre plusieurs commandes, l'ordre alphabétique tranchera.<br><br>Vous incarnez maintenant le personnage <b>#{@h}</b> qui aura peut-être un grand rôle dans ce monde. Peut-être deviez vous commencer par taper <b>aide</b> (ou <b>ai</b>), puis <b>chat/ch Bonjour !</b> pour discuter, ou encore <b>who/wh</b> pour voir la liste des joueurs en ligne."
			@control = :normal
			@h.look_around
		end
	end
	
	def normal arg
		h.cmd arg
	end
end
