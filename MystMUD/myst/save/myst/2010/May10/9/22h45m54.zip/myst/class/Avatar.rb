﻿
class Avatar
	attr_accessor :id
	attr_accessor :name
	alias to_s name
	attr_accessor :source
	
	def initialize id
		@id = id
	end
end
