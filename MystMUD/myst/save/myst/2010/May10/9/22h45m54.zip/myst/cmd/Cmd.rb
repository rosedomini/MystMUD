﻿
class Cmd
	def self.aide command = nil # commande
		if command
			if command == "move"
				wiz "<p>Vous pouvez déplacer votre personnage avec les flèches du clavier lorsque le curseur n'est pas sur la barre.</p><p>Sinon tapez <b>s</b> pour aller au sud, <b>n</b> pour aller au nord, <b>e</b> pour aller à l'est ou <b>o</b> pour aller à l'ouest. Pour effectuer un chemin en une fois, entrez la liste des mouvements à effectuer</p><p>(<u>exemples&nbsp;:</u> <b>no</b> pour aller au nord-ouest, ou encore <b>nnoo</b>...&nbsp;)</p>"

			elsif command == "shortcuts"
				echo "text::<p>les touches <b>&é\"'(-è_çà</b> correspondent aux raccourcis de 1 à 10 lorsque le curseur est sur la barre de commande et que celle-ci est vide.</p><p>La configuration des raccourcis se fait via le menu ::[option-option].</p>"
				
			else
				command = $command[command]
				wiz "<font color=#3366CC>Syntaxe : </font><font color=orange>#{command.syntax}</font><br> ¤ #{command.help}"
			end
		else
			echo "main::::[aide move-Déplacement du personnage]<br>
<p>::[aide shortcuts-Utilisation des raccourcis]</p>
<p><u>Liste des commandes :</u></p><br>
Action#{Cmd.AideList :action}
Communication#{Cmd.AideList :communication}
Gestion#{Cmd.AideList :gestion}
Divers#{Cmd.AideList :divers}<br>
Aide insuffisante ? Utilisez la commande ::[pray-pray] et elle sera améliorée selon votre question."

		end
	end

	def Cmd.AideList type
		s = "<br><p>"
		
		$command.each_value do |command|
			if command.keyboard and command.type == type and command.authlevel <= $p.authlevel
				s << "::[aide #{command}-#{command}]"
			end
		end
		
		return s+"</p>"
	end

	def Cmd.option option = ""
		if option == "skin"
			s = "main::<u>Skins disponibles :</u><br><br><table cellpadding=0 style=border-collapse:collapse><tr>"
			i = 1
			
			$skin.each do |skin|
				s << "<td><img onclick=\"p('selectSkin #{skin.id}')\" src=ico/skin/#{skin.source}/s.png></td>"
				s << "text::</tr><tr>" if (i%15).zero?
				i += 1
			end
			
			s << "text::</tr></table><br><br><u>Avatars disponibles :</u><br><table cellpadding=0 style=border-collapse:collapse><tr>"
			i = 1
			
			$avatar.each do |avatar|
				s << "<td><img width=102 onclick=\"p('selectAvatar #{avatar.id}')\" src=ico/avatar/#{avatar.source}.png></td>"
				s << "</tr><tr>" if (i%15).zero?
				i += 1
			end
			
			echo "#{s}</tr></table>"
			
		elsif option == "shortcut"
			list = "list::shortcuts::edit;moveup;movedown::"
			
			commands = $p.shortcut[1]
			$p.shortcut[0].each_with_index do |icon, i|
				list << ";<img src='ico/shortcuts/#{icon}.png'><b>#{i+1}</b> : #{commands[i]},#{i+1}"
			end
			
			echo "main::<p><u>Configuration des raccourcis :</u></p><div id=list_shortcuts></div>::_#{list}"
		else
			echo "main::
<p><u>Options disponibles :</u></p>
<p>::[option shortcut-Configurer les raccourcis]</p>
<p>::[option skin-Changer d'apparence]</p>
<p>::[option shortcuts-Configurer les raccourcis]</p>
<p>::[pray-Signaler ou proposer quelque chose]</p>"

		end
	end
	
	# affiche le calendrier et la date virtuelle
	def Cmd.time
		s = "<table width=400 bgcolor=white border=1 style=color:black;border-collapse:collapse;margin-left:50px><tr><td colspan=2 align=center><font color=blue>Année #{(d = wdate)['year']}</font></td><td>#{6}</td><td>#{$months[6]}</td></tr>"
		5.times do |n|
			s << "<tr><td>#{n+=1}</td><td>#{$months[n]}</td><td>#{n+=6}</td><td>#{$months[n]}</td></tr>"
		end
		wiz "#{s}</table><br>Nous sommes le jour #{d['day']} du mois d'#{d['month']} de l'année #{d['year']}.<br>Il est #{d['hours']}h#{d['minutes']}."
	end

	def self.who all = false
		if all
			s = "<font color=orange>Liste des joueurs :</font>"
			$heroe.each_value do |heroe|
				s << "<br> - #{heroe}#{" (en ligne)" if heroe.online?}"
			end
		else
			s = "<table width=400 cellpadding=2 cellspacing=0><tr><td style='border-right:1px solid white'><font color=orange align=left>Joueurs connectés</font></td><td style='border-right:1px solid white'>niveau</td><td>informations</td></tr>"
			$actor.each_value do |actor|
				s << "<tr><td style='border-right:1px solid white'>#{actor}</td><td style='border-right:1px solid white'>#{actor.level}</td><td></td></tr>" if actor.heroe?
			end
			s << "</table>"
		end
		wiz s
	end
end