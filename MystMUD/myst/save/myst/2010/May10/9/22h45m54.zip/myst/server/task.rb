﻿
class Task
	attr_accessor :id
	attr_accessor :timestamp
	attr_accessor :clss
	attr_accessor :func
	attr_accessor :args
	attr_accessor :del

	def initialize(timestamp, clss, func, args = [], del = false)
		@id = $t.count
		@timestamp = timestamp
		@clss = clss
		@func = func
		@args = args
		@del = del
	end
	
	def execute
		@clss.send @func, *@args
	end
	
	def Task.item_repop
		puts "Item repop..."
		$room.each_value do |room|
			room.item_repop
		end
		$task.timestamp = $srv.time + 600
	end
	
	def Task.gc
		GC.enable
		GC.start
		GC.disable
		$task.timestamp = $srv.time + 3
	end
	
	def Task.world_refresh
		puts "Refreshing...\n"
		$refresh += 1
		$task.timestamp = $srv.time + 55 + rand(10)
		worldTime = wtime()
		
		$actor.each_value do |actor|
			actor.hp += (actor.maxhp / 5)
			actor.mp += (actor.maxmp / 5)
		end
		
		if ($refresh%5).zero?
			$actor.each_value do |actor|
				actor.hunger -= 60 if actor.heroe?
			end
		end
		
		$body.each_value do |body|
			body.over if worldTime > body.expire
		end
		
		$mob.each_value do |mob|
			mob.repop unless $actor[mob.id]
		end
		$srv.send_all
	end
end
