﻿
# fonctions des commandes admin concernant la création et l'édition

class Cmd
	def self.set cls, object, var, value # ~ $hash[id].var = value
		begin
			object.send "#{var}=", (value = $data[cls.to_sym].from_olc(var, value))
			wiz "Nouvelle valeur : #{value}"
		rescue
			wiz "Erreur : #{$!}"
		end
	end

	def self.summonItem item, number = 1
		if $p.inv[item]
			$p.inv[item] += number
		else
			$p.inv[item] = number
		end
		wiz "Vous invoquez #{item.x number}."
	end
	
	def self.edit cls, o
		id = o.id
		s = "main::::[olc-OLC] - ::[redit-redit] - ::[olc #{cls}-#{cls}s]<br><br><font color=black>#{cls}[#{id}] :</font></b><br><table style=width:100%;border:none class=default><tr><td align=center width=100><b><font color=black>Variable<br></font></b></td><td width=100% align=center><b><font color=black>Valeur<br></font></td><td width=30 align=center></td><td align=center width=100><b><font color=black>Type<br></font></b></td>"
		$olc[cls].each do |var|
			v, type = $data[cls.to_sym].to_olc(var.to_sym, o.send(var))
			rows = 1
			v_rows = v.split("\n")
			v_rows.each{ |row| rows += row.length / 70 }
			rows = 5 if var == :desc
			s << "</tr><tr><td align=right>#{var}</td><td><textarea rows=#{rows} id=olcv_#{var} cols=70>#{v}</textarea></td><td>::('set #{cls} #{id} #{var} '+el('olcv_#{var}').value-OK)</td><td align=center>#{type}</td>"
		end
		echo "#{s}</tr></table>"
	end
	
	def self.clone class_, id
		if $clonable.index class_.to_sym
			hash = $classhash[class_]
			new_id = hash.new_id
			new_object = $data[class_.to_sym].copy_from(hash[id])
			hash << new_object
			new_object.id = new_id
			wiz "Objet #{class_}[#{id}] cloné en [#{new_id}] - ::[edit #{class_} #{new_id}-Modifier]"
		else
			wiz "Ce type d'objet ne peut pas encore être cloné."
		end
	end

	def self.olcShow class_, object
		s = "obj::<b><font color=black>#{class_}[#{id = object.id}] :</font></b><br><br>::[edit #{class_} #{id}-modifier] ::[clone #{class_} #{id}-cloner]#{" <input class=input size=4 type=text value=1 id=summon>::('summonItem #{id} '+el('summon').value-invoquer)<br>" if class_ == 'Item'}<br><br>"
		$olc[class_.to_s].each do |var|
			if (v = object.send(var).inspect).length > 50
				rows = v.length / 31 + 1
				s << "<br><b>&lt;#{var}&gt;</b><br><textarea style=width:100% rows=#{rows > 5 ? 5 : rows}>#{v}</textarea><br>"
			else
				s << "<br><b>&lt;#{var}&gt;</b><br>#{v}<br>"
			end
		end
		echo s
	end

	def self.olc class_ = nil # shows olc or class pannel
		s = "main::::[olc-OLC] - ::[redit-redit]#{class_ ? " - ::[olc #{class_}-#{class_}s]" : ""}<br><br>Listes : "
		$olc.each_key{|class_| s << "::[olc #{class_}-#{class_}]"}
		
		if class_
			vars = $classhash[class_]
			var = vars[0]
			
			s <<  "<br><br>#{class_}s :<br><br><div style='width:333px;position:fixed;top:0;right:0; bottom:300;overflow:auto'><table cellpadding=4 cellspacing=0 class=default><tr><td bgcolor=black><div id=obj></div></td></tr></table></div><table border=1 cellpadding=4 cellspacing=0 style=border-collapse:collapse class=default><tr>"
			
			vars.each_value do |var|
				s << "<td height=25 id=olcshow#{id = var.id} 
onmouseover=\"p('olcShow #{class_} #{id}');el('olcshow#{id}').bgColor='#0066FF'\" 
onmouseout=\"el('olcshow#{id}').bgColor=''\" 
onclick=\"p('edit #{class_} #{id}')\">#{id} - #{var}</td></tr><tr>"
			end
			echo "#{s[0..-4]}/table>"
		end
		echo s
	end
end
