﻿
class File
	def list_func
		
	end
end

File.open "actor/check.rb", "r+" do |file|
	file.list_func
end