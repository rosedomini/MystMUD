﻿
# fonctions globales

def wiz sth, color=nil
	if color
		$p.wiz "<font color=#{color}>#{sth}</font>"
	else
		$p.wiz sth
	end
end

def echo sth, color=nil
	if color
		$p.s "<font color=#{color}>#{sth}</font>"
	else
		$p.s sth
	end
end