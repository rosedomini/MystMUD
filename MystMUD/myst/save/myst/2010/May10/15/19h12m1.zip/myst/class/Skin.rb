﻿
class Skin
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :source
	
	def initialize id
		@id = id
	end
end