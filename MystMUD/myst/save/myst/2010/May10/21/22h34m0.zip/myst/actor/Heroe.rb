﻿
class Heroe < Actor
	attr_accessor :desc
	attr_accessor :msg
	attr_accessor :shortcut
	attr_accessor :password
	attr_accessor :authlevel
	attr_accessor :xp
	attr_reader :hunger
	
	def initialize id
		new_actor id
		
		@msg = ""
		@hunger = 0
	end
	
	def after_load
		@status = :none
		@msg.clear
	end
	
	def add_xp xp_to_add
		wiz "<br>Vous acquérissez de l'expérience ~ <font color=#3366CC>#{xp_to_add}</font> points."
		@xp += xp_to_add
		while @xp >= xp_needed
			@xp -= xp_needed
			level_up
		end
	end

	def echo sth
		@msg << "#{sth}::_"
	end
	
	def heroe?
		true
	end
	
	def hunger= value
		if @hunger < value
			if value < 0
				@hunger = 0
			elsif value > 1200
				@hunger = 1200
				wiz "Vous êtes complètement rassasié."
			else
				@hunger = value
			end
		else
			if (@hunger = value) < 0
				wiz "Vous avez #{"très "*(-value/1800).truncate}faim."
			end
		end
	end
	
	def inspect
		"$heroe[#{@id}]"
	end
	
	def killed actor = nil
		s = case rand 3
			when 0 then	"#{@name} tombe raide mort."
			when 1 then	"#{@name} expire son dernier souffle."
			else 				"#{@name} s'écroule dans une marre de sang."
		end
		
		wiz "Vous vous écroulez, vide d'énergie...<br>", :red
		room_heroes.each{ |heroe| heroe.wiz s }
		actor.add_xp xp_gives if actor and actor.heroe?
		body = $body << Body.new($body.new_id).create(@id, 720, @room)
		inventory = body.inv = @inv.clone
		
		@equip.each_value do |id|
			if inventory[id]
				inventory[id] += 1
			else
				inventory[id] = 1
			end
		end
		
		@inv.clear
		@equip.clear
		@status = ''
		@hp = @maxhp
		@room >> self
		(@room = $room[1]) << self
		@target = nil

		$actor.each_value{|x| x.target = nil if x.target == self}
		
		look_around
	end
	
	def level_up
		@level += 1
		wiz 'Vos capacités progressent d\'un niveau !', :blue
		case rand 4
			when 0 then @dex += 3
			when 1 then @wis += 3
			when 2 then @con += 3
			when 3 then @str += 3
		end
		@maxhp += @con
		@maxmp += @wis
		@hp = @maxhp
		@mp = @maxmp
	end
	
	def mob?
		false
	end
	
	def online?
		$actor.key self
	end
	
	def s sth, color=nil
		if color
			@msg << "<font color=#{color}>#{sth}</font>::_"
		else
			@msg << "#{sth}::_"
		end
	end
	
	def send_msg guest
		@msg << "health::#{@hp}::#{@maxhp}::#{@mp}::#{@maxmp}::_"
		
		# if @msg.length > 2048
			# @msg.scan(/.{1,2048}/).each{|s| guest.write s}
		# else
			guest.write @msg
		# end
		
		p @msg if $dump
		@msg = ''
	end
	
	def show_shortcuts
		@msg << "shortcuts::"
		commands = @shortcut[1]
		@shortcut[0].each_with_index do |icon, i|
			@msg << ";#{icon},#{commands[i]}"
		end
		@msg << "::_"
	end
	
	def wiz sth, color=nil
		if color
			@msg << "box::<font color=#{color}>#{sth}</font>::_"
		else
			@msg << "box::#{sth}::_"
		end
	end
	
	def xp_needed
		2*(@level**2)*(@level+50)*(1+0/3) # replace 0 with @ren
	end
end
