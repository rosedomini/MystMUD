﻿
class Data::Change
	def self.equipement value
		equip = {}
		value.each do |wear, item_id|
			if item = $item[item_id]
				equip[wear] = item
			else
				equip.delete wear
			end
		end
		return equip
	end
	
	def self.exits exits
		exits.each do |name, room_id|
			if room = $room[room_id]
				exits[name] = room
			else
				exits.delete name
			end
		end
		return exits
	end
	
	def self.inventory value
		inv = Inventory.new
		value.each do |id, number|
			if item = $item[id] and number > 0
				inv[item] = number
			else
				inv.delete id
			end
		end
		return inv
	end
	
	def self.room value
		$room[value]
	end
end