﻿
class Spell
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :desc
	attr_accessor :min_cost, :max_cost
	attr_accessor :school
	attr_accessor :func
	
	def initialize id
		@id = id
	end
end

class Spells
	# def boule_de_feu power, cible, caster
		# dmg = (power + 4 * caster.wis) / 2
		# echo "main::<br>Vous envoyez une boule de feu sur #{caster} (#{dmg})"
		# if dmg >= cible.hp
			# cible.killed
		# else
			# cible.hurt (power + 4 * caster.wis) / 2, self
		# end
		# wiz caster.id
	# end
end