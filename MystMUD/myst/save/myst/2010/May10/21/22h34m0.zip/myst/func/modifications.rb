﻿
class Hash	
	def << value
		self[1 + (keys.max or -1)] = value
	end
	
	def | h
		r = clone
		h.each do |key, value|
			if r[key]
				r[key] += value
			else
				r[key] = value
			end
		end
		return r
	end
	
	def new_id
		1 + (keys.max or -1)
	end
	
	def no value
		x = clone
		if k = key(value)
			x.delete k
		end
		x
	end
	
	def wiz sth, color=nil
		sth = "<font color=#{color}>#{sth}</font>"
		each_value{|x| x.wiz sth}
	end
end

class Mysql::Result
	def encode value, encoding = "utf-8"
		String === value ? value.force_encoding(encoding) : value
	end
	
	def each_utf8 &block
		each_orig do |row|
			yield row.each_with_index{|col, i| row[i] = encode(col) }
		end
	end
	alias each_orig each
	alias each each_utf8

	def each_hash_utf8 &block
		each_hash_orig  do |row|
		row.each{|k, v| row[k] = encode(v) }
			yield row
		end
	end
	alias each_hash_orig each_hash
	alias each_hash each_hash_utf8
end

class String
	# Est-ce que la phrase contient la chaîne s (insensible à la casse)
	def contains s
		downcase.rindex s.downcase
	end
	
	def main
		"main::#{self}::_"
	end

	# Est-ce la phrase est égale à la chaîne s (insensible à la casse)
	def same b
		downcase == b.downcase
	end
	
	def to_b
		self == "1"
	end
end

class NilClass
	def [] x; end
end

class TrueClass
	def to_str
		"1"
	end
end

class FalseClass
	def to_str
		"0"
	end
end

class Array
	def delete_one value
		if i = index(value)
			delete_at i
		end
	end
	
	def no value
		x = clone
		if i = index(value)
			x.delete_at i
		end
		x
	end
	
	def seek needle, count = nil, method = :name
		count = count ? count.to_i : 1
		find{|x| x.send(method).contains needle and (count -= 1).zero? }
	end
	
	def to_h
		a = {}
		size.times{|i| a[i] = self[i]}
		a
	end
	
	def wiz sth, color=nil
		sth = "<font color=#{color}>#{sth}</font>"
		each{|x| x.wiz sth}
	end
end

class TCPSocket
	include Guest
end

class TCPServer
	include Guest
end