﻿
class Actor	
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :room
	attr_accessor :level
	attr_accessor :hp
	attr_accessor :maxhp, :mp, :maxmp
	attr_accessor :str, :con, :wis, :dex
	attr_accessor :skin, :avatar
	attr_accessor :status
	attr_accessor :target
	attr_accessor :spell, :inv, :equip
	attr_accessor :master
	attr_accessor :last_teller
	
	include Receive
	
	def new_actor id
		@id = id
	end
	
	def onlogin
		look_around
		show_shortcuts
	end
	
	def cleardiv
		echo "main::::_"
	end

	def cmd arg
		$p = self
			
		if arg =~ /^(!)?(\w+) *(.*\S+)? *$/
			$link = $1
			$cmd = $2
			$x = $3
		else
			return
		end
		
		if $cmd =~ /^[nsoebh]$/
			@room.exits.each_key do |exit_name|
				if $cmd == exit_name.to_s[0]
					move exit_name
					return
				end
			end
			wiz "Vous ne pouvez pas aller par là."
			return
		end
		
		unless $x or $link
			@room.exits.each_key do |exit_name|
				if $cmd == exit_name.to_s[0, $cmd.length]
					move exit_name
					return
				end
			end
		end
		
		cmd = nil
		
		if $link
			if cmd = $command[$cmd] and cmd.link
				nil
			else
				Log.link_error
				wiz "Lien brisé : l'erreur vient d'être enregistrée.", :red
				return
			end
		elsif $keyboard_cmd =~ /;(#{$cmd}\w*);/
			cmd = $command[$1]
		elsif immortal? and $admin_keyboard_cmd =~ /;(#{$cmd}\w*);/
			cmd = $command[$1]
		else
			wiz "Commande inconnue : #{$cmd}", :red
			return
		end
		
		if @status == :dead and !cmd.ko
			wiz "Vous n'êtes pas en état de faire celà... vous êtes mort#{e} !"
		elsif mob? and !cmd.mob
			say_to_master "Je ne peux pas faire ça, maître#{"sse" if @master and @master.female?}."
			return
		elsif @authlevel < cmd.authlevel
			wiz "Vos pouvoirs ne vous permettent pas de faire cela."
		else
			send "check_#{cmd}#{$link}".to_sym
		end
	end
	
	def e
		"e" if @desc and @desc[:sex] == 2
	end
	
	def energize points, percent = nil
		points = (@maxmp / 100.0 * points).round if percent
		@mp += points
		if @mp < 0
			@mp = 0
		elsif @mp > @maxmp
			@mp = @maxmp
		end
	end
	
	def female?
		@desc[:sex] == 2
	end
	
	def heal points, percent = nil
		points = (@maxhp / 100.0 * points).round if percent
		@hp += points
		if @hp < 1
			@hp = 1
			killed
		elsif @hp > @maxhp
			@hp = @maxhp
		end
	end
	
	def hp_percent
		(  @hp / @maxhp * 100 ).round
	end
	
	def hurt dmg, actor
		@hp -= dmg
		if @hp < 1
			@hp = 1
			killed actor
		elsif @hp > @maxhp
			@hp = @maxhp
		end
	end
	
	def immortal?
		@authlevel > 0
	end
	
	def name_for actor
		actor.sees(self) ? name : "quelqu'un"
	end
	
	def nameFor actor
		actor.sees(self) ? name : "Quelqu'un"
	end
	
	def move_to new_room
		@room >> self
		(@room = new_room) << self
	end
	
	def mp= new_mp
		@mp = new_mp > @maxmp ?  @maxmp : new_mp
	end
	
	def retrieve id, number = 1
		if @inv[id] and @inv[id] >= number
			@inv[id] -= number
			ret = @inv[id]
			if @inv[id].zero?
				@inv.delete id
			end
			ret
		end
	end
	
	def say_to_master sth, color = nil
		@master.wiz "#{name} vous dit : #{sth}", color
	end
	
	def sb? actor, maj=true
		if actor.sees self
			name
		else
			"#{maj ? "Q" : "q"}uelqu'un"
		end
	end
	
	def sees a
		true
	end
	
	def up_spell id, points = 1
		if spell = @spell[id]
			spell += points
		else
			@spell[id] = points
		end
	end
	
	def xp_gives
		((115 - rand(31))*(@level**2)*(@level+50)*(1+0/3) / 1000).round # replace 0 with @ren
	end
end