﻿
=begin Arguments :
		check_cmd pour vérifier la liste des commandes
=end

# Script principal

GC.disable

print "Parse & def... "

trap "SIGINT", proc{ $server.shutdown } # Ctrl+C

$actor		= $a	= {}
$avatar			= {}
$body		= $b	= {}
$command		= {}
$data				= {}
$guest		= $g	= []
$heroe		= $h	= {}
$icon				= []
$item		= $i	= {}
$mob				= {}
$power				= {}
$race				= {}
$room		= $r	= {}
$shop				= {}
$skin				= {}
$spell		= $sp={}
$system	= $sys={}
$tasks		= $t	= []
$world				= {}
$area				= {}

require "server/settings"

require Mysql_gem
require "date"
require "cgi"
require "digest/md5"
require "socket"
include Socket::Constants

require "func/module/Receive"

require "world/Avatar"
require "world/Body"
require "world/Item"
require "world/Race"
require "world/Room"
require "world/Shop"
require "world/Skin"
require "world/Spell"
require "world/Area"
require "world/World"

require "server/data/Data.Change"
require "server/data/Data.Clone"
require "server/data/Data.Load"
require "server/data/Data.LoadOLC"
require "server/data/Data"
require "server/data/Data.Save"
require "server/data/Data_define"
require "server/data/Load"
require "server/data/Log"
require "server/data/Save"

require "server/globals"
require "server/Guest"
require "server/Server"
require "server/Task"

require Cache_dir

require "cmd/action"
require "cmd/admin"
require "cmd/Command"
require "cmd/communication"
require "cmd/divers"
require "cmd/divers_a"
require "cmd/gestion"
require "cmd/gestion_a"
require "cmd/olc"
require "cmd/check"
require "cmd/check_admin"

require "func/Error"
require "func/Fight"
require "func/Inventory"
require "func/Kernel"
require "func/lists"
require "func/modifications"
require "func/Power"
require "func/System"
require "func/time"

require "proc/power"

require "actor/Actor"
require "actor/Heroe"
require "actor/Mob"

Dat.define

$db = Mysql.init
$db.options Mysql::SET_CHARSET_NAME, 'utf8'
$db.real_connect(Db_server, Db_login, Db_pwd, Db_name)
$db.query "SET NAMES utf8"

# q = $db.query "SELECT * FROM command WHERE 1"
# q.each_hash do |d|
	# d.each_value do |value|
		# p value.gsub(/\n/, "<br>")
	# end
# end
# exit

Load.world

$w = $world[1]

$db.close

if ARGV[0] == "check_cmd"
	$command.each do |name, cmd|
		if cmd.link and !Actor.instance_methods.index("check_#{name}!".to_sym)
			puts "Method unavailable: check_#{name}! for command\n\t#{cmd.inspect}\n\n"
		elsif !cmd.link and !Actor.instance_methods.index("check_#{name}".to_sym)
			puts "Method unavailable: check_#{name} for command\n\t#{cmd.inspect}\n\n"
		end
	end
	Actor.instance_methods.each do |method|
		if method.to_s =~ /^check_(\w+)(!)?$/
			if cmd = $command[$1]
				if $2 and !cmd.link
					puts "$command[#{$1.inspect}] is not a indicated as a link"
				elsif $2.nil? and !cmd.keyboard
					puts "$command[#{$1.inspect}] is not indicated as working with keyboard"
				end
			else
				puts "undefined $command[#{$1.inspect}]"
			end
		end
	end
	exit
end

$srv = $server = Server.new

$srv.run
