﻿
# fonctions des commandes admin de gestion

class Actor
	def cmd_giveXp p, xp # player, amount of experience
		p.add_xp xp
	end

	def cmd_lvUp p #player
		p.add_xp p.xp_needed - p.xp
	end

	def cmd_force a, c # forces actor a to execute command c
		Task.cmd a, c
	end
end