# coding: ISO-8859-1

class Actor	
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :room
	attr_accessor :level
	attr_reader :hp
	attr_accessor :maxhp, :mp, :maxmp
	attr_accessor :str, :con, :wis, :dex
	attr_accessor :skin, :avatar
	attr_accessor :status
	attr_accessor :target
	attr_accessor :spell, :inv, :equip
	
	include Receive
	
	def new_actor id
		@id = id
		@maxhp = 100000
		@maxmp = 100000
	end
	
	def at_login
		look_around
		show_shortcuts
	end
	
	def cleardiv
		@msg << "main::::_"
	end

	def cmd arg
		$p = self
		
		splitted = arg.split " ", 2
		return unless $cmd = splitted[0]
		
		if splitted[1].nil? or splitted[1].empty?
			$x = nil
		else
			$x = splitted[1]
		end

		if $cmd[0] == '!'
			$link = "!"
			$cmd = $cmd[1,99]
		else
			$link = nil
		end
		
		unless $x
			@room.exits.each_key do |exit_name|
				if $cmd == exit_name.to_s[0, $cmd.length]
					move exit_name
					return
				end
			end
		end
		
		($link ? $link_cmd : $keyboard_cmd).each do |cmd|
		
			if $cmd == cmd[0, $cmd.length]
				command = $command[cmd]
				
				if @status == :dead and !command.ko
					wiz "Vous n'�tes pas en �tat de faire cela."
					return
					
				elsif mob? and !command.mob
					return
					
				elsif @authlevel >= command.authlevel
					send "check_#{cmd}#{$link}"
					return
				else
					break
				end
			end
		end
		if @authlevel > 0 and $command[$cmd]
			send "check_#{$cmd}"
		else
			echo "chat::red::Commande inconnue : #{$cmd}"
		end
	end
	
	def fem
		@fem ? "e" : ""
	end
	
	def hp= new_hp
		if 0 > @hp = new_hp
			killed
			true
		elsif @hp > @maxhp
			@hp = @maxhp
		end
	end
	
	def hp_percent
		(  hp / maxhp * 100 ).round
	end
	
	def immortal
		$god[@id]
	end
	
	def name_for actor
		actor.sees(self) ? name : "quelqu'un"
	end
	
	def nameFor actor
		actor.sees(self) ? name : "Quelqu'un"
	end
	
	def move_to new_room
		@room.actors.delete self
		@room = new_room
		@room.actors << self
	end
	
	def mp= new_mp
		@mp = new_mp > @maxmp ?  @maxmp : new_mp
	end
	
	def sees a
		true
	end
	
	def retrieve id, number = 1
		if @inv[id] and @inv[id] >= number
			@inv[id] -= number
			ret = @inv[id]
			if @inv[id].zero?
				@inv.delete id
			end
			ret
		end
	end
	
	def up_spell id, points = 1
		if spell = @spell[id]
			spell += points
		else
			@spell[id] = points
		end
	end
	
	def xp_gives
		((115 - rand(31))*(@level**2)*(@level+50)*(1+0/3) / 1000).round # replace 0 with @ren
	end
end