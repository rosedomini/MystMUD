
class Inventory
	attr_reader :items

	def initialize items={}
		@items = items
	end
	
	def << items
		if (c = items.class) == Hash then @items |= items
		elsif c == Inventory then @items |= items.items
		elsif c == Fixnum then @items[items] = if @items[items] then @items[items] + 1 else 1 end
		else raise ArgumentError end
		self
	end
end