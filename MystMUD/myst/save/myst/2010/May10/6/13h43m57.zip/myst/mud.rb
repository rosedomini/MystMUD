# coding: ISO-8859-1

# Script principal

GC.disable

print "Parsing... "

trap "SIGINT", proc{ $srv.server.close ; $db.close ; exit } # �x�cut� avec Control + C

$actor		= $a	= {}
$avatar			= {}
$body		= $b	= {}
$command			= {}
$data				= {}
$god				= {}
$guest		= $g	= []
$heroe		= $h	= {}
$icon				= []
$item		= $i	= {}
$mob				= {}
$race				= {}
$room		= $r	= {}
$shop				= {}
$skin				= {}
$spell		= $sp	= {}
$system	= $sys	= {}
$tasks		= $t	= []
$world				= {}
$zone				= {}

require "server/settings"

require Mysql_gem
require "date"
require "cgi"
require "digest/md5"
require "socket"
include Socket::Constants

require "module/Receive"

require "class/Avatar"
require "class/Body"
require "class/Item"
require "class/Race"
require "class/Room"
require "class/Shop"
require "class/Skin"
require "class/Spell"
require "class/Zone"

require "data/Data.Change"
require "data/Data.Clone"
require "data/Data.Load"
require "data/Data.LoadOLC"
require "data/Data"
require "data/Data.Save"
require "data/Data_define"

require "server/globals"
require "server/guest"
require "server/load"
require "server/save"
require "server/server"
require "server/task"

require Cache_dir

require "cmd/Command"
require "cmd/Cmd"
require "cmd/divers_a"
require "cmd/olc"
require "cmd/gestion_a"

require "func/Error"
require "func/fight"
require "func/function"
require "func/modifications"
require "func/System"
require "func/time"

require "actor/Actor"
require "actor/God"
require "actor/Heroe"
require "actor/Mob"

require "actor/action"
require "actor/admin"
require "actor/check"
require "actor/check_admin"
require "actor/gestion"
require "actor/communication"
require "actor/lists"

require "world/World"

Dat.define

$db = Mysql.real_connect(Db_server, Db_login, Db_pwd, Db_name)

Load.world

$w = $world[1]

$db.close

$srv = $server = Server.new

$srv.run
