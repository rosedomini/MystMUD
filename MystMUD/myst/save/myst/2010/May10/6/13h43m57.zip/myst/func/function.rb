# coding: ISO-8859-1

# fonctions globales

def wiz s
	$p.msg << "box::#{s}::_"
end

def echo s
	$p.msg << "#{s}::_"
end