# coding: ISO-8859-1

# Gestion du crossdomain sur le port 843

require "socket"
require "settings"
guests = []

(server = TCPServer.new(Hostname, 843)).set_encoding "ASCII-8BIT"

puts "Crossdomain server started at #{Hostname}:843"

loop do
	begin
		sock = server.accept
		sock.write "<?xml version=\"1.0\"?> 
<!DOCTYPE cross-domain-policy SYSTEM \"http://www.adobe.com/xml/dtds/cross-domain-policy.dtd\"> 
<cross-domain-policy>  
<allow-access-from domain=\"*\" to-ports=\"6022\" />
</cross-domain-policy>\0"
		sock.close
		puts "Client joined"
	rescue
		p $!
	end
end
