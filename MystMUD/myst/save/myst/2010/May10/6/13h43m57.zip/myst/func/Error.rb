# coding: ISO-8859-1

# fonctions permettant d'afficher des erreurs

class Error
	def Error.olc_class
		echo "main::Les classes �ditables via l'olc sont les suivantes :<br><br>#{$olc.keys.join(", ")}"
	end
	
	def Error.cmd_unavailable
		wiz "Commande indisponible"
	end
	
	def Error.cmd_hack c # command name used
		$hack << "<u>#{Time.now}:</u> <b>#{$p}</b> uses <b>#{c}</b> via scripting."
		$g.each do |g|
			if g.h and g.h == $p
				g.eject "Scripting interdit et loggu� ! Merci d'utiliser \"pray\" en cas de probl�me"
				return
			end
		end
	end
	
	def Error.warning s
		puts "\n\n#{s} :\n#{$!}\n\n"
	end
	
	def Error.sql id
		puts "\n\t\t#{@id} : #{$!}\n"
		raise "SQL save failed !"
	end
	
	def Error.display
		puts "****\n\t#{$!} (#{$!.class})\n\tfrom #{($!.backtrace+caller[0..-2]).join("\n\tfrom ")}\n****"
	end
end