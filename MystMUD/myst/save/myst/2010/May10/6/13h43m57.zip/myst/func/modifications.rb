# coding: ISO-8859-1

class Hash
	def new_id
		1 + (keys.max or -1)
	end
	
	def << value
		self[1 + (keys.max or -1)] = value
	end
	
	def | h
		r = clone
		h.each do |key, value|
			if r[key]
				r[key] += value
			else
				r[key] = value
			end
		end
		return r
	end
end

class String
	# Est-ce que la phrase contient la cha�ne s (insensible � la casse)
	def contains s
		downcase.rindex s.downcase
	end

	# Est-ce la phrase est �gale � la cha�ne s (insensible � la casse)
	def same b
		downcase == b.downcase
	end
	
	def to_b
		self == "1"
	end
end

class NilClass
	def [] a
		nil
	end
end

class TrueClass
	def to_str
		"1"
	end
end

class FalseClass
	def to_str
		"0"
	end
end

class Array
	def to_h
		a = {}
		each_with_index {|e, i| a[i] = e}
		a
	end
	
	def find needle, count, method = :name
		if count
			count = count.to_i
			each{ |var| return var if var.send(method).contains needle and (count -= 1).zero? }
		else
			each{ |var| return var if var.send(method).contains needle }
		end
		return nil
	end
end

class TCPSocket
	include Guest
end

class TCPServer
	include Guest
end