# coding: ISO-8859-1

remote = true if __FILE__ == "/var/myst/server/settings.rb"

if remote
	Website_directory = "/var/www/mud"
	Include_path = "/var/myst"
	Cache_dir = "/var/cache/cache"
	Hostname = "62.193.219.166"
	Mysql_gem = "module/mysql_api.so"
	Db_login = "admin"
else
	Website_directory = "c:/program files/lighttpd/htdocs/mud"
	Include_path = "c:/www/myst"
	Cache_dir = "c:/www/cache/cache"
	Hostname = "127.0.0.1"
	Mysql_gem = "mysql"
	Db_login = "root"
end

Db_server =	"localhost"
Db_pwd = "vesper007"
Db_name = "myst"
Port = 6022
Max_clients = 20
FloodLimit = 8