# coding: ISO-8859-1

class Actor
	def chat msg
		$guest.each do |guest|
			if heroe = guest.h
				heroe.s "chat::#0066FF::#{@name}</font> : #{msg}<font>"
			end
		end
	end

	def pray msg
		$pray << msg
		echo "#{$link ? "main" : "box"}::<b>Message re�u !</b>"
		$guest.each do |guest|
			if heroe = guest.h and heroe.immortal
				heroe.s "chat::#0066FF::#{@name} prie</font> : #{msg}<font>"
			end
		end
	end

	def say msg
		echo "chat::green::Vous dites : #{msg}"
		room_heroes.each do |heroe|
			heroe.s "chat::green::#{@name} dit : #{msg}"
		end
	end

	def shout msg
		echo "chat::3366cc::Vous criez : #{msg}"
		zone_heroes.each do |heroe|
			heroe.s "chat::blue::#{@name} crie : #{msg}"
		end
	end

	def tell heroe, msg
		heroe.wiz 	"<font color=purple>#{@name} vous dit : #{msg}</font>"
		wiz 		"<font color=purple>Vous dites � #{heroe} : #{msg}</font>"
	end
end

# class Actor
	# def chat msg
		# show :online, "#color{purple|#{@name}} : #{msg}"
	# end
	
	# def pray
		# $pray_history << msg
		# wiz "Message re�u !"
		# online_immortals.each{|i| i.wiz "#color{purple|#{@name} prie} : #{msg}"}
	# end
	
	# def say msg
		# wiz "Vous dites : #{msg}", :green
		# show(:room_heroes, :green){|heroe| "#{sb? heroe} dit : #{msg}"}# version avec gestion de l'invisibilit�
	# end
	
	# def sb? actor, maj=true
		# if actor.sees self then name else "#{maj ? "Q" : "q"}uelqu'un" end
	# end
	
	# def shout msg
		# wiz "Vous criez #{msg}", :skyblue
		# show :zone_heroes, "#{name} crie : #{msg}", :skyblue
	# end
	
	# def tell heroe, msg
		# heroe.wiz "#{@name} vous dit : #{msg}", :purple
		# wiz "Vous dites � #{heroe} : #{msg}", :purple
	# end
# end