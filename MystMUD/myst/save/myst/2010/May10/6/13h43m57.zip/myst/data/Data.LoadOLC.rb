# coding: ISO-8859-1

class Data::LoadOLC
	def self.array value
		Data::Load.array value
	end
	
	def self.bool value
		value.to_b
	end
	
	def self.equipement value
		value = eval value
		if value.is_a? Hash
			Data::Change.equipement value
		else
			{}
		end
	end
	
	def self.exits value
		Data::Change.exits hash(value)
	end
	
	def self.hash value
		Data::Load.hash value
	end
	
	def self.help value
		Data::Load.help value
	end
	
	def self.int value
		value.to_i
	end
	
	def self.inventory value
		value = eval value
		
		if value.is_a? Hash
			Data::Change.inventory value
		else
			{}
		end
	end
	
	def self.nil value
		nil
	end
	
	def self.sym value
		value.to_sym
	end
	
	def self.shortcut value
		Data::Load.shortcut value
	end
	
	def self.string value
		value
	end
end