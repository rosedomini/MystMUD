# coding: ISO-8859-1

class Data::Clone
	def self.array value
		value.clone
	end
	
	def self.bool value
		value
	end
	
	def self.equipement value
		value.clone
	end
	
	def self.hash value
		value.clone
	end
	
	def self.help value
		value
	end
	
	def self.int value
		value
	end
	
	def self.inventory value
		value.clone
	end
	
	def self.nil value
		nil
	end
	
	def self.sym value
		value
	end
	
	def self.shortcut value
		[value[0].clone, value[1].clone]
	end
	
	def self.string value
		value
	end
end