# coding: ISO-8859-1

class Fight
	def Fight.fighters
		f = $actor.values.select{ |actor| actor.target }
		tg = []
		
		f.each_with_index do |actor, i|
			if actor.target.room != actor.room
				actor.target = nil
			end
			unless actor.target
				f[i] = nil
			else
				actor.target.target = actor
				tg << actor.target
			end
		end
		
		f.delete nil
		
		(f + tg).uniq & $actor.values
	end


	def Fight.round
		f = Fight.fighters
		
		f.each do |a|
			tg = a.target
			if iid = a.equip[:main_gauche] and arme = $item[iid]
				if arme.stats[:damage]
					dmg = arme.stats[:damage]
				else
					dmg = 0
				end
				if arme.stats[:damage_type]
					dmg_type = $dmg_types[arme.stats[:damage_type]]
				else
					dmg_type = $dmg_types[:tappant]
				end
			else
				dmg = 3 * a.str
				dmg_type = $dmg_types[:frappant]
			end

			dmg += a.str * dmg / 100
			dmg -= tg.con
			
			if dmg < 0
				dmg = 0
			end
			
			dmg = (dmg * 0.7 + rand(dmg * 0.6)).to_i
			
			# <<<<<<<<< Application et affichage d'un potentiel coup critique <<<<<<<<
			if rand(9).zero?
				dmg = (dmg * 2.5).to_i
				
				a.s "chat::red::* Vous r�alisez un coup critique sur #{tg.name_for a} !"
				tg.s "chat::red::* #{a.nameFor tg} vous inflige un coup critique !"
				
				a.witness_heroes.each do |heroe|
					next if heroe == tg
					heroe.s "chat::red::* #{a.nameFor heroe} inflige un coup critique � #{tg.name_for heroe} !"
				end
			end
			# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	
			
			a.wiz "Vous #{dmg_type[1]} #{tg.name_for a}. (<font color=#3366CC>#{dmg}</font>)"
			tg.wiz "#{a.nameFor tg} vous #{dmg_type[0]}. (<font color=#3366CC>#{dmg}</font>)"
			
			if tg.hp -= dmg and a.heroe?	#
				a.add_xp tg.xp_gives		# Blesse la cible et si mort : renvoi les xp 
			end							#

			a.witness_heroes.each do |heroe|
				next if heroe == tg
				heroe.wiz "#{a.nameFor heroe} #{dmg_type[0]} #{tg.name_for heroe}. (#{dmg})"
			end
		end
		
		Fight.send_all f
		$task.timestamp = Time.now.to_f + 1.5
	end
	
	def Fight.send_all fighters
		fighters.each do |actor|
			if fighters.find_index(target = actor.target)
				adv = (100 * target.hp / target.maxhp).to_i
				actor.wiz "<br><span style=margin-left:25px>Vie : #{actor.hp}/#{actor.maxhp} &nbsp; Magie : #{actor.mp}/#{actor.maxmp} &nbsp; Adv. : <font color=#3366CC>#{adv}%</font></span>"
			end
		end
		$srv.send_all
	end
end
