# coding: ISO-8859-1

# V�rification des arguments pour chaque commande

class Actor	
	def check_aide
		if $x
			if command = $command[$x] and command.keyboard and command.authlevel <= @authlevel
				Cmd.aide $x
			elsif $x == "move" or $x == "shortcuts"
				Cmd.aide $x
			else
				echo "main::Cette commande n'existe pas."
			end
		else
			Cmd.aide
		end
	end

	def check_cast
		Error.cmd_unavailable
		# send spell.actor_method
	end
	
	def check_chat
		if $x
			chat $x
		else
			Cmd.aide "chat"
		end
	end
	
	def check_drag
		if $x =~ /^([^\d]+)( \d+)? to (.+)$/ # drag body (body_count) to direction
			
			if body = seen_bodies.find($1, $2)
				@room.exits.each_key do |exit_name|
					if $3 == exit_name.to_s[0, $3.length]
						drag body, exit_name
						return
					end
				end
				wiz "Vous ne pouvez pas aller par l�."	
			else
				wiz "Je ne vois pas ce corps."
			end
		else
			Cmd.aide "drag"
		end
	end

	def check_drop
		if $x == "*"
			@inv.each do |item, number|
				drop item, number
			end
		elsif (match = $x =~ /^(\*|\d+) (.+)$/) or $x
			needle = match ? $2 : $x
			@inv.each do |item, number|
				if item.name.contains needle
					num = match ? ($1 == "*" ? number : $1.to_i) : 1
					if num.zero?
						@inv.delete item
					else
						drop item, num
						return
					end
				end
			end
			wiz "Je ne trouve pas cet objet."
		else
			Cmd.aide "drop"
		end
	end
	
	def check_eat
		if $x
			msg = nil
			@inv.each do |item, number|
				if item.name.contains $x
					if item.type = :nourriture and item.stats[:rassasiment]
						eat item
						return
					else
						msg = "Un ogre affam� n'oserait pas !"
					end
				end
			end
			if msg
				wiz msg
			else
				wiz "Je ne trouve pas cet objet."
			end
		else
			Cmd.help "eat"
		end
	end

	def check_equipement
		show_equipement
	end

	def check_examine
		if $x =~ /^([^\d]+)( \d+)?$/
			if body = seen_bodies.find($1, $2)
				examine body
			elsif item = @inv.keys.find($1, $2)
				examine item
			else
				wiz "Vous ne poss�dez pas cet objet et n'apercevez pas ce corps."
			end
		else
			Cmd.aide "examine"
		end
	end

	def check_get
		if $x == "*" # get *
			if @room.inv.empty?
				wiz "Il n'y a rien � prendre ici."
			else
				@room.inv.each do |item, number|
					get item, number
				end
			end
			
		elsif $x =~ /^(\*|\d+ )?(.+ )?from ([^\d]+)( \d+)?$/ # get (number_of) sth|* from body (body_number)
		
			if $1.nil? and $2 != "* "
				Cmd.aide "get"
				return
			end
			
			if body = seen_bodies.find($3, $4)
				if $1
					needle = $2[0..-2]
					body.inv.each do |item, number|
						if item.name.contains needle
							to_pick = $1 ? ($1 == "* " ? number : $1.to_i) : 1
							get_from body, item, to_pick
							return
						end
					end
				else
					if body.inv.empty?
						wiz "Vous n'y trouvez rien � prendre."
					else
						body.inv.each do |item, number|
							get_from body, item, number
						end
					end
					return
				end
				wiz "Je ne trouve pas cet objet."
			else
				wiz "Ce corps n'est pas l�."
			end
			
		elsif $x =~ /^(\*|\d+ )?(.+)$/ # get (number_of) sth
			@room.inv.each do |item, number|
				if item.name.contains $2
					number = $1 ? ($1 == "* " ? number : $1.to_i) : 1
					get item, number
					return
				end
			end
			wiz "Je ne trouve pas cet objet."
		else
			Cmd.aide "get"
		end
	end

	def check_give actor = nil
		if $x =~ /^([^\W]+) ((\*|\d+) )?(.+)$/
			seen_actors.each do |a|
				if a.name.contains $1
					actor = a
					break
				end
			end
			unless actor
				wiz "Je ne vois pas cette personne."
			else
				@inv.each do |item, number|
					if item.name.contains $4
						num = $3 ? ($3 == "*" ? number : $3.to_i) : 1
						give actor, item, num
						return
					end
				end
				wiz "Je ne trouve pas cet objet."
			end
		else
			Cmd.aide "give"
		end
	end

	def check_inventory
		show_inventory
	end

	def check_kill
		if $x =~ /^([^\d]+)( \d+)?$/
			if actor = seen_actors.find($1, $2)
				kill actor
			else
				wiz "Je ne le vois pas."
			end
		else
			Cmd.aide "kill"
		end
	end

	def check_look
		if $x.nil?
			look_around
		elsif $x =~ /^([^\d]+)( \d+)?$/
			if actor = seen_actors.find($1, $2)
				look_actor actor
			else
				wiz "Cette personne n'est pas l�."
			end
		else
			Cmd.aide "look"
		end
	end

	def check_option
		if $x
			Cmd.option $x
		else
			Cmd.option
		end
	end

	def check_pray
		if $x
			pray $x
		else
			wiz "Vous n'avez pas entr� de message. Vous pouvez l'�crire l�-haut."
			echo "main::<u>Faire une demande ou signaler un probl�me quelconque :</u><br><br><textarea id=pray style=width:300px;height:100px></textarea><br>::('pray '+pray_replace(el('pray').value)-Envoyer)"
		end
	end

	def check_remove
		if $x =~ /^([^\d]+)( \d+)?$/
			if item = @equip.values.find($1, $2)
				remove @equip.key item
			else
				wiz "Vous ne portez pas cet objet."
			end
		else
			Cmd.aide "remove"
		end
	end

	def check_say
		if $x
			say $x
		else
			Cmd.aide "say"
		end
	end
	
	def check_selectAvatar!
		if $x and avatar = $avatar[$x]
			@avatar = avatar.source
			echo "top::_box::<b>Avatar mis � jour.</b>"
		end
	end

	def check_selectSkin!
		if $x and skin = $skin[$x]
			echo "top::_skin::#{@skin = skin.source}::_box::<b>Skin mis � jour.</b>"
		end
	end
	
	def check_special!
		if $x == "login"
			at_login
		else
			Error.cmd_hack "special"
		end
	end
	
	def check_shortcut!
		if $x =~ /^([^\W]+) (\d) ?(.+)?$/ and (no = $2.to_i) >= 0 and no < 10
			cmd_shortcut $1, no, $3
		else
			Error.cmd_hack "shortcut"
		end
	end

	def check_shout
		if $x
			shout $x
		else
			Cmd.aide "shout"
		end
	end

	def check_tell
		if $x =~ /^(\w+) (.+)$/
			$guest.each do |guest|
				if heroe = guest.h and heroe.name.same $1 and heroe != self
					tell heroe, $2
					return
				end
			end
			wiz "Cette personne n'existe pas."
		else
			Cmd.aide "tell"
		end
	end

	def check_time
		Cmd.time
	end

	def check_wear
		if $x =~ /^([^\d]+)( \d+)?$/
			if item = @inv.keys.find($1, $2)
				wear item
			else
				wiz "Vous ne poss�dez pas ou plus cet objet."
			end
		else
			Cmd.aide "wear"
		end
	end

	def check_who
		if $x and $x == "*"
			Cmd.who true
		else
			Cmd.who
		end
	end
end