# coding: ISO-8859-1

Lightblue = "#3399CC"

$dump = false

$refresh = 0 # nombre de ticks depuis le dernier boot

$classhash	= {} # both set with Dat.define
$olc		= {}

$default_shortcuts = [
	["Lettre 2",			"Sac 1",		"Masque 1",	"Skill 5",	"Parchemin 1",
		"Joyaux 6",		"Joyaux 6",		"Joyaux 6",		"Joyaux 6",		"Skill 6"],
		
	["option shortcut",	"inventory",	"who",			"get *",	"option",
		"o",			"n",			"s",				"e",			"aide"]
]

$wears = {
	:cheville_gauche => "Cheville gauche",
	:cheville_droite => "Cheville droite",
	:bras_gauche => "Bras gauche",
	:bras_droit => "Bras droit",
	:dos => "Dos",
	:torse => "Torse",
	:oreille_gauche => "Oreille gauche",
	:orielle_droite => "Oreille droite",
	:yeux => "Yeux",
	:doigt_gauche => "Doigt gauche",
	:doigt_droit => "Doigt droit",
	:pieds => "Pieds",
	:front => "Front",
	:gants => "Gants",
	:tete => "Tete",
	:jambes => "Jambes",
	:cou => "Cou",
	:taille => "Taille",
	:main_gauche => "Main gauche",
	:main_droite => "Main droite",
	:poignet_gauche => "Poignet gauche",
	:poignet_droit => "Poignet droit"
}

$months = {
	1 => 'Oxtanpus',
	2 => 'Arcanbis',
	3 => 'Myha',
	4 => 'Fyul',
	5 => 'Brhon',
	6 => 'Mist',
	7 => 'Adrea',
	8 => 'Neptus',
	9 => 'Sircanceas',
	10 => 'Learius',
	11 => 'Tarnas'
}

$dmg_types = {
	:tranchant => ["tranche", "tranchez"],
	:frappant => ["frappe", "frappez"],
	:tappant => ["tape", "tapez"]
}

$exits = {
	:nord => "le nord",
	:sud => "le sud",
	:ouest => "l'ouest",
	:est => "l'est",
	:haut => "le haut",
	:bas => "le bas",
}

$task = nil
