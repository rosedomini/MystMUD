# coding: ISO-8859-1

# Gestion des connexions

class Server
	attr_accessor :server
	attr_accessor :task_id
	attr_accessor :lastsave
	attr_accessor :time
	attr_accessor :flood
	
	def initialize
		@tasks_time	= Time.now
		@flood_time		= 0
		@online_players= 0
		@fight_amount	= 0
		@lastsave			= 0
		@time 				= 0
		@policy = '<?xml version="1.0"?> 
<!DOCTYPE cross-domain-policy SYSTEM "http://www.adobe.com/xml/dtds/cross-domain-policy.dtd"> 
<cross-domain-policy>  
    <allow-access-from domain="*" to-ports="6022" />
</cross-domain-policy>'<<"\0"
		# @policy	= ""
	end
	
	def run		
		@server = TCPServer.new(Hostname, Port)
		@server.set_encoding "ISO-8859-1"
		$guest << @server

		puts "Server started at #{Hostname}:#{Port})\n\n"
		
		loop do
			if (t = Time.now) - @tasks_time > 0.4
				@tasks_time = t
				do_tasks
			end
			ready = select $guest, nil, nil, 0.5
			
			@time = Time.now.to_f
			
			next if ready.nil?
			
			for sock in ready[0]
				if sock == @server	
					@online_players += 1
					begin
						sock = @server.accept_nonblock
						sock.new_guest
						$guest << sock
						sock.write @policy
						puts "Client joined"
					rescue
						puts "server/server.rb:#{__LINE__} #{$!.inspect}"
					end
				elsif sock.off
					sock.eject
				else
					next if (arg = sock.gets[0..-2]) == "<policy-file-request/>"
					arg = CGI.escapeHTML arg.gsub("\\", "").gsub(/::/, ": :")
					
					if @flood_time <= @time
						@flood_time = @time + 1
						$guest.each{ |guest| guest.flood = 0 }
					end
					
					sock.flood += 1
					if sock.flood > FloodLimit
						sock.eject "Flood interdit"
						next
					end
					
					sock.__send__ sock.control, arg
					
						# begin
							# sock.h.cmd arg
						# rescue
							# puts "\n\t\t******** ERROR ************\n\n"
							# puts "#{caller[0]} : #{$!} (#{$!.class})\n\tfrom #{caller[0..-1].join("\n\tfrom ")}"
							# $g.each do |g|
								# if h = g.h then g.write "alert::Une erreur critique est survenue !\nle serveur va red�marrer automatiquement ce qui entra�nera un retour en arri�re de #{(($srv.time - $srv.lastsave) / 60).round} minutes.\n\nSi cela vous concerne : certaines donn�es concernant le probl�me ont �t� enregistr�es mais toute information compl�mentaire pourrait aider � sa r�solution (commande pray). Si cette faille vient d'�tre exploit�e pour permettre un retour en arri�re, �a se saura sans probl�me." end
							# end
							# raise "reload world"
						# end

					send_all
					
					puts "Executed #{arg} in #{(1000000*(Time.now.to_f - @time)).round}us\n"
				end
			end
		end
	end
	
	def online_players
		$actor.size
	end
	
	def do_tasks
		$t.each do |task|
			if task.timestamp < @time
				$task = task
				task.execute
				$t.delete(task) if task.del
				send_all
			end
		end
		$task = nil
	end

	def send_all
		$guest.each do |g|
			if h = g.h and h.msg.length > 0
				h.send_msg g
			end
		end
	end
	
	def Server.update_cache name # cache name
		$task.timestamp = $srv.time + 17
		
		if name == "server"
			set_cache "server", "#{$srv.time},#{$srv.online_players}"
		elsif name == "world"
			set_cache "world", "#{$zone.count},#{$item.count},#{$mob.count},#{$heroe.count},#{$shop.count},#{$spell.count},#{$skin.count},#{$avatar.count}"
		end
	end
end
