# coding: ISO-8859-1

# V�rification des arguments pour les commandes admin

class Actor
	def check_clone
		if $x =~ /^(\w+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				Cmd.clone $1, $2.to_i
			else
				Error.olc_class
			end
		elsif $x =~ /^(\w+) (\w+)$/
			if $olc[$1] and $classhash[$1][$2]
				Cmd.clone $1, $2
			else
				Error.olc_class
			end
		else
			Cmd.help "clone"
		end
	end
	
	def check_dump
		begin
			if $x
				Cmd.dump $x
			else
				Cmd.dump
			end
		rescue
			wiz "Erreur : #{$!}"
		end
	end

	def check_edit
		if $x =~ /^(\w+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				Cmd.edit $1, $classhash[$1][$2.to_i]
			else
				Error.olc_class
			end
		elsif $x =~ /^(\w+) (\w+)$/
			if $olc[$1] and $classhash[$1][$2]
				Cmd.edit $1, $classhash[$1][$2]
			else
				Error.olc_class
			end
		else
			Cmd.help "clone"
		end
	end

	def check_force
		if $x =~ /^(\w+) to (.+)$/
			room_actors.each do |actor|
				if actor.name.contains $1
					actor.cmd "!#{$2}"
					return
				end
			end
			echo "Cette personne n'est pas l�"
		else
			Cmd.help "force"
		end
	end

	def check_giveXp
		if $x =~ /^([\w ]+) (\d+)$/
			if (amount = $2) > 0
				$guest.each do |guest|
					if heroe = guest.h and heroe.name.same $1
						Cmd.giveXp heroe, amount
						return
					end
				end
				wiz "Cette personne n'existe pas."
			else
				wiz "l'exp�rience acquise ne peut pas �tre retir�e !"
			end
		else
			Cmd.help "giveXp"
		end
	end

	def check_goto
		if $x and room = $room[$x.to_i]
			goto room
		else
			goto
		end
	end

	def check_help
		if $x and $command[$x]
			Cmd.help $command[$x]
		else
			Cmd.help nil
		end
	end
	
	def check_include
		Cmd.include $x
	end

	def check_lvUp
		unless $x
			Cmd.help "lvUp"
			return
		end
		$guest.each do |guest|
			if heroe = guest.h and heroe.name.same $1
				Cmd.lvUp heroe
				return
			end
		end
		wiz "Cette personne n'existe pas."
	end
   
	def check_olc
		if $x.nil?
			Cmd.olc
		elsif $olc[$x]
			Cmd.olc $x
		else
			Error.olc_class
		end
	end

	def check_olcShow
		if $x =~ /^(\w+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				Cmd.olcShow $1, $classhash[$1][$2.to_i]
			else
				Error.olc_class
			end
		elsif $x =~ /^(\w+) (\w+)$/
			if $olc[$1] and $classhash[$1][$2]
				Cmd.olcShow $1, $classhash[$1][$2]
			else
				Error.olc_class
			end
		else
			Cmd.help "olcShow"
		end
	end
	
	def check_rcreate
		if $x =~/^[bonseh]$/
			rcreate $x.to_sym
		else
			wiz "Les directions possibles sont n-s, o-e, h-b"
		end
	end

	def check_redit
		redit($x == "close")
	end

	def check_ruby
		if $x
			Cmd.ruby CGI.unescapeHTML $x
		else
			Cmd.ruby
		end
	end

	def check_set
		if $x =~ /^(\w+) (\w+) (\w+) (.+)$/
			if a = $classhash[cls = $1] and $olc[cls].find_index(var = $3)
				if o = a[$2.to_i] or o = a[$2]
					Cmd.set cls, o, var, CGI.unescapeHTML($4)
				end
			else
				Error.olc_class
			end
		else
			Cmd.help "set"
		end
	end

	def check_summonItem
		if $x =~ /^(\d+) (\d+)$/
			if item = $item[$1.to_i] and (number = $2.to_i) > 0
				Cmd.summonItem item, number
			else
				wiz "Cet objet n'existe pas."
			end
		else
			Cmd.help "summonItem"
		end
	end
end