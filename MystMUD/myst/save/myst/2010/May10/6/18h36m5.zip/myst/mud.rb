# coding: ISO-8859-1

=begin Arguments :
		check_cmd pour v�rifier la liste des commandes
=end

# Script principal

GC.disable

print "Parsing... "

trap "SIGINT", proc{ $srv.server.close ; $db.close ; exit } # �x�cut� avec Control + C

$actor		= $a	= {}
$avatar			= {}
$body		= $b	= {}
$command			= {}
$data				= {}
$god				= {}
$guest		= $g	= []
$heroe		= $h	= {}
$icon				= []
$item		= $i	= {}
$mob				= {}
$race				= {}
$room		= $r	= {}
$shop				= {}
$skin				= {}
$spell		= $sp	= {}
$system	= $sys	= {}
$tasks		= $t	= []
$world				= {}
$zone				= {}

require "server/settings"

require Mysql_gem
require "date"
require "cgi"
require "digest/md5"
require "socket"
include Socket::Constants

require "module/Receive"

require "class/Avatar"
require "class/Body"
require "class/Item"
require "class/Race"
require "class/Room"
require "class/Shop"
require "class/Skin"
require "class/Spell"
require "class/Zone"

require "data/Data.Change"
require "data/Data.Clone"
require "data/Data.Load"
require "data/Data.LoadOLC"
require "data/Data"
require "data/Data.Save"
require "data/Data_define"

require "server/globals"
require "server/guest"
require "server/load"
require "server/save"
require "server/server"
require "server/task"

require Cache_dir

require "cmd/Command"
require "cmd/Cmd"
require "cmd/divers_a"
require "cmd/olc"
require "cmd/gestion_a"

require "func/Error"
require "func/fight"
require "func/function"
require "func/modifications"
require "func/System"
require "func/time"

require "actor/Actor"
require "actor/God"
require "actor/Heroe"
require "actor/Mob"

require "actor/action"
require "actor/admin"
require "actor/check"
require "actor/check_admin"
require "actor/gestion"
require "actor/communication"
require "actor/lists"

require "world/World"

Dat.define

$db = Mysql.real_connect(Db_server, Db_login, Db_pwd, Db_name)

Load.world

$w = $world[1]

$db.close

if ARGV[0] == "check_cmd"
	$command.each do |name, cmd|
		if cmd.link and !Actor.instance_methods.find_index("check_#{name}!".to_sym)
			puts "Method unavailable: check_#{name}! for command\n\t#{cmd.inspect}\n\n"
		elsif !cmd.link and !Actor.instance_methods.find_index("check_#{name}".to_sym)
			puts "Method unavailable: check_#{name} for command\n\t#{cmd.inspect}\n\n"
		end
	end
	Actor.instance_methods.each do |method|
		if method.to_s =~ /^check_(\w+)(!)?$/
			if cmd = $command[$1]
				if $2 and !cmd.link
					puts "$command[#{$1.inspect}] is not a indicated as a link"
				elsif $2.nil? and !cmd.keyboard
					puts "$command[#{$1.inspect}] is not indicated as working with keyboard"
				end
			else
				puts "undefined $command[#{$1.inspect}]"
			end
		end
	end
	exit
end

$srv = $server = Server.new

$srv.run
