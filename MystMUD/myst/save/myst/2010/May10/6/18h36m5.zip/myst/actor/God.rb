# coding: ISO-8859-1

class God
	attr_accessor :id
	attr_accessor :redit
	
	def initialize id
		@id = id
		@redit = false
	end
	
	def inspect
		"$god[#{@id}]"
	end
	
	def to_s
		"<font color=yellow>#{$actor[@id]}</font>"
	end
end
