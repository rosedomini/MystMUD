# coding: ISO-8859-1

# D�finition de la classe command

class Command
	attr_accessor :id, :name
	attr_accessor :type
	attr_accessor :mob
	attr_accessor :ko
	attr_accessor :authlevel
	attr_accessor :keyboard, :link
	attr_accessor :syntax, :help
	
	def initialize id
		@name = @id = id
	end
	
	def admin
		authlevel > 0
	end
	
	def to_s
		@name
	end
end