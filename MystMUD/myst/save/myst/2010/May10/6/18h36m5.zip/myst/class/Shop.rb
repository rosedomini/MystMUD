# coding: ISO-8859-1

class Shop
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :keeper
	attr_accessor :room
	attr_accessor :inv
	
	def initialize id
		@id = id
	end
end