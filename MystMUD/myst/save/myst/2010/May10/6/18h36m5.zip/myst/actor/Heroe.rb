# coding: ISO-8859-1

class Heroe < Actor
	attr_accessor :desc
	attr_accessor :msg
	attr_accessor :shortcut
	attr_accessor :password
	attr_accessor :authlevel
	attr_accessor :xp
	attr_reader :hunger
	
	def initialize id
		new_actor id
		
		@msg = ""
		@hunger = 0
	end
	
	def after_load
		@status = :none
		@msg.clear
	end
	
	def add_xp xp_to_add
		wiz "<br>Vous acqu�rissez de l'exp�rience : <font color=#3366CC>#{xp_to_add}</font> points."
		@xp += xp_to_add
		while @xp >= xp_needed
			@xp -= xp_needed
			level_up
		end
	end

	def echo message
		@msg << "#{message}::_"
	end
	
	def heroe?
		true
	end
	
	def hunger= value
		if @hunger < value
			if value < 0
				@hunger = 0
			elsif value > 1200
				@hunger = 1200
				wiz "Vous �tes compl�tement rassasi�."
			else
				@hunger = value
			end
		else
			if (@hunger = value) < 0
				wiz "Vous avez #{"tr�s "*(-value/900).truncate}faim."
			end
		end
	end
	
	def inspect
		"$heroe[#{@id}]"
	end
	
	def killed
		s = case rand 3
			when 0 then	"#{@name} tombe raide mort."
			when 1 then	"#{@name} expire son dernier souffle."
			else 			"#{@name} s'�croule dans une marre de sang."
		end
		
		wiz "<font color=red>Vous vous �croulez, vide d'�nergie...</font>"
		
		room_heroes.each{ |heroe| heroe.wiz s }
		
		body = $body << Body.new($body.new_id).create(@id, 720, @room)
		
		inventory = body.inv
		
		@equip.each_value do |id|
			if inventory[id]
				inventory[id] += 1
			else
				inventory[id] = 1
			end
		end
		
		inventory |= @inv
		
		@inv, @equip, @status, @hp, @room = {}, {}, "", @maxhp, 1
		
		$actor.each_value do |actor|
			if actor.target and actor.target.id == @id 
				actor.target = nil
			end
		end
		
		look_around
	end
	
	def level_up
		@level += 1
		wiz "<font color=blue>Votre niveau s'am�liore : #{@level} !</font>"
		case rand 4
			when 0 then @dex += 3
			when 1 then @wis += 3
			when 2 then @con += 3
			when 3 then @str += 3
		end
		@maxhp += @con
		@maxmp += @wis
		@hp = @maxhp
		@mp = @maxmp
	end
	
	def mob?
		false
	end
	
	def online?
		$actor[self]
	end
	
	def s message
		@msg << "#{message}::_"
	end
	
	def send_msg guest
		@msg << "health::#{@hp}::#{@maxhp}::#{@mp}::#{@maxmp}::_"
		
		if @msg.length > 2048
			@msg.scan(/.{1,2048}/).each{|s| guest.write s}
		else
			guest.write @msg
		end
		
		p @msg if $dump
		@msg = ""
	end
	
	def show_shortcuts
		@msg << "shortcuts::"
		commands = @shortcut[1]
		@shortcut[0].each_with_index do |icon, i|
			@msg << ";#{icon},#{commands[i]}"
		end
		@msg << "::_"
	end
	
	def wiz message
		@msg << "box::#{message}::_"
	end
	
	def xp_needed
		2*(@level**2)*(@level+50)*(1+0/3) # replace 0 with @ren
	end
end
