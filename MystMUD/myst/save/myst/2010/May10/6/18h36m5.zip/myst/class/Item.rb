# coding: ISO-8859-1

class Item
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :type
	attr_accessor :weight
	attr_accessor :wearon
	attr_accessor :desc
	attr_accessor :stats
	attr_accessor :power
	attr_accessor :required
	attr_accessor :value
	
	def initialize id
		@id = id
	end
	
	def clone
		$data[:Item].copy_from @id		
	end
	
	def inspect
		"$item[#{@id}]"
	end
	
	def x number
		if number == 1
			@name
		else
			"#{@name} (x#{number})"
		end
	end
end