# coding: ISO-8859-1

# fonctions des commandes admin de gestion

class Cmd
	def Cmd.giveXp p, xp # player, amount of experience
		p.add_xp xp
	end

	def Cmd.lvUp p #player
		p.add_xp p.xp_needed - p.xp
	end

	def Cmd.force a, c # forces actor a to execute command c
		Task.cmd a, c
	end
end