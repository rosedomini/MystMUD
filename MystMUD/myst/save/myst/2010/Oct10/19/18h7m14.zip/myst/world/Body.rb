﻿
class Body
	attr_reader :id, :aid, :actor, :name, :room, :expire, :inv
	attr_writer :inv, :room
	alias to_s name
	
	def create actor, expire, room
		n = (@actor = actor).name
		@name = "le corps d#{n[0] =~ /[aeiouy]/i ? '\'': 'e '}#{n}"
		@expire = wtime + expire
		@inv = Inventory.new
		(@room = room) << self
		self
	end
	
	def initialize id = $body.new_id; @id = id end
	def inspect; "$body[#{@id}]" end
	
	def over
		@room.inv << @inv
		@room.heroes.wiz "#{@name.capitalize} se décompose."
		@room >> self
		$body.delete @id
	end
	
	def room_destroyed
		@room >> self
		(@room = Room.near @room) << self
	end
end
