﻿	
class Mob < Actor
	attr_reader :lastRepop

	def initialize id
		super id
		@lastRepop = @authlevel = 0
	end
	
	# def after_load; super end
	
	def echo sth, color = nil; end
	def heroe?; false end
	
	def inspect
		if $mob[@id] == self then "$mob[#{@id}]" else "$mob[#{@id}].clone"
	end end
	
	def killed actor = nil		
		case rand 3
			when 0 then s = "#{@name} tombe raide mort."
			when 1 then s = "#{@name} expire son dernier souffle."
			else s = "#{@name} s'écroule dans une marre de sang."
		end
		
		each_close_heroe{ |heroe| heroe.wiz s }
		
		actor.add_xp xp_gives(actor) if actor and actor.heroe?
		
		$body << body = Body.new.create(self, 720, @room)
		body_inv = body.inv = @inv
		
		@equip.each_value do |item|
			body_inv << item
		end
		
		get_peace
		
		@room >> self
		$actor.delete @id
	end
	
	def mob?; true end
	def online?; self != $mob[@id] end
	
	def repop force = nil
		mins = wtime()
		if (force or mins - @lastRepop > 120) and $actor[@id].nil?
			@lastRepop = mins
			$actor[@id] = actor = $data[:Mob].copy_from($mob[@id])
			actor.room << actor
			actor.room.heroes.wiz "#{actor} surgit de nulle part."
		end
	end
	
	def wiz sth, color=nil; end
		# if @master
			# @master.wiz "&gt; #{sth.gsub "<br>", "<br>&gt; "}"
		# end
	# end
end

class << Mob
	def named name
		$mob.value_named name
	end
	
	def repop force = nil
		$mob.each_value do |mob|
			mob.repop force unless $actor[mob.id]
		end
	end
end