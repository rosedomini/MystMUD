
Power.new(:gain_de_vie, -> power{
	$p.instance_eval{
		heal power
		wiz "Vos blessure se referment. Vous vous sentez mieux ~ #{power} points."
	}
})