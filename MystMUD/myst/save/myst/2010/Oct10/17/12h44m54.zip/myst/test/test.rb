﻿
Data_path = 'c:/var/save/myst_data'

class Dat; end
class << Dat
	def load klass
		file = File.open "#{Data_path}/#{klass}.rb"
		data = file.read
		file.close
		list = eval "[#{data}]"
	end
end

klass = 'Room'

list = Dat.load klass

list.each do |hash|
	puts "##{klass} #{hash[:id]}\n{"
	hash.each do |name, value|
		puts "\t#{name.inspect} => #{value.inspect}"
	end
	print "},\n\n"
end

