﻿
Remote = (__FILE__ == "/m/myst/srv/settings.rb")

if Remote
	Website_directory = "/m/mud"
	Include_path = "/m/myst"
	Cache_dir = "/m/cache/cache"
	Data_path = "/m/save/myst_data"
	Backup_Dir = "/m/save/old_myst_data"
	Logpath = "/m/logs"
	Hostname = "62.193.219.166"
	# Db_login = "admin"
	# Db_pwd = "gCyOyA1@"
	Mud_path = "/m"
else
	Website_directory = "c:/var/mud"
	Include_path = "c:/var/myst"
	Cache_dir = "c:/var/cache/cache"
	Data_path = "c:/var/save/myst_data"
	Backup_Dir = "c:/var/save/old_myst_data"
	Logpath = "c:/var/local_logs"
	Hostname = "127.0.0.1"
	# Db_login = "root"
	# Db_pwd = "vesper007"
	Mud_path = "c:/var"
end

# Db_server =	"localhost"
# Db_name = "myst"
Port = 6021
Max_clients = 20
FloodLimit = 8