﻿
def Dat.load type, value, olc = nil
	case type
	when 'Area'
		$area[value.to_i]
	when 'Actor'
		$actor[value.to_i]
	when 'Room'
		$room[value.to_i]
	when 'bool'
		value.to_b
	when 'Fixnum'
		value.to_i
	when 'String'
		value
	when 'Symbol'
		value.to_sym
	when 'value'
		Kernel.eval value
	when 'area_list'
		if (value = eval value).is_a? Array
			value.each_with_index do |x, i|
				unless value[i] = $area[x]
					raise "There is no Area at index #{x}"
			end end
			value
		else raise 'The area_list to load should look like an Array.' end
	when 'Array'
		if (a = eval value).is_a? Array then a else raise 'This is not an Array!' end
	when 'Equipement'
		if (value = eval value).is_a? Hash
			equip = {}
			value.each do |wear, item_id|
				if item = $item[item_id] then equip[wear] = item
				else equip.delete wear
			end end
			equip
		else raise 'The Equipement to load should look like a hash.' end
	when 'exit_list'
		if (exits = eval value).is_a? Hash
			exits.each do |name, room_id|
				if room = $room[room_id] then exits[name] = room
				else exits.delete name end
			end
			exits
		else raise 'The exit_list to load should look like a hash.' end
	when 'Hash'
		if (h = eval value).is_a? Hash then h else raise 'This is not a Hash!' end
	when 'Inventory'
		if (value = eval value).is_a? Hash
			inv = Inventory.new
			Inventory.new(value).each do |id, number|
				if item = $item[id] and number > 0 then inv[item] = number
				else inv.delete id
			end end
			inv
		else raise 'The Inventory to load should look like a hash.' end
	when 'shortcut'
		s = eval value
		if s.is_a? Array and s[0].is_a? Array and s[1].is_a? Array and
			s.size==2 and s[0].size==10 and s[1].size==10
		then s else Actor::Shortcut end
	when 'spell_list'
		if (value = eval value).is_a? Hash
			list = {}
			value.each do |id, pow|
				if spell = $spell[id] then list[spell] = pow
				else list.delete id
			end end
			list
		else  raise 'The spell_list to load should look like a hash.' end
	when 'command_help'
		# value.gsub!(/\n/, '<br>')
		value
	when 'command_syntax'
		# (value = CGI.escapeHTML value).gsub!(/(( from )|( to )|( on ))/) do
			# " <a class=syntax href=\"javascript:p('aide keywords')\">#{$1.strip!}</a> "
		# end
		# value.gsub!(/&lt;([\w-]+)&gt;/,
			# '<a class=syntax href="javascript:p(\'aide syntax \\1\')">\\1</a>')
		value
	else raise "Can't load type: #{type}"
end end

__END__

def Dat.load type, value, olc = nil
	case type
	when 'Area'
		# $area[value.to_i]
		$area[value]
	when 'Actor'
		# $actor[value.to_i]
		$actor[value]
	when 'Room'
		# $room[value.to_i]
		$room[value]
	when 'bool'
		# value.to_b
		value
	when 'Fixnum'
		# value.to_i
		value
	when 'String'
		value
	when 'Symbol'
		# value.to_sym
		value
	when 'value'
		# Kernel.eval value
		value
	when 'area_list'
		# if (value = eval value).is_a? Array
		if value.is_a? Array
			value.each_with_index do |x, i|
				unless value[i] = $area[x]
					raise "There is no Area at index #{x}"
			end end
			value
		else raise 'The area_list to load should look like an Array.' end
	when 'Array'
		# if (a = eval value).is_a? Array then a else raise 'This is not an Array!' end
		if value.is_a? Array then value else raise 'This is not an Array!' end
	when 'Equipement'
		# if (value = eval value).is_a? Hash
		if value.is_a? Hash
			equip = {}
			value.each do |wear, item_id|
				if item = $item[item_id] then equip[wear] = item
				else equip.delete wear
			end end
			equip
		else raise 'The Equipement to load should look like a hash.' end
	when 'exit_list'
		# if (exits = eval value).is_a? Hash
			# exits.each do |name, room_id|
				# if room = $room[room_id] then exits[name] = room
				# else exits.delete name end
			# end
			# exits
		if value.is_a? Hash
			value.each do |name, room_id|
				if room = $room[room_id] then value[name] = room
				else value.delete name end
			end
			value
		else raise 'The exit_list to load should look like a hash.' end
	when 'Hash'
		# if (h = eval value).is_a? Hash then h else raise 'This is not a Hash!' end
		if value.is_a? Hash then value else raise 'This is not a Hash!' end
	when 'Inventory'
		# if (value = eval value).is_a? Hash
		if value.is_a? Hash
			inv = Inventory.new
			Inventory.new(value).each do |id, number|
				if item = $item[id] and number > 0 then inv[item] = number
				else inv.delete id
			end end
			inv
		else raise 'The Inventory to load should look like a hash.' end
	when 'shortcut'
		# s = eval value
		s = value
		if s.is_a? Array and s[0].is_a? Array and s[1].is_a? Array and
			s.size==2 and s[0].size==10 and s[1].size==10
		then s else Actor::Shortcut end
	when 'spell_list'
		# if (value = eval value).is_a? Hash
		if value.is_a? Hash
			list = {}
			value.each do |id, pow|
				if spell = $spell[id] then list[spell] = pow
				else list.delete id
			end end
			list
		else  raise 'The spell_list to load should look like a hash.' end
	when 'command_help'
		value.gsub!(/\n/, '<br>')
		value
	when 'command_syntax'
		(value = CGI.escapeHTML value).gsub!(/(( from )|( to )|( on ))/) do
			" <a class=syntax href=\"javascript:p('aide keywords')\">#{$1.strip!}</a> "
		end
		value.gsub!(/&lt;([\w-]+)&gt;/,
			'<a class=syntax href="javascript:p(\'aide syntax \\1\')">\\1</a>')
		value
	else raise "Can't load type: #{type}"
end end