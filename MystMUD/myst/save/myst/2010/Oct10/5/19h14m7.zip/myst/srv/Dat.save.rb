﻿
def Dat.save type, value, olc = nil
	case type
	when 'Actor'
		value.id.to_s
	when 'Area'
		value.id.to_s
	when 'Room'
		value.id.to_s
	when 'bool'
		value.to_str
	when 'Fixnum'
		value.to_s
	when 'String'
		value
	when 'Symbol'
		value.to_s
	when 'value'
		value.inspect
	when 'area_list'
		value = value.clone
		value.each_with_index{|x, i| value[i] = x.id}
		value.inspect
	when 'Array'
		value.inspect
	when 'Equipement'
		(equip = value.clone).each do |wear, item|
			equip[wear] = item.id
		end
		equip.inspect
	when 'exit_list'
		value = value.clone
		value.each{|exit, room| value[exit] = room.id}
		value.inspect
	when 'Hash'
		value.inspect
	when 'Inventory'
		inv = {}
		value.each do |item, number|
			inv[item.id] = number unless number.zero?
		end
		inv.inspect
	when 'shortcut'
		value.inspect
	when 'spell_list'
		list = {}
		value.each{|spell, pow| list[spell.id] = pow}
		list.inspect
	when 'command_help'
		raise 'This should not be saved.'
	when 'command_syntax'
		raise 'This should not be saved.'
	else raise "Can't save type: #{type}"
end end