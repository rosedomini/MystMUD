﻿
class Area
	attr_reader :id, :name, :room
	alias to_s name
	
	def initialize id = $area.new_id
		@id = id
		@room = []
	end
	
	def inspect; "$area[#{@id}]" end
end