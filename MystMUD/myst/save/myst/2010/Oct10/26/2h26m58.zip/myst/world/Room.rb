﻿
class Room
	attr_reader :id, :name, :desc, :x, :y, :z, :area
	attr_reader :actors, :bodies, :exits, :inv, :items # items est la liste d'objets qui sont par défaut dans cette salle
	alias to_s name
	
	Exit = {
		:nord => 'le nord',
		:sud => 'le sud',
		:ouest => 'l\'ouest',
		:est => 'l\'est',
		:haut => 'le haut',
		:bas => 'le bas',
		:nowhere => 'nulle part'
	}
	
	def initialize id = $room.new_id; @id = id end
	
	def destroy
		$room.delete @id
		$w.delete_room_index @x, @y, @z
		$room.each_value do |room|
			if exit = room.exits.key(self)
				room.exits.delete exit
			end
		end
		@actors.map &:room_destroyed
		@bodies.map &:room_destroyed
		Room.near(self).inv << @inv
		@area.room.delete @id if @area
		@destroyed = true
		freeze
	end
	
	# permet de mettre à jour les listes @actors et @bodies
	def << object
		if object.is_a? Actor
			@actors << object
			Task.add(self, :on_enter, 0, -0.3, object) if object.online?
		elsif object.is_a? Body then @bodies.insert 0, object
		else
			$! = 'Room#<< only accepts Actors or Bodies.'
			Error.display
		end
		object
	end
	
	# permet de mettre à jour les listes @actors et @bodies
	def >> object
		if object.is_a? Actor then @actors.delete_one object
		elsif object.is_a? Body then @bodies.delete_one object
		else
			$! = 'Room#>> only accepts Actors or Bodies.'
			Error.display end
		object
	end
	
	def after_load
		@actors = []
		@bodies = []
		$body.each_value{|x| @bodies << x if x.room == self}
		if @area and !@area.room.include? self
			@area.room << self
		end
	end
	
	def heroes; @actors.select &:heroe? end
	def inspect; "$room[#{@id}]" end
	
	# réapparition des objects par défaut de la salle s'ils ont disparus
	def item_repop
		@items.each do |item, number|
			if num = @inv[item] then @inv[item] = number if num < number
			else @inv[item] = number
	end end end
	
	def mobs; @actors.select &:mob? end
	
	def on_enter actor
		if actor.room == self
			@actors.each do |x|
				if x.respond_to? :on_see and x.sees actor
					x.on_see actor
	end end end end
	
	def wiz msg, color = nil; @actors.wiz msg, color end
end

class << Room
	def near x, y = nil, z = nil
		if x.is_a? Room
			y, z = x.z, x.z
			x = x.x
		end
		min_dist = 999
		choise = nil
		$room.each_value do |room|
			if min_dist > dist = (room.x-x)**2+(room.y-y)**2+(room.z-z)**2
				min_dist = dist
				choise = room
			end end
		choise
	end
end
