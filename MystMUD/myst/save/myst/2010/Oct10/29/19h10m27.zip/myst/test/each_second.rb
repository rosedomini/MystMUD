﻿
class Actor
	def each_second
		@aff.each_key{|aff| unaffect aff if (@aff[aff] -= 1).zero?}
		heal hp_arrows_useful, true unless @hp_arrows.zero?
		heal mp_arrows_useful true unless @mp_arrows.zero?
	end
end

class << Task
	def each_second
		$actor.each &:each_second
	end
end