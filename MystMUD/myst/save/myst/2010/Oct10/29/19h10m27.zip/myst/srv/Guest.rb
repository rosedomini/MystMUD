﻿
module Guest
	attr_reader :h, :flood, :control
	attr_writer :h, :flood, :control
	
	def new_guest
		@flood = 0
		@control = :start
		# set_encoding "UTF-16BE"
		# set_encoding "UTF-8"
		# set_encoding "ISO-8859-1"
	end
	
	def eject reason = nil
		wiz reason if reason
		@h.log_out if @h
		$guest.delete self
		close
	end
	
	def e
		'e' if @desc and @desc[:sex] and @desc[:sex] == 2
	end
	
	def off
		begin eof
		rescue
			Kernel.puts "server/guest.rb:#{__LINE__} #{$!.inspect}"
			true
		end
	end
	
	def wiz sth, color=nil
		if color
			sth = "box::<font color=#{color}>#{sth}</font>::_"
		else
			sth = "box::#{sth}::_"
		end
		
		if sth.length > 2048
			sth.scan(/.{1,2048}/).each{|x| write x}
		else
			write sth
		end
	end
	
	def start arg
		return if arg == '&lt;policy-file-request/&gt;'
		@login_heroe = $heroe.each_value{|heroe| break heroe if heroe.name.same arg}
		if @login_heroe.is_a? Heroe
			@control = :login_password
			wiz "Entrez un mot de passe pour #{@login_heroe} :"
		else @login_heroe = nil
			if arg =~ /^\w{3,10}$/
				arg = arg.downcase.capitalize
				wiz "Bienvenue #{@name = arg}! Quel sera votre mot de passe ?"
				@control = :register_password
			else
				wiz 'Merci d\'entrer un nom de 3 à 10 lettres.'
			end
		end
	end
	
	def login_password arg
		if @login_heroe.password == Digest::MD5.hexdigest(arg)
		
			$guest.select{|guest| guest.h == @login_heroe}.each do |guest|
				guest.eject 'Une autre instance réclame ce personnage. Déconnexion forcée.'
			end
			
			@h = @login_heroe
			@h.room << $actor[@h.id] = @h
			@control = :normal
			
			Kernel.puts "login: #{@h.name}\n"
			
			@h.log_in self
		else
			wiz 'Mot de passe erroné.<br>Entrez votre nom :'
			@control = :start
		end
	end
	
	def register_password arg
		if arg =~ /^(\w|\d){5,13}$/
			wiz "Votre mot de passe est <b>#{arg}</b>. Vous pourrez le changer via la commande <b>account</b>.<br>Une voix profonde et mystérieuse vous parle.<br>Cliquez sur un des liens ou entrez au clavier votre choix.<br><br><font color=green>Serez-vous un ::[1-homme] ou une ::[2-femme] ?</font>"
			@desc = {}
			@password = Digest::MD5.hexdigest(arg)
			@control = :desc_sex
		else
			wiz 'Le mot de passe doit être formé par 5 à 13 caractères alphanumériques.'
		end
	end
	
	def desc_sex arg
		if 'homme'.contains arg then arg = 1
		elsif 'femme'.contains arg then arg = 2 end
		if (arg = arg.to_i).zero? or arg > 2
			wiz 'Ceci ne figure pas parmis les choix.', :red
		else
			s = case @desc[:sex] = arg
				when 1 then 'Un homme, vous serez.'
				when 2 then 'Une femme, vous serez.'
			end
			wiz '<font color=#3399CC>' << s << '</font><br><br>Vous percevez maintenant des echos de l\'écriture d\'une plume, sur ce qui pourrait-être un parchemin d\'une qualité inestimable.<br><br><font color=green>' <<  "Serez vous gauch#{ere = e ? 'ère' : 'er'} ou droiti#{ere} ?</font><br> - ::[1-gauch#{ere}]<br> - ::[2-droiti#{ere}]"
			@control = :desc_hand
		end
	end
	
	def desc_hand arg
		if "gauch#{ere = e ? 'ère' : 'er'}".contains arg then arg = 1
		elsif "droiti#{ere}".contains arg then arg = 2 end
		if (arg = arg.to_i).zero? or arg > 2
			wiz 'Ceci ne figure pas parmis les choix.', :red
		else
			s = case arg
			when 1
				@ambidexterity = 1
				"Gauch#{ere}, vous serez."
			when 2
				@ambidexterity = 100
				"Droiti#{ere}, vous serez."
			end
			wiz '<font color=#3399CC>' << s << '</font><br><br><font color=green>De quelle taille serez-vous ?</font><br> - ::[1-de petite taille]<br> - ::[2-de taille moyenne]<br> - ::[3-de grande taille]<br> - ::[4- d\'une taille immense !]'
			@control = :desc_height
		end
	end
	
	def desc_height arg
		if 'de petite taille'.contains arg then arg = 1
		elsif 'de taille moyenne'.contains arg then arg = 2
		elsif 'de grande taille'.contains arg then arg = 3
		elsif 'd\'une taille immense !'.contains arg then arg = 4 end
		if (arg = arg.to_i).zero? or arg > 4
			wiz 'Ceci ne figure pas parmis les choix.', :red
		else
			s = case @desc[:height] = arg.to_i
				when 1 then "Petit#{e}, vous serez."
				when 2 then 'De taille moyenne, vous serez.'
				when 3 then "Grand#{e}, vous serez."
				when 4 then 'Immense ! Pourquoi pas.'
			end
			wiz '<font color=#3399CC>' << s << '</font><br><br><font color=green>De quelle couleur seront vos cheveux ?</font><br> - ::[1-roux]<br> - ::[2-blonds]<br> - ::[3-blonds cendrés]<br> - ::[4-bruns]<br> - ::[5-noirs]'
			@control = :desc_haircolor
		end
	end
	
	def desc_haircolor arg
		if 'roux'.contains arg then arg = 1
		elsif 'blonds'.contains arg then arg = 2
		elsif 'blonds cendrés'.contains arg then arg = 3
		elsif 'bruns'.contains arg then arg = 4
		elsif 'noirs'.contains arg then arg = 5
		elsif 'blancs'.contains arg then arg = 6 end
		if (arg = arg.to_i).zero? or arg > 6
			wiz 'Ceci ne figure pas parmis les choix.', :red
		else
			s = case @desc[:haircolor] = arg
				when 1 then 'Vos cheveux seront roux.'
				when 2 then 'Vos cheveux seront blonds.'
				when 3 then 'Vos cheveux seront blonds cendrés.'
				when 4 then 'Vos cheveux seront bruns.'
				when 5 then 'Vos cheveux seront noirs.'
				when 6 then 'Vos cheveux seront blancs.'
			end
			wiz '<font color=#3399CC>' << s << '</font><br><br><font color=green>De quelle longueur seront vos cheveux ?</font><br> - ::[1-chauves]<br> - ::[2-très courts]<br> - ::[3-courts]<br> - ::[4-de longueur moyenne]<br> - ::[5-mi-longs]<br> - ::[6-longs]<br> - ::[7-très longs].'
			@control = :desc_hairlength
		end
	end
	
	def desc_hairlength arg
		if 'chauves'.contains arg then arg = 1
		elsif 'courts'.contains arg then arg = 3
		elsif 'très courts'.contains arg then arg = 2
		elsif 'longs'.contains arg then arg = 6
		elsif 'mi-longs'.contains arg then arg = 5
		elsif 'très longs'.contains arg then arg = 7
		elsif 'de longueur moyenne'.contains arg then arg = 4 end
		if (arg = arg.to_i).zero? or arg > 7
			wiz 'Ceci ne figure pas parmis les choix.', :red
		else
			s = case @desc[:hairlength] = arg
				when 1 then 'Chauve, vous serez.'
				when 2 then 'Vos cheveux seront très courts.'
				when 3 then 'Vos cheveux seront courts.'
				when 4 then 'Vos cheveux seront de taille moyenne.'
				when 5 then 'Vos cheveux seront moyennement longs.'
				when 6 then 'Vos cheveux seront longs.'
				when 7 then 'Vos cheveux seront très longs.'
			end
			wiz '<font color=#3399CC>' << s << '</font><br><br><font color=green>De quelle couleur seront vos yeux ?</font><br> - ::[1-bleus]<br> - ::[2-verts]<br> - ::[3-jaunes]<br> - ::[4-roses]<br> - ::[5-violets]<br> - ::[6-marrons]'
			@control = :desc_eyecolor
		end
	end
	
	def desc_eyecolor arg
		if 'bleus'.contains arg then arg = 1
		elsif 'verts'.contains arg then arg = 2
		elsif 'jaunes'.contains arg then arg = 3
		elsif 'roses'.contains arg then arg = 4
		elsif 'violets'.contains arg then arg = 5
		elsif 'marrons'.contains arg then arg = 6 end
		if (arg = arg.to_i).zero? or arg > 6
			wiz 'Ceci ne figure pas parmis les choix.', :red
		else
			@desc[:eyecolor] = arg
			@h = $heroe[id = $heroe.new_id] = Heroe.new(id)
			$actor[id] = @h
			
			name = @name
			password = @password
			desc = @desc
			ambidexterity = @ambidexterity
			@name = @password = @desc = @ambidexterity = nil
			
			@h.instance_eval do
				@name = name
				@password = password
				@authlevel = 0
				@desc = desc
				(@room = $room[1]) << self
				@xp = 0
				@level = 1
				@maxhp = 20
				@hp = 20
				@maxmp = 10
				@mp = 10
				@str = 5
				@con = 5
				@wis = 5
				@dex = 5
				@armor = 0
				@ambidexterity = ambidexterity
				@skin = 'default'
				@avatar = 'default'
				@target = nil
				@spell = {}
				@inv = Inventory.new
				@equip = {}
				@shortcut = Actor::Shortcut
				@hunger = 0
				after_load
				show_shortcuts
			end
			wiz '<font color=#3399CC>Les milliers de filaments de connexion de votre âme illuminée s\'emparent du corps d\'un Fœtus qui n\'a pas tardé à devenir un nouveau né. Vous incarnez maintenant ce personnage et allez apprendre à vous en servir.</font><br><br>Ci-dessous se trouve la description de l\'endroit ou vous vous trouvez.'
			@control = :normal
			@h.log_in self
		end
	end
	
	def normal arg; @h.cmd arg end
end
