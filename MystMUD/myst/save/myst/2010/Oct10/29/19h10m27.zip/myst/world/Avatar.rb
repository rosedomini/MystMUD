﻿
class Avatar
	attr_reader :id, :name, :source
	alias to_s name
	
	def initialize id; @id = id end
end
