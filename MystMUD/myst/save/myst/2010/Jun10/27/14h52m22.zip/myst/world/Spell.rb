﻿
class Spell
	attr_accessor :id, :name, :desc
	alias to_s name
	attr_accessor :school
	attr_accessor :min_cost, :max_cost
	attr_accessor :func, :arg_target
	
	def initialize id
		@id = id
	end
	
	def inspect
		"$spell[#{@id}]"
	end
	
	def container; $spell end
end