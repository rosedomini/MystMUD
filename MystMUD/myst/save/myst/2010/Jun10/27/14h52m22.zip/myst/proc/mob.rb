﻿
class << Mob.named 'Casimir'
	def hurt dmg, actor
		@hp -= dmg
		if @hp < 1
			@hp = 1
			cmd 'cast soin'
			$actor.peace_on self
			if actor.heroe?
				say 'Très bien, je vois que vous progressez.'
				actor.add_xp xp_gives(actor) if actor and actor.heroe?
			end
		elsif @hp > @maxhp then @hp = @maxhp end
	end
	
	def on_see actor
		if actor.heroe?
			say "Bon#{wdate('hours') > 17 ? ' soir,' : 'jour'} #{actor.name}. Je pourrais vous enseigner les bases du combat, mais pour cela il vous faut une arme. Allez donc voir le forgeron, en suivant le chemin vers la forge."
		end
	end
end