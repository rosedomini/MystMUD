﻿
class Actor
	def cast spell, power, target
		cost = spell.min_cost + (((spell.max_cost - spell.min_cost) / 100.0)*power).round
		if cost <= @mp
			@mp -= cost
			if spell.arg_target then send spell.func, power, target
			else send spell.func, power end
		else wiz 'Vous n\'avez pas assez de chi pour cela.' end
	end
	
	def drag body, exit_name
		witness_heroes.wiz "#{@name} s'en va vers #{Room::Exit[exit_name]} en traînant #{body}."
		
		move_to(new_room = @room.exits[exit_name])
		body.move_to new_room
		
		look_around
		
		witness_heroes.wiz "#{@name} arrive, traînant #{body}."
		
		redit if immortal? and @redit
	end
	
	def drop item, number
		@inv.give item, number, @room.inv
		wiz "Vous posez #{gift = item.x number}."
		room_heroes.each{|x| x.wiz "#{sb? x} pose #{gift}."}
	end
	
	def eat item
		@inv >> item
		witness_heroes.each{|x| x.wiz "#{@name} mange #{item}."}
		wiz "Vous mangez #{item}."
		self.hunger += item.stats[:rassasiment] if heroe? and item.stats[:rassasiment]
		item.call_power :eat
	end

	def examine something
		if something.is_a? Body
			if (items = (body = something).inv).empty?
				s = 'mais n\'y trouvez rien.'
			else
				s = 'et y trouvez :<br>'
				body.inv.each{|item, number| s << "<br> - #{item.x number}"}
			end
			wiz "Vous examinez #{body} #{s}"
			room_heroes{|x| x.wiz "#{sb? x} scrute #{body}."}
		else
			item = something
			room_heroes {|x| x.wiz "#{sb? x} examine #{item}."}
			weight = (item.weight / 3 + 0.5).round
			s = (weight == 1) ? 'une livre' : "#{weight} livres"
			s = weight.zero? ? 'ne pèse presque rien' : "pèse environ #{s}"
			wiz "Vous examinez #{item}.<br><br> #{item.desc}<br><br>Cet objet #{s}."
		end
	end
	
	def get item, number
		@room.inv.give item, number, @inv
		wiz "Vous ramassez #{gift = item.x number}."
		room_heroes.each{|x| x.wiz "#{sb? x} ramasse #{gift}."}
	end
	
	def get_from body, item, number
		body.inv.give item, number, @inv
		wiz "Vous ramassez #{gift = item.x number} depuis #{body}."
		room_heroes.each{|x| x.wiz "#{sb? x} ramasse #{gift} depuis #{body}."}
	end
	
	def give actor, item, number
		@inv.give item, number, actor.inv
		wiz "Vous donnez #{gift = item.x number} à #{actor}."
		actor.wiz "#{sb? actor} vous donne #{gift}."
		
		room_heroes.each do |x|
			x.wiz "#{sb? x} donne #{gift} à #{actor.sb? x, nil}." if x != actor end
	end
	
	def junk item, number
		@inv.junk item, number
		wiz "Vous détruisez #{gift = item.x number}."
		room_heroes.each{|x| x.wiz "#{sb? x} détruit #{gift}."}
	end

	def kill target
		wiz "Vous attaquez #{@target = target}."
		target.wiz "#{sb? target} vous attaque."
		room_heroes.each do |x|
			x.wiz "#{sb? x} attaque #{target.sb? x, nil}." if x != target end
	end
	
	def look_around
		s = '<font color=#3399CC>' << @room.name << '</font><br>'
		s << @room.desc << '<br><font color=green>Sorties :</font> '

		if @room.exits.empty? then s << 'aucunes'
		else
			@room.exits.each_key do |exit|
				s << " #{exit}&nbsp;" end end
		
		@room.inv.each do |item, number|
			s << "<br>- #{item.x number} est posé là." end
			
		seen_actors.each do |x|
			s << "<br><img src='ico/chars/#{x.skin}.png' height=24> #{x} est là." end
			
		seen_bodies.each{|x| s << "<br>¤ #{x} est là."}
		
		cleardiv
		wiz s
		redit if immortal? and @redit
	end
	
	def look_actor actor
		state = case hp_percent
			when 0..5		then "#{actor} est très proche de la mort."
			when 6..20		then "#{actor} saigne énormément."
			when 21..40	then "#{actor} est couvert d'entailles."
			when 41..60	then "#{actor} est légèrement blessé."
			when 61..90	then "#{actor} est affaibli."
			when 91..99	then "#{actor} est en pleine forme."
			when 100		then "#{actor} est en parfaite santé."
		end
		
		s = ''
		actor.equip.each{|on, item| s << "[#{Actor::Equip[on]}] #{item}<br>"}

		wiz "<br><table cellpadding=0 cellspacing=0 style=width:80% class=default><tr><td width=100%><p>#{state}</p><p><img src='ico/chars/#{actor.skin}.png'> équipement :</p><br>#{s}</td><td valign=top><img src='ico/avatar/#{actor.avatar}.png' height=100></td></tr></table>"
		
		witness_heroes.each do |heroe|
			if heroe == actor then actor.wiz "#{name} vous regarde."
			else heroe.wiz "#{name} regarde #{actor.sb? heroe, nil}." end
		end
	end
	
	def move exit_name
		witness_heroes.wiz "#{@name} s'en va vers #{Room::Exit[exit_name]}."
		move_to @room.exits[exit_name]
		witness_heroes.wiz "#{name} arrive."
		look_around
	end
end