
Power.new :gain_de_vie, -> power do
	$p.heal power
	$p.wiz "Vos blessure se referment. Vous vous sentez mieux ~ #{power} points."
end