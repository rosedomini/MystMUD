﻿
Lightblue = '#3399CC'

Server_policy = '<?xml version="1.0"?> 
<!DOCTYPE cross-domain-policy SYSTEM "http://www.adobe.com/xml/dtds/cross-domain-policy.dtd"> 
<cross-domain-policy>  
<allow-access-from domain="*" to-ports="*" />
</cross-domain-policy>' << "\0"
		
Server_MOTD = '::_box::<pre style="font-size:12pt;font-family:monospace;color:#3E6FB1">
 __  __           _
|  \\\\/  |_   _ ___| |_
| |\\\\/| | | | / __| __|
| |  | | |_| \\\\__ \\\\ |_
|_|  |_|\\\\__, |___/\\\\__|
        |___/</pre>Entrez votre nom: ::_'

$dump = false

$refresh = 0 # nombre de ticks depuis le dernier boot

Classhash	= {} # both set with Dat.define
Olc		= {}

$task = nil
