﻿









$a = []; 100.times{|i| $a << i}

def each_test
	$a.select{|x| x < 50}
end

each_test.each{|x| print x}




require 'benchmark'

n = 10000
Benchmark.bm do |x|
	x.report 'A' do n.times do |i|
		each_test.each{|x| x}
	end end
	x.report 'B' do n.times do |i|
		$a.each{|x| x if x < 50}
	end end
end