﻿
# Chargement du monde depuis la base de données

class Load; end
class << Load
	def world
		time = Time.now.to_f
		
		print "\n\t__Chargement du monde__\n"
		
		classes = [:Area, :Avatar, :Body, :Command, :Heroe, :Item, :Mob, :Room, :Shop, :Skin, :Spell, :System, :World]
		
		print 'Prechargement, '
		
		classes.each do |class_|
			$data[class_].pre_load end
		
		classes.each do |class_|
			$data[class_].load end
		
		# races
		self.icons
		self.system
		self.set_cmd_globals
		self.tasks
		
		print "\n\t__Modifications apres-chargement__\n "
		
		classes.each do |class_|
			$data[class_].after_load end
			
		puts "\n* Termine en #{ ( (Time.now.to_f - time) * 1000 ).to_i }ms\n\n"
	end
	
	def icons
		print 'Icon, '
		q = $db.query 'SELECT * FROM icon WHERE 1'
		q.each_hash do |d|
			$icon << d['source'] end
	end
	
	def mob_repop
		print 'Action: repop, '
		$mob.each_value do |mob|
			mob.repop end
	end
	
	def set_cmd_globals
		$keyboard_cmd, $admin_keyboard_cmd = ';', ';'
		$command.each do |name, command|
			if command.keyboard
				(command.admin ? $admin_keyboard_cmd : $keyboard_cmd) << "#{name};"
			end
		end
	end
	
	def system
		print 'System, '
		$hack = $sys['hack'].value
		$pray_history = $sys['pray'].value
		$sys['time_difference'].value = Time.now.to_i - $sys['world_time'].value
	end
	
	# def races
		# print '\tLoading Races\n'
		# require 'world/races'
	# end
	
	def tasks
		print 'Préparation des actions futures...'
		$tasks += [
			Task.new(Save, :world),
			Task.new(Fight, :round, 1.5),
			Task.new(Task, :update_cache_server, 17),
			Task.new(Task, :update_cache_world, 1200),
			Task.new(Task, :gc, 3),
			Task.new(Task, :world_refresh, 0, Time.now.to_i + 50),
			Task.new(Task, :item_repop, 600)
		]
	end
end
