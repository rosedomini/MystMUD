﻿
class Actor
	def each_second
		@hp_arrows = @mp_arrows = 0
		
		@aff.each_key do |aff|
			@aff[aff] -= 1
			if @aff[aff].zero? then @aff.delete aff
			else
				if aff.effect[:hp_arrows]
					
			end
			
		end
		unless @hp_arrows.zero?
			heal
		end
	end
end

class << Task
	def each_second
		$actor.each &:each_second
	end
end