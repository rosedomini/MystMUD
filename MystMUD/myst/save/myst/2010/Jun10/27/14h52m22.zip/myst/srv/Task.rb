﻿
class Task
	attr_accessor :id, :timestamp, :clss, :func, :args, :repeat

	def initialize clss, func, repeat = 0, timestamp = 0, *args
		@clss = clss
		@func = func
		@repeat = repeat
		@timestamp = timestamp < 0 ? Time.now.to_f - timestamp : timestamp
		@args = args
	end
	
	def execute
		$task = self
		@clss.send @func, *@args
		unless @repeat.zero?
			@timestamp = Time.now.to_f + @repeat end
	end
	
	def inspect
		"Task.new(#{([@clss, @func, @repeat, @timestamp]+@args).collect{|x| x.inspect}*', '})"
	end
end

class << Task
	def execute time
		$tasks.each_with_index do |x, i|
			if x.timestamp < time
				x.execute 
				$tasks[i] = nil if x.repeat.zero?
			end
		end
		$tasks.delete nil
		$task = nil
		send_all
	end
	
	def item_repop
		puts 'Item repop...'
		$room.each_value{|room| room.item_repop}
	end
	
	def gc
		GC.enable
		GC.start
		GC.disable
	end
	
	def update_cache_server
		set_cache 'server', "#{Time.now.to_f},#{online_players}"
	end
	
	def update_cache_world
		set_cache 'world', "#{$room.size},#{$area.size},#{$item.size},#{$mob.size},#{$heroe.size},#{$shop.size},#{$spell.size},#{$skin.size},#{$avatar.size}"
	end
	
	def world_refresh
		puts 'Refreshing...'
		$refresh += 1
		$task.repeat = 55 + rand(10)
		worldTime = wtime()
		
		$actor.each_value do |actor|
			actor.heal 20, true
			actor.energize 20, true end
		
		if ($refresh%5).zero?
			$actor.each_value do |actor|
				actor.hunger -= 60 if actor.heroe? end end
		
		$body.each_value do |body|
			body.over if worldTime > body.expire end
		
		$mob.each_value do |mob|
			mob.repop unless $actor[mob.id] end
	end
end
