﻿
class Room
	attr_accessor :id, :name, :desc
	alias to_s name
	attr_accessor :x, :y, :z, :area
	attr_accessor :inv, :items # items est la liste d'objets qui sont par défaut dans cette salle
	attr_accessor :exits
	
	# à mettre à jour à chaque déplacement, arrivée ou départ d'un Joueur ou d'une Créature
	attr_accessor :actors, :bodies
	
	include Receive # permet de recevoir des objets
	
	def initialize id
		@id = id
	end
	
	# permet de mettre à jour les listes actors ou bodies
	def << object
		if object.is_a? Actor then @actors << object
		elsif object.is_a? Body then @bodies << object
		else
			$! = "Room#<< only accepts Actors or Bodies."
			Error.display
		end
		object
	end
	
	# permet de mettre à jour les listes actors ou bodies
	def >> object
		if object.is_a? Actor
			@actors.delete_one object
		elsif object.is_a? Body
			@bodies.delete_one object
		else
			$! = "Room#>> only accepts Actors or Bodies."
			Error.display
		end
		object
	end
	
	# crée une nouvelle salle à l'emplacement voulu
	def self.create_to x, y, z
		room = $data[:Room].create
		room.x, room.y, room.z = x, y, z
		room.actors, room.bodies = [], []
		room.area = Room.near(x, y, z).area
		room
	end

	def self.near x, y, z
		min_dist = 999
		choise = nil
		$room.each_value do |room|
			if min_dist > dist = (room.x-x)**2+(room.y-y)**2+(room.z-z)**2
				min_dist = dist
				choise = room
			end
		end
		choise
	end
	
	def after_load
		@actors = []
		@bodies = []
		$body.each_value{|x| @bodies << x if x.room == self}
	end
	
	def heroes
		@actors.select{|actor| actor.heroe?}
	end
	
	def inspect
		"$room[#{@id}]"
	end
	
	# réapparition des objects par défaut de la salle s'ils ont disparus
	def item_repop
		@items.each do |item, number|
			if num = @inv[item]
				@inv[item] = number if num < number
			else
				@inv[item] = number end
		end
	end
end
