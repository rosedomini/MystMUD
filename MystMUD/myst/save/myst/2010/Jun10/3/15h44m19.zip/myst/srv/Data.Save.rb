﻿
class Data::Save
	def self.area value
		value.id.to_s
	end
	
	def self.array value
		value.inspect
	end
	
	def self.bool value
		value.to_str
	end
	
	def self.equipement value
		equip = value.clone
		
		equip.each do |wear, item|
			equip[wear] = item.id
		end
		
		return equip.inspect
	end
	
	def self.hash value
		value.inspect
	end
	
	def self.help value
		value.gsub(/<br>/, "\n")
	end
	
	def self.inventory value
		inv = {}
		value.each do |item, number|
			inv[item.id] = number unless number.zero?
		end
		return inv.inspect
	end
	
	def self.int value
		value.to_s
	end
	
	def self.spell_list value
		list = {}
		value.each do |spell, pow|
			list[spell.id] = pow
		end
		return list.inspect
	end
	
	def self.string value
		value
	end
	
	def self.inspect value
		value.inspect
	end
	
	def self.exits exits
		value = exits.clone
		value.each do |exit, room|
			value[exit] = room.id
		end
		return value.inspect
	end
	
	def self.nil value
		'nil'
	end
	
	def self.room value
		value.id.to_s
	end
	
	def self.zero value
		'0'
	end
	
	def self.sym_to_s value
		value.to_s
	end
end