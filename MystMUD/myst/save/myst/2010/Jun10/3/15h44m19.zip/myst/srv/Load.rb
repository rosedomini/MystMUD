﻿
# Chargement du monde depuis la base de données

class Load
	def Load.world
		time = Time.now.to_f
		
		print "\n\t__Chargement du monde__\n"
		
		classes = [:Area, :Avatar, :Body, :Command, :Heroe, :Item, :Mob, :Room, :Shop, :Skin, :Spell, :System, :World]
		
		classes.each do |class_|
			$data[class_].load
		end
		
		# Load.races
		Load.icons
		Load.system
		Load.set_cmd_globals
		Load.tasks
		
		print "\n\t__Modifications apres-chargement__\n "
		
		classes.each do |class_|
			$data[class_].change
		end
		
		Load.mob_repop
			
		puts "\n* Termine en #{ ( (Time.now.to_f - time) * 1000 ).to_i }ms\n\n"
	end
	
	def Load.icons
		print 'Icon, '
		q = $db.query 'SELECT * FROM icon WHERE 1'
		q.each_hash do |d|
			$icon << d['source']
		end
	end
	
	def Load.mob_repop
		print 'Action: repop, '
		$mob.each_value do |mob|
			mob.repop
		end
	end
	
	def Load.set_cmd_globals
		$keyboard_cmd, $admin_keyboard_cmd = ';', ';'
		$command.each do |name, command|
			if command.keyboard
				(command.admin ? $admin_keyboard_cmd : $keyboard_cmd) << "#{name};"
			end
		end
	end
	
	def Load.system
		print 'System, '
		$hack = $sys['hack'].value
		$pray = $sys['pray'].value
		$sys['time_difference'].value = Time.now.to_i - $sys['world_time'].value
	end
	
	# def Load.races
		# puts "\tLoading Races\n"
		# require 'world/races'
	# end
	
	def Load.tasks
		print 'Préparation des actions futures...'
		$tasks += [
			Task.new(0, Save, 'world'),
			Task.new(0, Fight, 'round'),
			Task.new(0, Task, 'update_cache_server'),
			Task.new(0, Task, 'update_cache_world'),
			Task.new(0, Task, 'gc'),
			Task.new(Time.now.to_i + 50, Task, 'world_refresh'),
			Task.new(0, Task, 'item_repop')
		]
	end
end
