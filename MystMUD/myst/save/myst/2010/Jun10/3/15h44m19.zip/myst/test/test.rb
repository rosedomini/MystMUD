


t = Time.now
1000.times do |i|

end
puts Time.now - t