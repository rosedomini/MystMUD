﻿
class Task
	attr_accessor :id, :timestamp, :clss, :func, :args, :del

	def initialize timestamp, clss, func, args = [], del = false
		@id = $tasks.size
		@timestamp = timestamp
		@clss = clss
		@func = func
		@args = args
		@del = del
	end
	
	def self.execute time
		$tasks.each{|x| x.execute if x.timestamp < time}
		$task = nil
	end
	
	def execute
		$task = self
		@clss.send @func, *@args
		$tasks.delete_one self if @del
	end
	
	def self.item_repop
		puts 'Item repop...'
		$room.each_value{|room| room.item_repop}
		$task.timestamp = Time.now.to_f + 600
	end
	
	def self.gc
		GC.enable
		GC.start
		GC.disable
		$task.timestamp = Time.now.to_f + 3
	end
	
	def self.update_cache_server
		$task.timestamp = Time.now.to_f + 17
		set_cache 'server', "#{Time.now.to_f},#{online_players}"
	end
	
	def self.update_cache_world
		$task.timestamp = Time.now.to_f + 1200
		set_cache 'world', "#{$room.size},#{$area.size},#{$item.size},#{$mob.size},#{$heroe.size},#{$shop.size},#{$spell.size},#{$skin.size},#{$avatar.size}"
	end
	
	def self.world_refresh
		puts 'Refreshing...'
		$refresh += 1
		$task.timestamp = Time.now.to_f + 55 + rand(10)
		worldTime = wtime()
		
		$actor.each_value do |actor|
			actor.heal 20, true
			actor.energize 20, true
		end
		
		if ($refresh%5).zero?
			$actor.each_value do |actor|
				actor.hunger -= 60 if actor.heroe?
			end
		end
		
		$body.each_value do |body|
			body.over if worldTime > body.expire
		end
		
		$mob.each_value do |mob|
			mob.repop unless $actor[mob.id]
		end
		
		send_all
	end
end
