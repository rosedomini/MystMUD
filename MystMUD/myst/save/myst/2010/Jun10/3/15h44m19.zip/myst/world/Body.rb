﻿
class Body
	attr_accessor :id, :aid, :actor, :name
	alias to_s name
	attr_accessor :room
	attr_accessor :expire
	attr_accessor :inv
	
	def create aid, expire, room
		@aid = aid
		
		if @actor = $actor[aid] then n = @actor.name
		else n = (@actor = $mob[aid]).name end
		
		@name = (n[0,2] == 'un') ? "#{n} mort#{(n[2] == 'e') ? 'e' : ''}" : "le corps d'#{n}"
		@expire = wtime + expire
		@inv = {}
		@room = room
		@room << self
		self
	end
	
	def initialize id
		@id = id
	end
	
	def inspect
		"$body[#{@id}]"
	end
	
	def after_load
		if @aid > 999999 then @actor = $mob[@aid]
		else @actor = $heroe[@aid] end
	end
	
	def move_to new_room
		@room >> self
		(@room = new_room) << self
	end
	
	def over
		@room.inv |= @inv
		@room.heroes.wiz "#{@name} se décompose."
		@room >> self
		$body.delete @id
	end
end
