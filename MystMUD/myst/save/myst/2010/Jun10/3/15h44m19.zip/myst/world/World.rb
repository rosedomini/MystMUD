﻿
class World
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :areas
	attr_reader :rooms
	
	def initialize id
		@id = id
	end
	
	def [] x, y, z
		@rooms[x][y][z]
	end
	
	def after_load
		@rooms = {}
	
		$room.each_value do |room|
			if rx = @rooms[room.x]
				if ry = rx[room.y] then ry[room.z] = room
				else
					rx[room.y] = {room.z=>room}
				end
			else
				@rooms[room.x] = {room.y=>{room.z=>room}}
			end
		end
	end
	
	def create_room x, y, z
		room = Room.create_to x, y, z		
		exits = room.exits
		
		if r = @rooms[x+1][y][z] then (exits[:est] = r).exits[:ouest] = room end
		if r = @rooms[x-1][y][z] then (exits[:ouest] = r).exits[:est] = room end
		if r = @rooms[x][y+1][z] then (exits[:nord] = r).exits[:sud] = room end
		if r = @rooms[x][y-1][z] then (exits[:sud] = r).exits[:nord] = room end
		if r = @rooms[x][y][z+1] then (exits[:haut] = r).exits[:bas] = room end
		if r = @rooms[x][y][z-1] then (exits[:bas] = r).exits[:haut] = room end
		
		if rx = @rooms[x]
			if ry = rx[y] then ry[z] = room
			else rx[y] = {z=>room}
			end
		else @rooms[x] = {y=>{z=>room}}
		end
		
		room
	end
end
