﻿# Vérification des arguments pour les commandes admin

class Actor
	def check_clone
		if $x =~ /^(\w+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				cmd_clone $1, $2.to_i
			else
				Error.olc_class end
		elsif $x =~ /^(\w+) (\w+)$/
			if $olc[$1] and $classhash[$1][$2]
				cmd_clone $1, $2
			else
				Error.olc_class end
		else cmd_help 'clone' end
	end
	
	def check_delete
		if $x =~ /^(\w+) (\d+)$/
			if $1 == 'room'
				if room = $room[$2.to_i]
					if room.id != 1
						close = @room.exits.first[1]
						move_to(close ? close : $room[1])
						room.destroy
						look_around
					else wiz 'Vous ne pouvez pas détruire <b>cette</b> salle.' end
				else wiz 'Cette salle n\'existe pas.' end
			else cmd_help 'delete' end
		else cmd_help 'delete' end
	end
	
	def check_dump
		begin
			if $x then cmd_dump $x else cmd_dump end
		rescue
			wiz "Erreur : #{$!}" end
	end

	def check_edit
		if $x =~ /^(\w+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				cmd_edit $1, $classhash[$1][$2.to_i]
			else 
				Error.olc_class end
		elsif $x =~ /^(\w+) (\w+)$/
			if $olc[$1] and $classhash[$1][$2]
				cmd_edit $1, $classhash[$1][$2]
			else
				Error.olc_class end
		else
			cmd_help 'clone' end
	end

	def check_force
		if $x =~ /^([\w ]+)(( +to +)|(, *))(.+)$/
			if actor = room_actors.named($1)
				oldmaster = actor.master
				actor.master = self
				actor.cmd $5
				actor.master = oldmaster
			else wiz 'Cette personne n\'est pas là' end
		else cmd_help 'force' end
	end

	def check_giveXp
		if $x =~ /^(\w+) (\d+)$/
			if (amount = $2.to_i) > 0
				if heroe = $actor.select{|k, x| x.heroe?}.value_named($1)
					cmd_giveXp heroe, amount
				else wiz 'Cette personne n\'existe pas.' end
			else wiz 'l\'expérience acquise ne peut pas être retirée !' end
		else cmd_help 'giveXp' end
	end

	def check_goto
		if $x and room = $room[$x.to_i] then goto room else goto end
	end

	def check_help
		cmd_help $command[$x]
	end
	
	def check_include
		cmd_include $x
	end

	def check_lvUp
		if $x
			if heroe = $actor.select{|k, x| x.heroe?}.value_named($x)
				cmd_lvUp heroe
			else wiz 'Cette personne n\'existe pas.' end
		else cmd_help 'lvUp' end
	end
   
	def check_olc
		if $x.nil? then cmd_olc
		elsif $olc[$x] then cmd_olc $x
		else Error.olc_class end
	end

	def check_olcShow
		if $x =~ /^(\w+) (\d+)$/
			if $olc[$1] and $classhash[$1][$2.to_i]
				cmd_olcShow $1, $classhash[$1][$2.to_i]
			else Error.olc_class end
		elsif $x =~ /^(\w+) (\w+)$/
			if $olc[$1] and $classhash[$1][$2]
				cmd_olcShow $1, $classhash[$1][$2]
			else Error.olc_class end
		else cmd_help 'olcShow' end
	end
	
	def check_rcreate
		if $x =~ /^[bonseh]$/ then rcreate $x.to_sym
		else
			wiz 'Les directions possibles sont n-s, o-e, h-b. Les noms des sorties peuvent être changés après.'
		end
	end

	def check_redit
		redit($x == 'close')
	end

	def check_ruby
		if $x then ruby CGI.unescapeHTML($x) else ruby end
	end

	def check_set
		if $x =~ /^(\w+) (\w+) (\w+) (.+)$/
			if a = $classhash[cls = $1] and $olc[cls].index(var = $3)
				if o = a[$2.to_i] or o = a[$2]
					cmd_set cls, o, var, CGI.unescapeHTML($4)
				end
			else Error.olc_class end
		else cmd_help 'set' end
	end

	def check_summonItem
		if $x =~ /^(\d+) (\d+)$/
			item, number = $item[$1.to_i], $2.to_i
		elsif $x =~ /^(\d+)? *(.+)$/
			item, number = $item.value_named($2), $1.to_i
		else
			cmd_help 'summonItem'
			return
		end
		if item and number > 0 then cmd_summonItem item, number
		else wiz 'Cet objet n\'existe pas.' end
	end
end