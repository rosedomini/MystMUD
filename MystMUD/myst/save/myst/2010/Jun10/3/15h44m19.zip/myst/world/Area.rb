﻿
class Area
	attr_accessor :id, :name
	alias to_s name
	attr_accessor :room
	
	def initialize id
		@id = id
		@room = []
	end
end