﻿
# class ActorHash < Hash
	# def named s
		# s = s.downcase
		# if @names[@names.index(s)+s.length,50] =~ /\w*=(\d+)/
			# return self[$1.to_i]
		# end
		# nil
	# end
	
	# def initialize
		# super
		# @names = ';'
	# end
	
	# def []= key, value
		# @names << "#{value.name.downcase}=#{key};"
		# store key, value
	# end
# end

class Inventory < Hash
	def initialize hash = {}
		hash.each do |key, value| store key, value end
	end
	
	def << items
		if items.is_a? Hash
			items.each do |key, value|
				if self[key] then self[key] += value
				else
					store key, value end
			end
		elsif items.is_a? Fixnum
			self[items] = if self[items] then self[items] + 1 else 1 end
		else
			raise ArgumentError end
		self
	end
	
	def add item, number
		self[item] = if self[item] then self[item] + number else number end
	end
	
	def >> item
		if self[item]
			if self[item] == 1 then delete item else self[item] -= 1 end
		end
	end
	
	def give item, number, inv
		if number >= self[item]
			inv.add item, self[item]
			delete item
		else
			self[item] -= number
			inv.add item, number
		end
	end
	
	def junk item, number
		if number >= self[item] then delete item
		else self[item] -= number end
	end
end

class Actor
	def room_actors
		@room.actors.select{ |actor| actor != self }
	end
	
	def room_heroes
		@room.actors.select{ |actor| actor.heroe? and actor != self }
	end
	
	def seen_bodies
		# @room.bodies.select{ |body| sees body }
		@room.bodies
	end
	
	def seen_heroes
		@room.actors.select{ |actor| actor.heroe? and sees actor and actor != self }
	end
	
	def seen_actors
		@room.actors.select{ |actor| sees actor and actor != self }
	end
	
	def witness_heroes
		@room.actors.select{ |actor| actor.heroe? and actor.sees self and actor != self }
	end
	
	def witnesses
		@room.actors.select{ |actor| actor.sees self and actor != self }
	end
	
	def area_heroes
		area = @room.area
		$actor.collect{ |id, actor| actor if actor.heroe? and actor.room.area == area and actor != self }
	end
	
	def area_actors
		area = @room.area
		$actor.collect{ |id, actor| actor if actor.room.area == area and actor != self }
	end
end
