﻿
class Heroe < Actor
	attr_reader :desc, :msg, :shortcut, :password, :authlevel, :xp, :hunger
	
	def initialize id
		super id
		@msg = ''
		@hunger = 0
	end
	
	def after_load
		super
		@msg.clear
	end
	
	def add_xp number
		wiz "<br>Vous acquérissez de l'expérience ~ <font color=#3366CC>#{number}</font> points."
		@xp += number
		while @xp >= xp_needed
			@xp -= xp_needed
			level_up
		end
	end

	def echo sth, color = nil
		@msg << "#{color ? "<font color=#{color}>#{sth}</font>" : sth}::_"
	end
	
	def heroe?; true end
	
	def hunger= value
		if @hunger < value
			@hunger = if value < 0 then 0
			elsif value > 1200 then wiz 'Vous êtes complètement rassasié.'; 1200
			else value end
		elsif (@hunger = value) < 0
			wiz "Vous avez #{'très '*(-value/1800).truncate}faim."
	end end
	
	def inspect; "$heroe[#{@id}]" end
	
	def killed actor = nil
		s = case rand 3
			when 0 then 'tombe raide mort'
			when 1 then 'expire son dernier souffle'
			else				 's\'écroule dans une marre de sang'
		end
		
		wiz 'Vous vous écroulez, vide d\'énergie...<br>', :red
		each_close_heroe{ |heroe| heroe.wiz "#{@name} #{@s}." }
		actor.add_xp xp_gives(actor) if actor and actor.heroe?
		body = $body << Body.new($body.new_id).create(@id, 720, @room)
		inventory = body.inv = @inv.clone
		
		@equip.each_value do |item|
			inventory << item end
		
		@inv.clear
		@equip.clear
		@status = ''
		@hp = @maxhp
		@room >> self
		(@room = $room[1]) << self
		@target = nil

		$actor.each_value{|x| x.target = nil if x.target == self}
		
		look_around
	end
	
	def level_up
		@level += 1
		wiz 'Vos capacités progressent d\'un niveau !', :blue
		case rand 4
			when 0 then @dex += 3
			when 1 then @wis += 3
			when 2 then @con += 3
			when 3 then @str += 3
		end
		@maxhp += @con
		@maxmp += @wis
		@hp = @maxhp
		@mp = @maxmp
	end
	
	def mob?; false end
	def online?; $actor.key self end
	
	def log_in sock
		@sock = sock
		@target = nil
		look_around
		show_shortcuts
	end
	
	def log_out write_MOTD = false
		@target = nil
		Actor.peace_on self
		@target = nil
		@msg.clear
		@room >> self
		$actor.delete @id
		@sock.write "reset_bars::::_main::#{Server_MOTD}" if write_MOTD
		@sock.control = :start
		@sock.h = nil
		@sock = nil
	end
	
	def send_msg
		return if@msg.length.zero?
		@msg << "adv::#{@target}::#{(100*@target.hp/@target.maxhp).to_i}::_" if @target
		@msg << "health::#{@hp}::#{@maxhp}::#{@mp}::#{@maxmp}::#{hp_arrows_useful}::#{mp_arrows_useful}::_"
		
		if @msg.length > 2048 then @msg.scan(/.{1,2048}/).each{|s| @sock.write s}
		else @sock.write @msg end
			
		p @msg if $dump
		@msg.clear
	end
	
	def show_shortcuts
		@msg << 'shortcuts::'
		commands = @shortcut[1]
		@shortcut[0].each_with_index do |icon, i|
			@msg << ";#{icon},#{commands[i]}" end
		@msg << '::_'
	end
	
	def wiz sth, color=nil
		@msg << "box::#{color ? "<font color=#{color}>#{sth}</font>" : sth}::_"
	end
	
	def xp_needed; 2*(@level**2)*(@level+50)*(1+0/3) end # replace 0 with @ren
end
