﻿
# Définition de la classe command

class Command
	attr_reader :id, :name, :french_name, :type, :mob, :ko, :authlevel, :keyboard, :link, :syntax, :help
	alias to_s name
	
	def inspect; "$command['#{@name}']" end
	def initialize id; @id = id end
	def admin; authlevel > 0 end
end