﻿

require 'benchmark'

n = 1000
Benchmark.bm do |x|
	x.report 'A' do n.times do |i|
		
	end end
	x.report 'B' do n.times do |i|
		
	end end
	x.report 'B' do n.times do |i|
		
	end end
end