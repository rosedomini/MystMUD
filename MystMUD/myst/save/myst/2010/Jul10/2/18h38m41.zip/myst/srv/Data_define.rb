﻿
Clonable = [:Item, :Mob]

class Dat; end
class << Dat
	def define
		self.Area
		self.Avatar
		self.Body
		self.Command
		self.Heroe
		self.Item
		self.Mob
		self.Room
		self.Shop
		self.Skin
		self.Spell
		self.System
		self.World
		
		OLC :Area, :Body, :Heroe, :Item, :Mob, :Room, :Shop, :World
		
	end
	
	def OLC *classnames
		classnames.each do |classname|
			
			a = Olc[classname.to_s] = []
			
			(data = $data[classname]).data.each do |var|
				a << var[:name].to_s
			end
			
			Classhash[classname.to_s] = data.hash
		end
	end
	
# add values in SQL table order
	
	def Area
		data = $data[:Area] = new(:Area, $area, Area)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		}]
	end
	
	def Avatar
	
		data = $data[:Avatar] = new(:Avatar, $avatar, Avatar)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :source,
			:load	=> :string
		}]
	end
	
	def Body
		data = $data[:Body] = new(:Body, $body, Body)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :aid,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :expire,
			:load	=> :int
		},{
			:name	=> :inv,
			:load	=> :inventory
		},{
			:name	=> :room,
			:load	=> :room
		}]
	end
	
	def Command
		data = $data[:Command] = new(:Command, $command, Command)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string,
		},{
			:name	=> :french_name,
			:load	=> :string,
		},{
			:name	=> :type,
			:load	=> :sym,
			:save	=> :sym_to_s
		},{
			:name	=> :mob,
			:load	=> :bool
		},{
			:name	=> :ko,
			:load	=> :bool
		},{
			:name	=> :authlevel,
			:load	=> :int
		},{
			:name	=> :keyboard,
			:load	=> :bool
		},{
			:name	=> :link,
			:load	=> :bool
		},{
			:name	=> :syntax,
			:load	=> :string
		},{
			:name	=> :help,
			:load	=> :help
		}]
	end
	
	def Heroe
		data = $data[:Heroe] = new(:Heroe, $heroe, Heroe)
		
		data.make [{
			:name	=> :id,
			:load	=> :int,
			:default	=> 0
		},{
			:name	=> :name,
			:load	=> :string,
			:default	=> 1
		},{
			:name	=> :password,
			:load	=> :string,
			:default	=> 2
		},{
			:name	=> :authlevel,
			:load	=> :int,
			:default	=> '0'
		},{
			:name	=> :desc,
			:load	=> :hash,
			:default	=> '{}'
		},{
			:name	=> :room,
			:load	=> :room,
			:default	=> '1'
		},{
			:name	=> :xp,
			:load	=> :int,
			:default	=> '0'
		},{
			:name	=> :level,
			:load	=> :int,
			:default	=> '1'
		},{
			:name	=> :hp,
			:load	=> :int,
			:default	=> '20'
		},{
			:name	=> :maxhp,
			:load	=> :int,
			:default	=> '20'
		},{
			:name	=> :mp,
			:load	=> :int,
			:default	=> '20'
		},{
			:name	=> :maxmp,
			:load	=> :int,
			:default	=> '20'
		},{
			:name	=> :str,
			:load	=> :int,
			:default	=> '5'
		},{
			:name	=> :con,
			:load	=> :int,
			:default	=> '5'
		},{
			:name	=> :wis,
			:load	=> :int,
			:default	=> '5'
		},{
			:name	=> :dex,
			:load	=> :int,
			:default	=> '5'
		},{
			:name	=> :skin,
			:load	=> :string,
			:default	=> 'default'
		},{
			:name	=> :avatar,
			:load	=> :string,
			:default	=> 'default'
		},{
			:name	=> :spell,
			:load	=> :spell_list,
			:default	=> '{}'
		},{
			:name	=> :inv,
			:load	=> :inventory,
			:default	=> '{}'
		},{
			:name	=> :equip,
			:load	=> :equipement,
			:default	=> '{}'
		},{
			:name	=> :shortcut,
			:load	=> :shortcut,
			:save	=> :inspect,
			:default	=> :default_shortcuts
		},{
			:name	=> :hunger,
			:load	=> :int,
			:default	=> '0'
		}]
	end
	
	def Item
		data = $data[:Item] = new(:Item, $item, Item)
		
		data.make [{
			:name	=> :id,
			:load	=> :int,
			:default	=> 0
		},{
			:name	=> :name,
			:load	=> :string,
			:default	=> 1
		},{
			:name	=> :type,
			:load	=> :sym,
			:save	=> :sym_to_s,
			:default	=> 'divers'
		},{
			:name	=> :weight,
			:load	=> :int,
			:default	=> '1'
		},{
			:name	=> :wearon,
			:load	=> :array,
			:default	=> '[]'
		},{
			:name	=> :desc,
			:load	=> :string,
			:default	=> ''
		},{
			:name	=> :stats,
			:load	=> :hash,
			:default	=> '{}'
		},{
			:name	=> :power,
			:load	=> :hash,
			:default	=> '{}'
		},{
			:name	=> :required,
			:load	=> :hash,
			:default	=> '{}'
		},{
			:name	=> :value,
			:load	=> :int,
			:default	=> '1'
		}]
	end
	
	def Mob
		data = $data[:Mob] = new(:Mob, $mob, Mob)
		
		data.make [{
			:name	=> :id,
			:load	=> :int,
			:default	=> 0
		},{
			:name	=> :name,
			:load	=> :string,
			:default	=> 'une créature mystérieuse'
		},{
			:name	=> :room,
			:load	=> :room,
			:default	=> '1'
		},{
			:name	=> :level,
			:load	=> :int,
			:default	=> '1'
		},{
			:name	=> :hp,
			:load	=> :int,
			:default	=> '10'
		},{
			:name	=> :maxhp,
			:load	=> :int,
			:default	=> '10'
		},{
			:name	=> :mp,
			:load	=> :int,
			:default	=> '10'
		},{
			:name	=> :maxmp,
			:load	=> :int,
			:default	=> '10'
		},{
			:name	=> :str,
			:load	=> :int,
			:default	=> '10'
		},{
			:name	=> :con,
			:load	=> :int,
			:default	=> '10'
		},{
			:name	=> :wis,
			:load	=> :int,
			:default	=> '10'
		},{
			:name	=> :dex,
			:load	=> :int,
			:default	=> '10'
		},{
			:name	=> :skin,
			:load	=> :string,
			:default	=> 'mob/default'
		},{
			:name	=> :avatar,
			:load	=> :string,
			:default	=> 'mob/default'
		},{
			:name	=> :spell,
			:load	=> :spell_list,
			:default	=> '{}'
		},{
			:name	=> :inv,
			:load	=> :inventory,
			:default	=> '{}'
		},{
			:name	=> :equip,
			:load	=> :equipement,
			:default	=> '{}'
		}]
	end
	
	def Room
		data = $data[:Room] = new(:Room, $room, Room)
		
		data.make [{
			:name	=> :id,
			:load	=> :int,
			:default	=> 0
		},{
			:name	=> :area,
			:load	=> :area,
			:save	=> :room,
			:default	=> '1'
		},{
			:name	=> :name,
			:load	=> :string,
			:default	=> 'Nouvelle salle'
		},{
			:name	=> :desc,
			:load	=> :string,
			:default	=> 'Cette salle est bien éclairée et sent bon la peinture fraîche.'
		},{
			:name	=> :x,
			:load	=> :int,
			:default	=> '0'
		},{
			:name	=> :y,
			:load	=> :int,
			:default	=> '0'
		},{
			:name	=> :z,
			:load	=> :int,
			:default	=> '-1'
		},{
			:name	=> :inv,
			:load	=> :inventory,
			:default	=> '{}'
		},{
			:name	=> :items,
			:load	=> :inventory,
			:default	=> '{}'
		},{
			:name	=> :exits,
			:load	=> :exits,
			:default	=> '{}'
		}]
	end
	
	def Shop
		data = $data[:Shop] = new(:Shop, $shop, Shop)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :keeper,
			:load	=> :int
		},{
			:name	=> :room,
			:load	=> :room
		},{
			:name	=> :inv,
			:load	=> :inventory
		}]
	end
	
	def Skin
		data = $data[:Skin] = new(:Skin, $skin, Skin)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :source,
			:load	=> :string
		}]
	end
	
	def Spell
		data = $data[:Spell] = new(:Spell, $spell, Spell)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :desc,
			:load	=> :string
		},{
			:name	=> :min_cost,
			:load	=> :int
		},{
			:name	=> :max_cost,
			:load	=> :int
		},{
			:name	=> :school,
			:load	=> :string
		},{
			:name	=> :func,
			:load	=> :sym,
			:save	=> :sym_to_s
		},{
			:name	=> :arg_target,
			:load	=> :bool
		}]
	end
	
	def System
		data = $data[:System] = new(:System, $sys, System)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :value,
			:load	=> :eval,
			:save	=> :inspect
		}]
	end
	
	def World
		data = $data[:World] = new(:World, $world, World)
		
		data.make [{
			:name	=> :id,
			:load	=> :int
		},{
			:name	=> :name,
			:load	=> :string
		},{
			:name	=> :areas,
			:load	=> :array,
			:save	=> :inspect
		}]
	end
end
