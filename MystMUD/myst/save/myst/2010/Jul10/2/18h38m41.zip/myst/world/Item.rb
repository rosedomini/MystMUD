﻿
class Item
	attr_reader :id, :name, :desc, :type
	attr_reader :weight, :wearon, :value
	attr_reader :stats, :power, :required
	alias to_s name
	
	def initialize id; @id = id end
	
	def call_power caller
		if caller = @power[caller] and rand(1000) < caller[2]
			$power[caller[0]][caller[1]]
		end
	end
	
	def clone; $data[:Item].copy_from @id end
	def inspect; "$item[#{@id}]" end
	
	def x number
		if number == 1 then @name
		else
			"#{@name} (x#{number})" end
	end
end