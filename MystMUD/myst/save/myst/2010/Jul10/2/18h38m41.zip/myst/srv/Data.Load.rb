﻿
class Data::Load; end
class << Data::Load
	def area value, olc = nil
		$area[value.to_i] end
	
	def array value, olc = nil
		if (a = eval value).is_a? Array then a else {} end end
	
	def bool value, olc = nil
		value.to_b end
	
	def equipement value, olc = nil
		if (value = eval value).is_a? Hash
			equip = {}
			value.each do |wear, item_id|
				if item = $item[item_id] then equip[wear] = item
				else equip.delete wear end
			end
			equip
		else {} end
	end
	
	def eval value, olc = nil
		Kernel.eval value end
	
	def exits value, olc = nil
		if (exits = eval value).is_a? Hash
			exits.each do |name, room_id|
				if room = $room[room_id] then exits[name] = room
				else exits.delete name end
			end
			exits
		else {} end
	end
	
	def int value, olc = nil
		value.to_i end
	
	def hash value, olc = nil
		if (h = eval value).is_a? Hash then h else {} end
	end
	
	def help value, olc = nil
		value.gsub(/\n/, '<br>') end
	
	def inventory value, olc = nil
		if (value = eval value).is_a? Hash
			inv = Inventory.new
			Inventory.new(value).each do |id, number|
				if item = $item[id] and number > 0 then inv[item] = number
				else inv.delete id end
			end
			inv
		else Inventory.new end
	end
	
	def room value, olc = nil
		$room[value.to_i] end
	
	def spell_list value, olc = nil
		if (value = eval value).is_a? Hash
			list = {}
			value.each do |id, pow|
				if spell = $spell[id] then list[spell] = pow
				else list.delete id end
			end
			list
		else {} end
	end
	
	def shortcut value, olc = nil
		s = eval value
		if s.is_a? Array and s[0].is_a? Array and s[1].is_a? Array and s.size==2 and s[0].size==10 and s[1].size==10
			s
		else Actor::Shortcut end
	end
	
	def string value, olc = nil
		value end
	
	def sym value, olc = nil
		value.to_sym end
end
