﻿
class Body
	attr_reader :id, :aid, :actor, :name, :room, :expire, :inv
	attr_writer :inv, :room
	alias to_s name
	
	def create aid, expire, room
		@aid = aid
		
		if @actor = $actor[aid] then n = @actor.name
		else n = (@actor = $mob[aid]).name end
		
		@name = (n[0,2] == 'un') ? "#{n} mort#{(n[2] == 'e') ? 'e' : ''}" : "le corps d#{n[0] =~ /[aeiouy]/i ? '\'' : 'e '}#{n}"
		@expire = wtime + expire
		@inv = {}
		@room = room
		@room << self
		self
	end
	
	def initialize id; @id = id end
	def inspect; "$body[#{@id}]" end
	
	def after_load
		if @aid > 999999 then @actor = $mob[@aid]
		else @actor = $heroe[@aid] end
	end
	
	def over
		@room.inv << @inv
		@room.heroes.wiz "#{@name} se décompose."
		@room >> self
		$body.delete @id
	end
end
