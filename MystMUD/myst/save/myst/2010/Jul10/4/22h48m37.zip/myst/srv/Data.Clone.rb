﻿
class Data::Clone; end
class << Data::Clone
	def array value; value.clone end
	def bool value; value end
	alias equipement array
	alias hash array
	alias help bool
	alias int bool
	alias inventory array
	def nil value; end
	alias room bool
	alias spell_list array
	alias sym bool
	def shortcut value; [value[0].clone, value[1].clone] end
	alias string bool
end