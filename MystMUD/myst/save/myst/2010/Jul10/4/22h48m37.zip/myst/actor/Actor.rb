﻿
class Actor
	attr_reader :id, :name, :room, :level
	attr_reader :hp, :maxhp, :mp, :maxmp
	attr_reader :str, :con, :wis, :dex
	attr_reader :spell, :inv, :equip, :aff
	attr_reader :master, :last_teller
	attr_reader :skin, :avatar, :master, :last_teller, :status, :target, :weapons, :shields
	attr_writer :target, :master
	alias to_s name
	
	Equip = {
		:cheville_gauche => 'Cheville gauche',
		:cheville_droite => 'Cheville droite',
		:bras_gauche => 'Bras gauche',
		:bras_droit => 'Bras droit',
		:dos => 'Dos',
		:torse => 'Torse',
		:oreille_gauche => 'Oreille gauche',
		:orielle_droite => 'Oreille droite',
		:yeux => 'Yeux',
		:doigt_gauche => 'Doigt gauche',
		:doigt_droit => 'Doigt droit',
		:pieds => 'Pieds',
		:front => 'Front',
		:gants => 'Gants',
		:tête => 'Tête',
		:jambes => 'Jambes',
		:cou => 'Cou',
		:taille => 'Taille',
		:main_gauche => 'Main gauche',
		:main_droite => 'Main droite',
		:poignet_gauche => 'Poignet gauche',
		:poignet_droit => 'Poignet droit'
	}
	
	Shortcut = [
		['Skill 7', 'Item 1',     'Weapon 1',   'Item 5',     'Joyaux 2', 'Boomerang 1', 'Lanterne 1', 'Masque 1', 'Item 9', 'Skill 6'],
		['score', 'inventory', 'equipement', 'affections', 'spells',      'skills',               'time',          'who',         'option',  'aide']
	]
	
	def after_load
		@status = :none
		@left_fist = Fist.new(self, :left)
		@right_fist = Fist.new(self, :right)
		@hp_arrows = @mp_arrows = 0
		update_weapons_and_shields
	end
	
	def initialize id
		@id = id
		@aff = {}
	end
	
	def unaffect aff
		@hp_arrows -= x if x = aff.effect[:hp_arrows]
		@mp_arrows -= x if x = aff.effect[:mp_arrows]
		@aff.delete aff
	end
	
	def affect affection, power, time
		if aff = @aff[affection]
			if (time = time /10).zero? then time += 1 end
			aff[1] = (aff[0]*aff[1]+time*power)/(aff[0]+time)
			aff[0] += time
		else
			@aff[affection] = [time, power]
			@hp_arrows += x if x = aff.effect[:hp_arrows]
			@mp_arrows += x if x = aff.effect[:mp_arrows]
		end
	end
	
	def can_hold? item; true end
	def can_reach? actor; actor.room == @room and sees actor end

	def cmd arg
		$p = self
			
		if arg =~ /^(!)?(\w+) *(.*\S+)? *$/
			$link = $1
			$cmd = $2
			$x = $3
		else return end
		
		if $cmd =~ /^[nsoebh]$/
			@room.exits.each_key do |exit_name|
				if $cmd == exit_name.to_s[0]
					move exit_name
					return
			end end
			wiz 'Vous ne pouvez pas aller par là.'
			return
		end
		
		unless $x or $link
			@room.exits.each_key do |exit_name|
				if $cmd == exit_name.to_s[0, $cmd.length]
					move exit_name
					return
		end end end
		
		cmd = nil
		
		if $link
			if cmd = $command[$cmd] and cmd.link then nil
			else
				Log.link_error
				wiz 'Lien brisé : l\'erreur vient d\'être enregistrée.', :red
				return
			end
		elsif $keyboard_cmd =~ /;(#{$cmd}\w*);/
			cmd = $command[$1]
		elsif immortal? and $admin_keyboard_cmd =~ /;(#{$cmd}\w*);/
			cmd = $command[$1]
		else
			wiz "Commande inconnue : #{$cmd}", :red
			return
		end
		
		if @status == :dead and !cmd.ko
			wiz "Vous n'êtes pas en état de faire celà... vous êtes mort#{e} !"
		elsif mob? and !cmd.mob
			say_to_master "Je ne peux pas faire ça, maître#{'sse' if @master and @master.female?}."
		elsif @authlevel < cmd.authlevel
			wiz 'Vos pouvoirs ne vous permettent pas de faire cela.'
		else return send "check_#{cmd}#{$link}".to_sym end
		nil
	end
	
	def e; 'e' if @desc and @desc[:sex] == 2 end
	
	def each_second
		@aff.each_key{|aff| unaffect aff if (@aff[aff] -= 1).zero?}
		unless (useful = hp_arrows_useful).zero? then heal useful, true end
		unless (useful = mp_arrows_useful).zero? then energize useful, true end
	end
	
	def energize points, percent = nil
		points = (@maxmp / 100.0 * points).round if percent
		@mp += points
		if @mp < 0 then @mp = 0
		elsif @mp > @maxmp then @mp = @maxmp
	end end
	
	def emote sth
		each_close_actor{|x| x.wiz "#{sb? x} #{sth}"}
	end
	
	def female?; @desc[:sex] == 2 end
	
	def heal points, percent = nil
		points = (@maxhp / 100.0 * points).round if percent
		@hp += points
		if @hp < 1
			@hp = 1
			killed
		elsif @hp > @maxhp then @hp = @maxhp
	end end
	
	def hp_arrows_useful
		useful = @target ? @hp_arrows : @hp_arrows + 4
		if useful > 10 then 10
		elsif useful < -10 then -10
		else useful
	end end
	
	def hp_percent; (@hp /@maxhp*100).round end
	
	def hurt dmg, actor
		@hp -= dmg
		if @hp < 1 then @hp = 1; killed actor
		elsif @hp > @maxhp then @hp = @maxhp end
	end
	
	def hwiz sth, color = nil
		wiz CGI.escapeHTML(sth.to_s), color
	end
	
	def immortal?; @authlevel > 0 end
	
	def mp_arrows_useful
		if @mp_arrows > 10 then 10
		elsif @mp_arrows < -10 then -10
		else @mp_arrows end
	end
	
	def mp= new_mp
		@mp = (new_mp > @maxmp) ? @maxmp : new_mp
	end
	
	def retrieve id, number = 1
		if @inv[id] and @inv[id] >= number
			@inv[id] -= number
			ret = @inv[id]
			if @inv[id].zero? then @inv.delete id end
			ret
	end end
	
	def say_to_master sth, color = nil
		@master.wiz "#{name} vous dit : #{sth}", color
	end
	
	def sb? actor, maj=true
		if actor.sees self then name else (maj ? 'Q' : 'q') << 'uelqu\'un'
	end end
	
	def sees a; true end
	
	def up_spell id, points = 1
		if spell = @spell[id] then spell += points
		else @spell[id] = points end
	end
	
	def update_weapons_and_shields
		left = (left = @equip[:main_gauche]) ? left : @left_fist
		right = (right = @equip[:main_droite]) ? right : @right_fist
		@weapons = {}
		@weapons[:left] = left if left.type == :arme
		@weapons[:right] = right if right.type == :arme and left.stats[:deux_mains].nil?
		@shields = []
		@shields << shield if shield = @equip[:main_gauche] and shield.type == :bouclier
		@shields << shield if shield = @equip[:main_droite] and shield.type == :bouclier
	end
	
	def xp_gives actor # à prendre en compte plus tard
		((115 - rand(31))*(@level**2)*(@level+50)*(1+0/3) / 1000).round # replace 0 with @ren
	end
	
	def wiz_help msg, color = nil
		wiz "<i>#{msg}</i>", color # if @help
	end
end