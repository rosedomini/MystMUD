﻿# Les équipes sont très dynamiques. Il s'agit d'alliances <b>temporaires</b>.
# <font color=#3399CC>team add &lt;nom&gt;:</font> ajoute un membre à votre équipe à condition qu'il vous suivre, qu'il ne soit pas déjà dans une équipe et que vous êtes meneur de votre équipe. Si vous n'avez pas d'équipe, elle sera crée par la même occasion.<br>
# <font color=#3399CC>team leave (&lt;nom&gt;):</font> quitte votre équipe. Si vous êtes le meneur, la personne désignée ou la deuxième à avoir rejoint l'équipe prendra la relève.<br>
# <font color=#3399CC>team join &lt;nom&gt;:</font> ceci enverra un message à la personne visée indiquant que vous voulez rejoindre son équipe. Vous suivrez cette personne jusqu'à-ce que vous tapiez <font color=orange>follow stop</font>.
# <font color=#3399CC>team speak &lt;message&gt;:</font> envoie un message à votre équipe. Identique à la commande <b>ts</b>.
# <font color=#3399CC>team switch &lt;nom&gt;:</font> si vous êtes le meneur d'une équipe, vous en donnerez les rênes à la personne désignée.

class Team < Array
	attr_reader :leader
	attr_writer :leader
	
	def initialize leader
		super
		self << @leader = leader
	end
end