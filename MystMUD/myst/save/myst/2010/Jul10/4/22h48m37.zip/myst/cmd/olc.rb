﻿
# fonctions des commandes admin concernant la création et l'édition

class Actor
	def cmd_set cls, object, var, value # ~ $hash[id].var = value
		begin
			object.instance_variable_set "@#{var}", (value = $data[cls.to_sym].from_olc(var, value))
			wiz "Nouvelle valeur : #{value}"
		rescue
			wiz "Erreur : #{$!}"
	end end

	def cmd_summonItem item, number = 1
		if $p.inv[item] then $p.inv[item] += number
		else $p.inv[item] = number end
		wiz "Vous invoquez #{gift = item.x number}."
		each_close_heroe{|x| "#{sb? x} invoque #{gift}."}
	end
	
	def cmd_edit cls, o
		id = o.id
		s = "main::::[olc-OLC] - ::[redit-redit] - ::[olc #{cls}-#{cls}s]<br><br><font color=black>#{cls}[#{id}] :</font></b><br><table style=width:100%;border:none class=default><tr><td align=center width=100><b><font color=black>Variable<br></font></b></td><td width=100% align=center><b><font color=black>Valeur<br></font></td><td width=30 align=center></td><td align=center width=100><b><font color=black>Type<br></font></b></td>"
		Olc[cls].each do |var|
			v, type = $data[cls.to_sym].to_olc(var.to_sym, o.instance_variable_get("@#{var}"))
			rows = 1
			v_rows = v.split("\n")
			v_rows.each{ |row| rows += row.length / 70 }
			rows = 5 if var == :desc
			s << "</tr><tr><td align=right>#{var}</td><td><textarea rows=#{rows} id=olcv_#{var} cols=70>#{v}</textarea></td><td>::('set #{cls} #{id} #{var} '+replacen(el('olcv_#{var}').value)-OK)</td><td align=center>#{type}</td>"
		end
		echo "#{s}</tr></table>"
	end
	
	def cmd_clone klass, id
		if Clonable.index klass.to_sym
			hash = Classhash[klass]
			new_id = hash.new_id
			new_object = $data[klass.to_sym].copy_from hash[id]
			hash << new_object
			new_object.instance_variable_set :@id, new_id
			wiz "Objet #{klass}[#{id}] cloné en [#{new_id}] - ::[edit #{klass} #{new_id}-Modifier]"
		else
			wiz 'Ce type d\'objet ne peut pas encore être cloné.'
	end end

	def cmd_olcShow klass, object
		s = "obj::<b><font color=black>#{klass}[#{id = object.id}] :</font></b><br><br>::[edit #{klass} #{id}-modifier] ::[clone #{klass} #{id}-cloner]#{" <input class=input size=4 type=text value=1 id=summon>::('summonItem #{id} '+el('summon').value-invoquer)<br>" if klass == 'Item'}<br><br>"
		Olc[klass.to_s].each do |var|
			if (v = object.instance_variable_get("@#{var}").inspect).length > 50
				rows = v.length / 31 + 1
				s << "<br><b>&lt;#{var}&gt;</b><br><textarea style=width:100% rows=#{rows > 5 ? 5 : rows}>#{v}</textarea><br>"
			else
				s << "<br><b>&lt;#{var}&gt;</b><br>#{v}<br>"
		end end
		echo s
	end

	def cmd_olc klass = nil # shows olc or class pannel
		s = "main::::[olc-OLC] - ::[redit-redit]#{klass ? " - ::[olc #{klass}-#{klass}s]" : ""}<br><br>Listes : "
		Olc.each_key{|klass| s << "::[olc #{klass}-#{klass}]"}
		
		if klass
			vars = Classhash[klass]
			var = vars[0]
			
			s <<  "<br><br>#{klass}s :<br><br><div style='width:333px;position:fixed;top:0;right:0; bottom:300;overflow:auto'><table cellpadding=4 cellspacing=0 class=default><tr><td bgcolor=black><div id=obj></div></td></tr></table></div><table border=1 cellpadding=4 cellspacing=0 style=border-collapse:collapse class=default><tr>"
			
			vars.each_value do |var|
				s << "<td height=25 id=olcshow#{id = var.id} 
onmouseover=\"p('olcShow #{klass} #{id}');el('olcshow#{id}').bgColor='#0066FF'\" 
onmouseout=\"el('olcshow#{id}').bgColor=''\" 
onclick=\"p('edit #{klass} #{id}')\">#{id} - #{var}</td></tr><tr>"
			end
			echo "#{s[0..-4]}/table>"
		end
		echo s
	end
end
