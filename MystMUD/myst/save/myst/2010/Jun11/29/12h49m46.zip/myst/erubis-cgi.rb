#!C:/Ruby/bin/ruby.exe

require 'cgi'
require 'erubis'

$linux = false

class Eruby < Erubis::Eruby
  include Erubis::InterpolationEnhancer
  include Erubis::StdoutEnhancer
end

cgi = CGI.new
puts cgi.header
path = "C:/var/mud#{cgi.script_name}"

begin
	if File.exists? path
		eval Eruby.new(File.read(path).force_encoding 'UTF-8').src
	else
		puts "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \
\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
	<title>404 - Not Found</title>
</head>
<body>
	<h1>404 - Not Found</h1>
</body>
</html>"
	end
rescue
	puts "<div style=position:fixed;top:0px;left:0px;background-color:black;color:white><pre>****
#{CGI.escapeHTML $!.to_s} (#{$!.class}) from #{CGI.escapeHTML(($!.backtrace+caller[0..-2]).join("\n\tfrom "))}
****</pre></div>"
end
