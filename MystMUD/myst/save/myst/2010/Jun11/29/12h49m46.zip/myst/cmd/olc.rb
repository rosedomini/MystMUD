﻿
# fonctions des commandes admin concernant la création et l'édition

class Actor
	def cmd_set klass, object, var, value # ~ $hash[id].var = value
		# begin
			wiz "Nouvelle valeur : #{value = $data[klass.to_sym].from_olc object, var, value}"
			object.instance_variable_set "@#{var}", value
		# rescue
			# wiz "Erreur : #{$!}"
	# end end
	end

	def cmd_summonItem item, number = 1
		@inv.add item, number
		wiz "Vous invoquez #{gift = item.x number}."
		each_close_heroe{|x| "#{sb? x} invoque #{gift}."}
	end
	
	def cmd_edit klass, o
		id = o.id
		s = "<input type=button onclick=p('olc') value=OLC>\
<input type=button onclick=\"p('redit show')\" value=REdit>\
#{"<input type=button onclick=\"p('olc #{klass}')\" \
value=\"#{klass}\">" if klass}<br>\
<table style=width:100%;border:none class=default><tr>\
<td align=center width=100></td>\
<td width=100% align=center><b><font color=cyan>\
#{klass} (<font color=orange>#{id}</font>)</font><br></td>\
<td width=30 align=center></td><td align=center width=100></td>"

		Olc[klass].each do |var|
			v, type = $data[klass.to_sym].to_olc(var.to_sym, o.instance_variable_get("@#{var}"))
			rows = 1
			v_rows = v.split("\n")
			v_rows.each{ |row| rows += row.length / 60 }
			rows = 5 if var == :desc
			
			s << "</tr><tr><td align=right>#{var}</td>\
<td>#{Dat.var_editor klass, id, type, var, v, rows}</td>\
<td align=center>#{type}</td>"
			
		end
		echo :top_show, "#{s}</tr></table>"
	end
	
	def cmd_clone klass, id
		if Clonable.index klass.to_sym
			hash = Classhash[klass]
			new_id = hash.new_id
			new_object = $data[klass.to_sym].copy_from hash[id]
			hash << new_object
			new_object.instance_variable_set :@id, new_id
			wiz "Objet #{klass}[#{id}] cloné en [#{new_id}] - \
<a href=\"javascript:p('edit #{klass} #{new_id}')\">Modifier</a>"
		else
			wiz 'Ce type d\'objet ne peut pas encore être cloné.'
	end end

	def cmd_olcShow klass, object
		s = "<p align=center><b><font color=cyan>#{klass} (<font color=orange>\
#{id = object.id}</font>)</font></b></p>\
<input type=button onclick=\"p('edit #{klass} #{id}')\" value=Modifier> \
<input type=button onclick=\"p('clone #{klass} #{id}')\" value=Cloner>\
#{"<br> &nbsp;<input class=input size=4 type=text value=1 id=summon>\
 &nbsp;<input type=button onclick=\"p('summonItem #{id} ')\" \
value=Invoquer>" if klass == 'Item'}<br><hr>"

		Olc[klass.to_s].each do |var|
			if (v = object.instance_variable_get("@#{var}").inspect).length > 50
				rows = v.length / 30 + 1
				s << "<br><b><font color=cyan>#{var}: </font></b><br>\
<textarea style=width:100% rows=\"#{rows > 10 ? 10 : rows}\" cols=33>#{v}</textarea><br>"
			else
				s << "<br><b><font color=cyan>#{var}: </font></b>#{v}<br>"
		end end
		echo :div_setHtml, 'olc_preview', s
	end

	def cmd_olc klass = nil, needle = nil # shows olc or class pannel
		s = "<input type=button onclick=p('olc') value=OLC>\
<input type=button onclick=\"p('redit show')\" value=REdit>"

		Olc.each_key{|klass| s << "<input type=button \
onclick=\"p('olc #{klass}')\" value=\"#{klass}\">"}
		
		if klass		
			if needle
				if needle == '*'
					vars = Classhash[klass]
					display = "Affichage de tou#{'te' if Dat::ClassVoc[klass.to_sym][2]}s les %"
				else
					vars = Classhash[klass].select{|id, x| x.name.contains needle}
					display = "Affichage des % dont le nom contient \
\"<font color=orange>#{needle}</font>\""
				end
			else
				vars = Classhash[klass].select{|id, x| x.in_olc? self}
				display = "Affichage des % apparent#{'e' if Dat::ClassVoc[klass.to_sym][2]}s \
dans un rayon de 6 salles. <a href=\"javascript:p('olc #{klass} *')\">Afficher tout</a>"
			end
			
			echo :top_show, "#{s}<br><br><p>&nbsp; #{display.sub! '%', "<b>\
<font color=cyan>#{Dat::ClassVoc[klass.to_sym][1]}</font></b>"}</p><div style=\"\
width:366px;position:fixed;top:0px;right:0px;bottom:300px;overflow:auto\">\
<table id=olc_preview_table class=default><tr>\
<td><div id=olc_preview></div></tr></table></div><div id=\"list_#{klass}\"></div>"
			
			echo :list_show, klass, 'olc_edit'
			
			vars.each_value do |var|
				echo :list_append, klass, [id = var.id].pack('N'), "<span \
onmouseover=\"p('olcShow #{klass} #{id}')\">#{var} \
(<font color=orange>#{id}</font>)</span>"

			end
			
			echo :list_display, klass
		else echo :top_show, s end
	end
	
	def cmd_varEdit var, arg
		case var
		when 'Mob:skin'
			s = '<div style=width:100%>'
			
			$skin.each_value do |skin|
				s << "<img title=\"#{skin.name}\" style=float:left onclick=\
\"p('varEdit Mob:skin2 #{arg} #{skin.id}')\" src=\"ico/chars/#{skin.source}.png\">"
			end
			
			echo :div_setHtml, 'select_skin', s << '</div>'
		when 'Mob:skin2'
			if arg =~/(\d+) (\d+)/
				v = $skin[$2.to_i].source
				cmd "set Mob #{$1} skin #{v}"
				echo :div_setHtml, 'select_skin', "<p align=center><img title=\"#{v}\" \
src=\"ico/chars/#{v}.png\" onclick=\"p('varEdit Mob:skin #{$1}')\"></p>"
			else wiz 'Erreur: utilisation de la commande varEdit avec de mauvais paramètres.' end
		when 'Mob:avatar'
			s = '<div style=width:100%>'
			
			$avatar.each_value do |avatar|
				s << "<img title=\"#{avatar.source}\" style=float:left onclick=\
\"p('varEdit Mob:avatar2 #{arg} #{avatar.id}')\" src=\"ico/avatar/#{avatar.source}.png\">"
			end
			
			echo :div_setHtml, 'select_avatar', s << '</div>'
		when 'Mob:avatar2'
			if arg =~/(\d+) (\d+)/
				v = $avatar[$2.to_i].source
				cmd "set Mob #{$1} avatar #{v}"
				echo :div_setHtml, 'select_avatar', "<p align=center><img title=\"#{v}\" \
src=\"ico/avatar/#{v}.png\" onclick=\"p('varEdit Mob:avatar #{$1}')\"></p>"
			else wiz 'Erreur: utilisation de la commande varEdit avec de mauvais paramètres.' end
		end
	end
end
