﻿
# fonctions permettant d'afficher des erreurs

class Error
	def Error.olc_class
		echo :top_show, "<br><p>Seules les classes suivantes sont disponibles dans l'OLC :</p>\
<p>#{Olc.keys.join ', '}</p>"
	end
	
	def Error.cmd_unavailable; wiz 'Commande indisponible' end
	
	def Error.cmd_hack c # command name used
		$hack << "<u>#{Time.now}:</u> <b>#{$p}</b> uses <b>#{c}</b> via scripting."
		$g.each do |guest|
			if guest.h and guest.h == $p
				guest.eject 'Scripting interdit et loggué ! Merci d\'utiliser "pray" en cas de problème'
				return
			end
		end
	end
	
	def Error.warning s; print "\n\n#{s} :\n#{$!}\n\n" end
	def Error.sql id; puts "\n\t\t#{@id} : #{$!}"; raise 'SQL save failed !' end
	
	def Error.display
		puts "****\n\t#{$!} (#{$!.class})\n\tfrom #{($!.backtrace+caller[0..-2]).join("\n\tfrom ")}\n****"
	end
end