﻿
# def safe_eval x
	# x.strip!
	# if x == 'nil'
		# nil
	# elsif x.empty?
		# raise "#{__FILE__}:#{__LINE__}: string to eval is empty."
	# elsif x == '0'
		# 0
	# elsif (i = x.to_i) != 0
		# i
	# elsif (x =~ /^:[\w_\?]+$/) or (x =~ /:'.*'/ and x[-2] != '\\')
		# x[1..-1].to_sym
	# elsif ((x =~ /^".+"$/) or (x =~ /^'.+'$/)) and x[-2] != '\\'
		# eval x
	# elsif x =~ /^\[(.*)\]$/ #make dot match new lines
		# array = get_array_struct($1.strip)
		# array.size.times{|i| array[i] = safe_eval array[i]}
		# array
	# elsif x =~ /^\{(.*)\}$/ #make dot match new lines
		# pairs = get_hash_struct($1.strip)
		# hash = {}
		# pairs.each{|x, y| hash[safe_eval x] = safe_eval y}
		# hash
	# else
		# raise "#{__FILE__}:#{__LINE__}: can't eval string `#{x}'"
# end end

# def get_hash_struct x
	# pairs = []
	# context = 0
	# start = 0
	# x.length.times do |i|
		# y = x[i]
		# if context.zero?
			# if y == "'" then context = 1 elsif y == '"' then context = 2
			# elsif y == ','
				# pairs << x[start, i].strip
				# start = i+1
			# end
		# elsif context == 1
			# if y == '\\' then context = 10 elsif y == "'" then context = 0 end
		# elsif context == 2
			# if y == '\\' then context = 20 elsif y == '"' then context = 0 end
		# elsif context == 10
			# context = 1
		# elsif context == 20
			# context = 2
	# end end
	# pairs << x[start..-1]
	# context = 0
	# pairs.each_with_index do |x, j|
		# x.length.times do |i|
			# y = x[i]
			# if context.zero?
				# if y == "'" then context = 1 elsif y == '"' then context = 2
				# elsif y == '=' and x[i+1] == '>'
					# pairs[j] =  [x[0, i].strip, x[(i+2)..-1].strip]
					# break
				# end
			# elsif context == 1
				# if y == '\\' then context = 10 elsif y == "'" then context = 0 end
			# elsif context == 2
				# if y == '\\' then context = 20 elsif y == '"' then context = 0 end
			# elsif context == 10
				# context = 1
			# elsif context == 20
				# context = 2
# end end end end

# p safe_eval '{:lol => "yah", :poo => "yeah"}'

p [0, 1, 2].include? 3
