﻿
class Actor
	def check_affections
		s = '<font color=orange> ~ Enchantements et maléfices qui vous affectent ~</font>'
		@aff.each do |aff, pow|
			s << "<br> - #{aff}: #{pow[0]} minutes, puissance #{pow[1]}"
		end
		wiz s
	end
	
	def check_equipement
		s = "Vous êtes muni#{e} de l'équipement suivant :"
		@equip.each do |on, item|
			s << "<br> - #{Actor::Equip[on]} : #{item}" end
		echo 'main'
		wiz s
	end
	
	def follow actor
		cmd_team :leave if @team
		if @following == actor
			wiz 'Vous suivez déjà cette personne.'
		else
			wiz "Vous ne suivez plus #{@following}." if @following
			wiz "Vous commencez à suivre #{@following = actor}"
		end
	end
	
	def check_inventory
		s = 'Vous avez :'
		@inv.each do |item, number|
			s << '<br>- ' << item.x(number) end
		echo 'main'
		wiz s
	end
	
	def check_score
		wiz "<table cellpadding=0 cellspacing=0 style=width:100%><tr>
<td align=center colspan=3><font color=orange>~ #{name} ~</font></td><td></td>
</tr><tr><td colspan=2><font color=#3399CC>
Niveau:</font> #{@level} et #{((@xp * 100.0)/(needed = xp_needed)).round}%</td>
<td colspan=2><font color=#3399CC>Vitalité:</font> #{@maxhp}</td>
</tr><tr>
<td colspan=2><font color=#3399CC>Expérience:</font> #{@xp} sur #{needed}</td>
<td colspan=2><font color=#3399CC>Énergie:</font> #{@maxmp}</td>
</tr><tr>
<td><font color=#3399CC>Force:</font> #{@str}</td>
<td><font color=#3399CC>Dextérité:</font> #{@dex}</td>
<td><font color=#3399CC>Constitution:</font> #{@con}</td>
<td><font color=#3399CC>Sagesse:</font> #{@wis}</td>
</tr>"
	end
	
	def check_spells
		s = '<font color=orange> &nbsp; &nbsp; &nbsp; ~ Liste de vos sorts ~</font>'
		@spell.each do |spell, power|
			s << "<br>#{spell.school} => #{spell} : #{power}%"
		end
		wiz s
	end
	
	def cmd_shortcut action, id, value
		case action
		when 'cmd'
			@shortcut[1][id] = value
			echo 'main'
			wiz "Commande modifiée pour le raccourcis N°#{id+1}"
			show_shortcuts
		when 'ico'
			if $icon.index value
				@shortcut[0][id] = value
				wiz "Icône modifiée pour le raccourcis N°#{id+1}"
				show_shortcuts
			else Error.cmd_hack 'shortcut' end
		when 'edit'
			s = ''; i = 0
			$icon.each do |ico|
				s << "<td><img src='ico/shortcuts/#{ico}.png' onclick=\"p('!shortcut ico #{id} #{ico}')\"></td>"
				s << '</tr><tr>' if ((i+=1)%26).zero?
			end
			
			echo "main::<u>Configuration du raccourcis N°#{id+1} :</u><br><br><p>Choix de l'icône :</p><table cellpadding=0 style=height:120px;border-collapse:collapse><tr>#{s}</tr></table>
<p>Commande(s) associée(s) (une par ligne) : </p><br>
<textarea rows=5 id=shcmd style=width:90%>#{@shortcut[1][id]}</textarea>
::('!shortcut cmd #{id} '+replacen(el('shcmd').value)-OK)"

		when 'moveup'
			if id == 0
				wiz 'Permutation impossible car ce raccourcis est en tête de liste.'
			else
				2.times do |i|
					array = @shortcut[i]
					x, array[id - 1] = array[id - 1], array[id]
					array[id] = x
				end
				cmd_option 'shortcut'
				show_shortcuts
			end
		when 'movedown'
			if id == 9
				wiz 'Permutation impossible car ce raccourcis est en fin de liste.'
			else
				2.times do |i|
					array = @shortcut[i]
					x, array[id + 1] = array[id + 1], array[id]
					array[id] = x
				end
				cmd_option 'shortcut'
				show_shortcuts
			end
		else
			Error.cmd_hack 'shortcut'
		end
	end
	
	def remove on # place where item to remove is
		item = @equip[on]
		@equip.delete on
		@inv << item
		update_weapons_and_shields if on == :main_gauche or on == :main_droite
		wiz "Vous enlevez #{item}."
		each_close_heroe{|x| x.wiz "#{sb? x} enlève #{item}."}
		each_close_mob do |x|
			x.on_remove_view self, item, on if x.respond_to? :on_remove_view
	end end
	
	def cmd_team action, actor = nil
		case action
		when :accept
			@team = Team.new(self) unless @team
			if @team.leader == self
				if actor.following == self
					@team.wiz "#{actor} fait maintenant partie de votre équipe."
					@team << actor
					actor.wiz "Vous faites maintenant partie de l'équipe de #{@name}."
				else wiz "#{actor} doit vous suivre avant de pouvoir l'accepter dans votre équipe." end
			else wiz 'Vous n\'êtes pas le meneur de l\'équipe.' end
		when :join
			if @team then wiz 'Vous faites déjà partie d\'une équipe.'
			else
				follow actor
				actor.wiz "&lt;&lt; #{@name} veut se joindre à votre équipe. &gt; &gt;", :yellow
			end
		when :leave
			if @team
				wiz 'Vous venez de quitter votre équipe.'
				@team.delete_one self
				@team.wiz "#{@name} vient de quitter votre équipe."
				if @team.size == 1
					@team[0].team = nil
					@team.clear
				end
				if @team.leader == self
					(leader = @team.leader = @team[0]).wiz 'Vous êtes maintenant le meneur de l\'équipe.'
					@team.no(leader).each do |actor|
						actor.wiz "#{leader} est maintenant le meneur de l\'équipe."
						actor.follow leader
					end
				end
				@team = nil
			else wiz 'Vous ne faites actuellement pas partie d\'une équipe.' end
		when :switch
			if @team
				if @team.leader == self
					s = "#{actor} remplace #{@name} en temps que meneur de l'équipe."
					wiz "#{actor} vous remplace en temps que meneur de l'équipe."
					(@team.leader = actor).wiz "Vous remplacez #{@name} en temps que meneur de l'équipe."
					@team.each do |x|
						if x != self and x != actor
							x.wiz s
							x.follow actor
					end end
				else wiz 'Vous n\'êtes pas le meneur de l\'équipe.' end
			else wiz 'Vous ne faites actuellement pas partie d\'une équipe.'
	end end end

	def wear item
		if wearon = item.wearon.find{|on| @equip[on].nil?}
			msg1 = "équipe #{item}."
			msg2 = "Vous équipez #{item}."
		elsif wearon = item.wearon[0]
			last = @equip[wearon]
			@inv << last
			msg1 = "remplace #{last} par #{item}."
			msg2 = "Vous remplacez #{last} par #{item}."
		else
			wiz 'Cet objet ne peut pas être équipé.'
			return
		end
		
		if wearon == :main_droite and i = @equip[:main_gauche] and i.stats[:deux_mains]
			remove :main_gauche
			wiz 'Vous portiez une arme à deux mains.', :red
		elsif wearon == :main_gauche and i = @equip[:main_droite] and i.stats[:deux_mains]
			remove :main_droite
			wiz 'Vous portiez une arme à deux mains.', :red
		end
		
		@equip[wearon] = @inv >> item
		update_weapons_and_shields if wearon == :main_gauche or wearon == :main_droite
		
		wiz msg2
		each_close_heroe{|x| x.wiz "#{sb? x} #{msg1}"}
		each_close_mob do |x|
			x.on_wear_view self, item, wearon if x.respond_to? :on_wear_view end
	end
end