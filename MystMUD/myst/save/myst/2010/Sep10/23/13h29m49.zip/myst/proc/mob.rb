﻿
class << Mob.named('Kariati')
	def hurt dmg, actor
		@hp -= dmg
		if @hp < 1
			@hp = @maxhp
			@mp = @maxmp
			cmd 'cast soin'
			Actor.peace_on self
			if actor.heroe?
				say 'Très bien, je vois que vous progressez.'
				actor.add_xp xp_gives(actor) if actor and actor.heroe?
			end
		elsif @hp > @maxhp then @hp = @maxhp
	end end
	
	def on_see actor 
		if actor.heroe? and @room.id == 2
			if (i = actor.equip[:main_gauche] and i.type == :arme) or (i = actor.equip[:main_droite] and i.type == :arme)
				say 'Tu es armé, parfait. Tape "kill kari" pour engager le duel.'
			else
				say "Bon#{wdate('hours') > 17 ? ' soir,' : 'jour'} #{actor.name}. Je pourrais t'enseigner les bases du combat, mais pour cela il te faut une arme. Part donc voir le forgeron, en suivant le chemin vers la forge."
	end end end
end

class << Mob.named('Adel')
	def give_special actor, item
		if actor.room == @room and @room.id == 6
			if actor.can_hold? item
				actor.wiz "#{@name} vous donne #{item}."
				actor.inv << item
			else
				say 'Cet objet semble trop lourd pour toi, je te laisse au sol.'
				@room.actors.wiz "#{@name} pose #{item}."
				room.inv << item
			end
			actor.wiz_help "Tapez <font color=orange>wear #{item.name.split(' ')[1]}</font> pour l'équiper."
		end
		@busy_building_weapons = nil
	end
	
	def on_wear_view actor, item, on
		if item.id == 1 or item.id == 7 and @room.id == 6
			emote 'semble satisfait du résultat.'
	end end
	
	def on_hear actor, sth
		return if @room.id != 6
		sth.downcase!
		if 'oui'[0, sth.length] == sth
			if @busy_building_weapons then say 'Je suis occupé pour l\'instant.'
			else
				@busy_building_weapons = true
				say "Très bien. Je reviens dans une minute avec ce qu\'il te faut. Ne bouge pas hm... #{actor.name}."
				cmd 'wear marteau'
				Task.add(@room, :wiz, 0, -2, 'Des bruits assourdissants résonnent dans la forge.')
				Task.add(self, :cmd, 0, -3, 'remove marteau')
				Task.add(self, :give_special, 0, -4, actor, $item[7])
				Task.add(self, :give_special, 0, -4, actor, $item[1])
			end
		elsif 'non'[0, sth.length] == sth
			say 'Et bien si tu changes d\'avis, fait le moi donc savoir !'
	end end
	
	def on_see actor
		if actor.heroe? and @room.id == 6
			if (i = actor.equip[:main_gauche] and i.type == :arme) or (i = actor.equip[:main_droite] and i.type == :arme)
				say 'Tu es armé, parfait. Tape "kill kari" pour engager le duel.'
			else
				say "Salut #{actor.name}. Tu viens chercher ton équipement ?"
				actor.wiz_help '<font color=orange>say oui</dont>/<font color=orange>non</font> pour lui répondre.'
	end end end
end