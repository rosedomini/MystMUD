
class Actor
	def poing_gauche
		Poing.new(@str)
	end
	
	def poing_droit
		Poing.new(@str)
	end
end

class Poing
	attr_reader :stats
	
	def initialize str
		damage_type = case rand(100)
			when 0..50 then :cognant
			when 51..85 then :frappant
			else :tapant
		end
		@stats = {
			:damage => str,
			:damage_type => damage_type
		}
	end
end