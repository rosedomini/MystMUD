﻿
# Script principal

=begin Arguments :
		check_cmd pour vérifier la liste des commandes
=end

GC.disable # sera réactivé ponctuellement

print 'Parse & def... '

trap 'SIGINT', ->{shutdown} # Ctrl+C

$actor		= $a	= {}
$avatar			= {}
$body		= $b	= {}
$command		= {}
$data				= {}
$guest		= $g	= []
$heroe		= $h	= {}
$icon				= []
$item		= $i	= {}
$mob				= {}
$power				= {}
$race				= {}
$room		= $r	= {}
$shop				= {}
$skin				= {}
$spell				={}
$system	= $sys={}
$world				= {}
$area				= {}

require 'srv/settings'

require 'mysql'
require 'digest/md5'
require 'net/http'
require 'date'
require 'cgi'
require 'uri'
require 'socket'
include Socket::Constants

Time_start = Time.now.to_f

require 'world/Area'
require 'world/Avatar'
require 'world/Body'
require 'world/Item'
require 'world/Race'
require 'world/Room'
require 'world/Shop'
require 'world/Skin'
require 'world/Spell'
require 'world/Team'
require 'world/World'

require 'srv/Dat'
require 'srv/Dat.clone'
require 'srv/Dat.define'
require 'srv/Dat.load'
require 'srv/Dat.save'
require 'srv/Load'
require 'srv/Log'
require 'srv/Save'
require 'srv/globals'
require 'srv/Guest'
require 'srv/Task'

require Cache_dir

require 'cmd/action'
require 'cmd/admin'
require 'cmd/Command'
require 'cmd/communication'
require 'cmd/divers'
require 'cmd/divers_a'
require 'cmd/gestion'
require 'cmd/gestion_a'
require 'cmd/olc'
require 'cmd/check'
require 'cmd/check_admin'

require 'func/Check'
require 'func/Destroy'
require 'func/Error'
require 'func/Fight'
require 'func/Kernel'
require 'func/lists'
require 'func/modifications'
require 'func/Power'
require 'func/System'
require 'func/time'

require 'proc/actor'
require 'proc/power'

require 'actor/Actor'
require 'actor/Heroe'
require 'actor/Mob'
require 'actor/Fist'

require 'spells'

connect_db
	Dat.define
	Load.world	
	require 'proc/mob'
	Load.mob_repop
	$w = $world[1]
$db.close

check_cmd if ARGV[0] == 'check_cmd'

Check.world

flood_time= 0
$lastsave	= 0
time			= 0

$guest << $srv = $server = TCPServer.new(Hostname, Port)

puts "Server started at #{Hostname}:#{Port}"
		
task_time = Time.now.to_f

loop do
	if task_time + 0.1 < now = Time.now.to_f
		Task.execute(task_time = now) end
	
	next unless ready = select($guest, nil, nil, 0.2)
	
	now = Time.now.to_f
	
	for sock in ready[0]
		if sock == $server
			begin
				sock = $server.accept_nonblock
				# sock.write "#{Server_policy}<!--#{Server_MOTD}-->\0"
				sock.write "#{Server_policy}<!--#{Server_MOTD}-->"
				sock.new_guest
				$guest << sock
				puts 'Client joined'
			# rescue
				# puts "#{__FILE__}:#{__LINE__} #{$!.inspect}"
			end
		elsif sock.off then sock.eject
		else
			arg = CGI.escapeHTML sock.gets.force_encoding('UTF-8').strip.gsub('\\', '').gsub('::', ': :')
			
			next if arg == '&lt;policy-file-request/&gt;'
			
			if flood_time <= now
				flood_time = now + 1
				$guest.each{|x| x.flood = 0 }
			end
			
			if (sock.flood += 1) > FloodLimit
				sock.eject 'Flood interdit'
				next
			end
			
			# begin
				sock.__send__ sock.control, arg
			# rescue
				# error = "#{caller[0]} : #{$!} (#{$!.class})\n\tfrom #{caller[0..-1].join("\n\tfrom ")}"
				# puts ">>>\n#{error}\n<<<"
				# Log.cmd_error error, arg, sock.h
				# $guest.each do |guest|
					# guest.h.wiz "Suite à une faille dans la matrice, le monde va remonter le temps de #{((Time.now.to_f - $lastsave) / 60).round} minutes. Les données sur l'erreur ont été enregistrées. Utilisez la commande pray si vous avez des informations complémentaires.", :red if guest.h
				# end
				# send_all
				# shutdown
			# end
			
			send_all
			
			puts "Executed #{arg} in #{(1000000*(Time.now.to_f - now)).round}us"
		end
	end
end
