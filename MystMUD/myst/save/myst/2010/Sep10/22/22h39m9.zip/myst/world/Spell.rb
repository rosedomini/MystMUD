﻿
class Spell
	attr_reader :id, :name, :desc, :school, :min_cost, :max_cost, :func, :arg_target
	alias to_s name
	
	def initialize id; @id = id end
	def inspect; "$spell[#{@id}]" end
	def container; $spell end
end