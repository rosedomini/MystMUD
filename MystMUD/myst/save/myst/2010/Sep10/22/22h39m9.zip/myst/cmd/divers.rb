﻿
class Actor
	# affiche le calendrier et la date virtuelle
	def check_time
		s = "<table width=400 bgcolor=white border=1 style=color:black;border-collapse:collapse;margin-left:50px><tr><td colspan=2 align=center><font color=blue>Année #{(d = wdate)['year']}</font></td><td>#{6}</td><td>#{World::Month[6]}</td></tr>"
		5.times do |n|
			s << "<tr><td>#{n+=1}</td><td>#{World::Month[n]}</td><td>#{n+=6}</td><td>#{World::Month[n]}</td></tr>"
		end
		wiz "#{s}</table><br>Nous sommes le jour #{d['day']} du mois d'#{d['month']} de l'année #{d['year']}.<br>Il est #{d['hours']}h#{d['minutes']}."
	end
	
	def cmd_aide cmd = nil, word = nil # commande
		if cmd.is_a? Command or cmd.is_a? Symbol and cmd = $command[cmd.to_s]
			wiz "<font color=#3366CC>Syntaxe: </font>#{cmd.syntax}<br> ¤ #{cmd.help}", :orange
		elsif cmd == 'move'
				wiz '<font color=#3366CC>Déplacer votre personnage: </font>il vous suffit de taper <b>n</b>, <b>o</b>, <b>s</b>, <b>e</b>, <b>b</b> ou <b>h</b> pour aller dans les directions <b>nord</b>, <b>ouest</b>, <b>sud</b>, <b>est</b>, <b>bas</b> ou <b>haut</b>. Pour les autres issues, entrez son nom partiellement ou entièrement. Par exemple : <b>esc</b> pour monter ou descendre un <b>escalier</b>.'
		elsif cmd == 'shortcuts'
				wiz '<font color=#3366CC>Utilisation des raccourcis: </font>les touches <b>&é"\'(-è_çà</b> correspondent aux raccourcis de 1 à 10 lorsque le curseur est sur la barre de commande et que celle-ci est vide.</p><p>La configuration des raccourcis se fait via le menu ::[option-option].'
		elsif cmd == 'keywords'
			wiz 'Les mots clefs <b>from</b>, <b>on</b> et <b>to</b> sont utilisés pour les commandes complexes. Vous pouvez les remplacer par des "<b>,</b>".'
		elsif cmd == 'syntax'
			syntax = Syntax_words.each{|x, syntax| break syntax if word == x}
			wiz "<font color=#3399CC>#{word.capitalize}:</font> #{syntax.is_a?(String) ? syntax : 'Il n\'y a pas d\'aide pour ce paramètre.'}"
		else
			s = 'main::<br>::[aide move-Déplacement du personnage] ::[aide shortcuts-Utilisation des raccourcis]<br>
<br><u>Liste des commandes :</u><br><br>'
			[:action, :communication, :gestion, :divers].each do |type|
				s << type.to_s.capitalize; s << '<p>'
				$command.each_value do |cmd|
					if cmd.keyboard and cmd.type == type and cmd.authlevel <= $p.authlevel
						s << "<a href=\"javascript:p('aide #{cmd}')\" title=\"#{cmd.french_name}\">#{cmd}</a>"
				end end
				s << '</p>'
			end
			echo s
	end end

	def cmd_option option = nil
		if option == 'skin'
			s = 'main::<br><u>Skins disponibles :</u><br><br><table class=compact><tr>'
			i = 1
			
			$skin.each_value do |skin|
				s << "<td><img onclick=\"p('!selectSkin #{skin.id}')\" src=ico/chars/#{skin.source}.png></td>"
				s << '</tr><tr>' if (i%20).zero?
				i += 1
			end
			
			s << '</tr></table><br><br><u>Avatars disponibles :</u><br><table class=compact><tr>'
			i = 1
			
			$avatar.each_value do |avatar|
				s << "<td><img width=102 onclick=\"p('!selectAvatar #{avatar.id}')\" src=ico/avatar/#{avatar.source}.png></td>"
				s << '</tr><tr>' if (i%6).zero?
				i += 1
			end
			
			echo s << '</tr></table>'
			
		elsif option == 'shortcut'
			list = 'list::shortcuts::edit;moveup;movedown::'
			
			commands = @shortcut[1]
			@shortcut[0].each_with_index do |icon, i|
				list << ";;<table class=\"compact\"><tr><td><img class=\"list-ico\" src=\"ico/shortcuts/#{icon}.png\"></td><td style=\"padding-left:7px;width:100%\" align=\"left\"><b>#{i+1}</b> : #{commands[i]}</td></tr></table>,#{i+1}"
			end
			
			echo "main::<p><u>Configuration des raccourcis :</u></p><div id=list_shortcuts></div>::_#{list}"
		else
			echo 'main::<br>
<p><u>Options disponibles :</u></p>
<p>::[option shortcut-Configurer les raccourcis]</p>
<p>::[option color-Changer les couleurs]</p>
<p>::[option skin-Changer d\'apparence]</p>
<p>::[option shortcuts-Configurer les raccourcis]</p>
<p>::[pray-Signaler ou proposer quelque chose]</p>'

		end
	end
	
	def cmd_spell spell
		s = "<font color=orange>~ #{spell} ~</font>"
		if power = @spell[spell]
			s << " maitrisé à #{power}%"
		else s << '<br>Vous ne maitrisez pas ce sort.' end
		wiz s << "<br>#{spell.desc}<br>École: #{spell.school}
<br>Coût d'énergie à puissance minimale: #{spell.min_cost}
<br>Coût maximal: #{spell.max_cost}"
	end

	def cmd_who all = false
		if all
			s = '<font color=orange>Liste des joueurs :</font>'
			$heroe.each_value do |heroe|
				s << "<br> - #{heroe}#{' (en ligne)' if heroe.online?}"
			end
		else
			s = '<table width=400 cellpadding=2 cellspacing=0><tr><td style="border-right:1px solid white"><font color=orange align=left>Joueurs connectés</font></td><td style="border-right:1px solid white">niveau</td><td>informations</td></tr>'
			$actor.each_value do |actor|
				s << "<tr><td style='border-right:1px solid white'>#{actor}</td><td style='border-right:1px solid white'>#{actor.level}</td><td></td></tr>" if actor.heroe?
			end
			s << '</table>'
		end
		wiz s
	end
end