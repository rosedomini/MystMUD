﻿
class Dat
	attr_reader :name, :hash, :class, :table, :data
	
	def initialize name, hash, klass, table = nil
		@name = name
		@class = klass
		@table = table ? table : name
		@hash = hash
		@data = []
		@queries = []
	end
	
	def add var
		var[:set] = var[:load] unless var[:set]
		var[:save] = var[:load] unless var[:save]
		var[:olc] = var[:save] unless var[:olc]
		var[:clone] = var[:load] unless var[:clone]
		@data << var
	end
	
	def after_load
		print "#{@name}, "
		
		hash.each_value do |object|
			object.after_load if object.respond_to? :after_load
	end end
	
	def copy_from object
		new_object = object.clone		
		@data.each do |var|
			new_var = Data::Clone.send var[:clone], object.instance_variable_get("@#{var[:name]}")
			new_object.instance_variable_set "@#{var[:name]}", new_var
		end
		new_object
	end
	
	def create
		values = {}
		
		@data.each do |var|
			name, load_method, default_value = var[:name], var[:load], var[:default]
			if default_value
				values[name] = Data::Load.send load_method, default_value
		end end
		
		object = @class.new(@hash.new_id)
		
		values.each do |name, value|
			object.instance_variable_set "@#{name}", value end
		
		object.instance_variable_set :@id, @hash.new_id
		@hash << object
		object
	end
	
	def from_olc object, var, value
		var = var.to_sym
		if data = @data.find{|x| x[:name] == var}
			Data::Load.send(data[:set], value, true)
		else
			raise "Error@#{__FILE__}:#{__LINE__}\n\tObject: #{object.inspect}\n\tVariable: #{var}\n\tValue: #{value}"
	end end
	
	def load
		print "#{@name}, "
		
		@data.each do |var|
			name = "@#{var[:name]}"
			load = var[:load]
			@hash.each_value do |x|
				x.instance_variable_set name, Data::Load.send(load, x.instance_variable_get(name))
	end end end
	
	def make to_add
		to_add.each do |var_data| add var_data
	end end
	
	def pre_load
		q = $db.query "SELECT * FROM #{@table} WHERE 1"
		
		q.each_hash do |d|
			values = {}
			
			@data.each do |var|
				values[name = var[:name]] = d[name.to_s] end
			
			if @name == :System or @name == :Command # exeptions: $sys and $command sort by name
				id = values[:name]
			else
				id = values[:id].to_i end
			
			object = @hash[id] = @class.new(id)
			
			values.each do |name, value|
				object.instance_variable_set "@#{name}", value
	end end end
	
	def save
		print "#{@name}, "
		
		@queries.clear
		@queries << "TRUNCATE table #{@table}"
	
		@hash.each do |id, object|
			query = "INSERT INTO #{@table} VALUES("
		
			@data.each do |var|
				name, save_method = var[:name], var[:save]
				
				value = object.instance_variable_get "@#{name}"
				query << "'#{Data::Save.send(save_method, value).gsub "'", "''"}',"
			end
			
			@queries << "#{query[0..-2]})"
		end
		
		@queries
	end
	
	def to_olc var, value
		@data.each do |data|
			return Data::Save.send(data[:olc], value, true), data[:olc] if data[:name] == var
		end
		"Error: #{__FILE__}:#{__LINE__}"
	end
end
