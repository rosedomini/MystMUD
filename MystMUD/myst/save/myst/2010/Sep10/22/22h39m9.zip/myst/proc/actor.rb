
def Actor.peace_on actor
	actor.target = nil
	$actor.each_value{|x| x.target = nil if x.target == actor}
end