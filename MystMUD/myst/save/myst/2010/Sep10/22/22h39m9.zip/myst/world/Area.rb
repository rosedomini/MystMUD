﻿
class Area
	attr_reader :id, :name, :room
	alias to_s name
	
	def initialize id
		@id = id
		@room = []
	end
end