﻿
class Data::Save; end
class << Data::Save
	def area value, olc = nil
		value.id.to_s end
	
	def array value, olc = nil
		value.inspect end
	
	def bool value, olc = nil
		value.to_str end
	
	def equipement value, olc = nil
		(equip = value.clone).each do |wear, item|
			equip[wear] = item.id end
		equip.inspect end
	
	def hash value, olc = nil
		value.inspect end
	
	def help value, olc = nil
		value.gsub(/<br>/, "\n") end
	
	def inventory value, olc = nil
		inv = {}
		value.each do |item, number|
			inv[item.id] = number unless number.zero?
		end
		inv.inspect end
	
	def int value, olc = nil
		value.to_s end
	
	def spell_list value, olc = nil
		list = {}
		value.each do |spell, pow|
			list[spell.id] = pow end
		list.inspect end
	
	def string value, olc = nil
		value end
	
	def inspect value, olc = nil
		value.inspect end
	
	def exits exits, olc= nil
		value = exits.clone
		value.each do |exit, room| value[exit] = room.id end
		value.inspect end
	
	def nil value, olc = nil
		'nil' end
	
	def room value, olc = nil
		value.id.to_s end
	
	def zero value, olc = nil
		'0' end
	
	def sym_to_s value, olc = nil
		value.to_s end
end