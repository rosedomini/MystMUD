
Power.new :gain_de_vie, -> power do
	$p.instance_eval do
		heal power
		wiz "Vos blessure se referment. Vous vous sentez mieux ~ #{power} points."
	end
end