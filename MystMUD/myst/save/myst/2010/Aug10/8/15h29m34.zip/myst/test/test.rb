﻿
class Cool
	def rep
		replace 'rep'
	end
end

# p s.method(:replace).owner
# p s.method(:replace).receiver

# p s