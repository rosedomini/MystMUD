﻿
# fonctions permettant d'afficher des erreurs

class Error
	def Error.olc_class
		echo :top_show, "<br><p>Seules les classes suivantes sont disponibles dans l'OLC :</p>\
<p>#{OLC.keys.collect(&:to_s).join ', '}</p>"
	end
	
	def Error.cmd_unavailable; wiz 'Commande indisponible' end
	
	def Error.cmd_hack c # command name used
		$hack << "<u>#{Time.now}:</u> <b>#{$p}</b> uses <b>#{c}</b> via scripting."
		$g.each do |guest|
			if guest.h and guest.h == $p
				guest.eject 'Scripting interdit et loggué ! Merci d\'utiliser "pray" en cas de problème'
				return
			end
		end
	end
	
	def Error.warning s; print "\n\n#{s} :\n#{$!}\n\n" end
	def Error.sql id; puts "\n\t\t#{@id} : #{$!}"; raise 'SQL save failed !' end
	
	def Error.handle report = 'stderr', log = true
		message = "in #{($@.reverse[0..-2]).join("\nin ")}
in #{$@[0]}:
	#{$!} (#{$!.class})"
		report = [report] if report.is_a? String
		report.each do |report|
			case report
			when 'stderr'
				STDERR << "\n#{message}\n"
			when 'wiz'
				wiz CGI.escapeHTML(message).
					gsub("\n", '<br>').
					gsub("\t", '&nbsp; &nbsp; &nbsp; ')
			when 'light wiz'
				wiz CGI.escapeHTML(message.split("\n")[-3..-1].join "\n").
					gsub("\n", '<br>').
					gsub("\t", '&nbsp; &nbsp; &nbsp; ')
			when 'html page'
				puts "<div style=position:fixed;top:0px;left:0px;\
	background-color:black;color:white><pre>\
	Internal Server Error - 500\n
	#{CGI.escapeHTML message}</pre></div>"
			end
		end
		if log
			nil # log
		end
	end
end