
class Aff < WorldObject
	
end
