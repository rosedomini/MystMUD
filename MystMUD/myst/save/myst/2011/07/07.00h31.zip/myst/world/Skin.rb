﻿
class Skin < WorldObject
	attr_reader :source
end