﻿
def a args = [1, 2]
	p args
end

a 5