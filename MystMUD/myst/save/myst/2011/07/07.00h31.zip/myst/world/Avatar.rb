﻿
class Avatar < WorldObject
	attr_reader :source
end
