﻿
class Race < WorldObject
	attr_reader :description, :skill_points, :spell_points, :skill, :spell, :power
end