﻿
class Array
	def delete_one value
		if i = index(value) then delete_at i end
	end
	
	def echo *args
		s = String.echo *args
		each{|x| x.instance_variable_get(:@msg) << s if x.heroe?}
	end
	
	def no value
		x = clone
		if i = index(value) then x.delete_at i end
		x
	end
	
	def seek needle, count = nil, method = :name
		count = count ? count.to_i : 1
		needle = needle.downcase
		find{|x| x.send(method).downcase.index needle and (count -= 1).zero? }
	end
	
	def named needle, count = nil
		count = count ? count.to_i : 1
		needle = needle.downcase.strip
		find{|x| x.name.downcase.index needle and (count-=1).zero?}
	end
	
	def to_h
		a = {}
		size.times{|i| a[i] = at(i)}
		a
	end
	
	def wiz sth, color=nil; each{|x| x.wiz sth, color} end
end

class FalseClass
	def to_str;'0' end
end

class Hash	
	def << value
		self[(max or [0])[0]+1] = value
	end
	
	def | h
		r = clone
		h.each do |key, value|
			if r[key] then r[key] += value else r[key] = value
		end end
		r
	end
	
	def echo *args
		s = String.echo *args
		each_value{|x| x.instance_variable_get(:@msg) << s if x.heroe?}
	end
	
	def new_id; (max or [0])[0]+1 end
	
	def no value
		x = clone
		if k = key(value) then x.delete k end
		x
	end
	
	def seek_key needle, count = nil, method = :name
		count = count ? count.to_i : 1
		needle = needle.downcase.strip
		each_key{|x| return x if x.send(method).downcase.index needle and (count -= 1).zero? }
		nil
	end
	
	def seek_value needle, count = nil, method = :name
		count = count ? count.to_i : 1
		needle = needle.downcase.strip
		each_value{|x| return x if x.send(method).downcase.index needle and (count -= 1).zero? }
		nil
	end
	
	def value_named needle, count = nil
		count = count ? count.to_i : 1
		needle = needle.downcase.strip
		each_value{|x| return x if x.name.downcase.index needle and (count-=1).zero?}
		nil
	end
	
	def key_named needle, count = nil
		count = count ? count.to_i : 1
		needle = needle.downcase.strip
		each_key do |x|
			if x.name.downcase.index needle and (count-=1).zero?
				$value = self[x]
				return x
		end end
		nil
	end
	
	def wiz sth, color=nil
		sth = "<font color=\"#{color}\">#{sth}</font>"
		each_value{|x| x.wiz sth}
	end
end

class NilClass
	def [] x; end
	def destroyed?; true end
end

class Object
	def destroyed?; @destroyed end
	def destroy; @destroyed = true end
end

class String	
	def link cmd; "<a href=\"javascript:p('#{cmd}')\">#{self}</a>" end
	
	def apos letter = 'e'
		if self =~ /^[aeiouy]/
			'\'' << self
		else
			letter << ' ' << self
		end
	end
	
	def contains s; downcase.index s.downcase end
	
	def String.echo name, *args
		s = ''
		if args.empty?
			s << "\0\0" << ExtCmd[name]
		else
			params = ''
			args.each do |arg|
				params << [arg.bytesize].pack('n').force_encoding($utf8) << arg.force_encoding($utf8)
			end
			s << [params.bytesize].pack('n').force_encoding($utf8) << ExtCmd[name] << params
		end
	end
	
	def escape; CGI.escapeHTML self end
	def starts_with? s; s == self[0, s.length] end
	def same b; downcase == b.downcase end
	def to_b; self == '1' end
end

class Symbol
	def starts_with? s; s == to_s[0, s.length] end
end

class TrueClass
	def to_str; '1' end
end
