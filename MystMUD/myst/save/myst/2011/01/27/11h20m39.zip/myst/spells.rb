﻿
class Actor
	def cast_boule_de_feu success, power, target
		if success
			if target or (target = @target and can_reach? target)
				dmg = (power+4*@wis) /2
				
				wiz "Vous envoyez une boule de feu sur #{target.sb? self} ~ #{dmg} points."
				target.wiz "#{sb? target} vous envoie une boule de feu ~ #{dmg} points."
				target.kill self unless target.target
				
				@room.actors.each do |actor|
					if actor.room == @room and actor != self and actor != target
						actor.wiz "#{sb? actor} envoie une boule de feu sur #{target.sb? actor} ~ #{dmg} points."
					end
				end
					
				target.hurt dmg, self
			else
				wiz '<i>Vous n\'êtes pas en combat! Précisez la cible enemie.</i>', 'green'
				wiz 'Vous envoyez une boule de feu qui monte très haut dans le ciel.'
				each_close_heroe do |heroe|
					heroe.wiz "#{sb? heroe} envoie une boule de feu qui monte très haut dans le ciel."
			end end
		else
			wiz 'Vous provoquez des étincelles qui ne s\'embrasent pas.'
			each_close_heroe do |heroe|
				heroe.wiz "Des étincelles échappent des mains d#{sb?(heroe).apos}."
	end end end
	
	def cast_bouclier success, power, target = nil
		if success
			if target
				wiz "Vous agitez vos mains et un voile magique entoure #{target}."
				target.wiz "Un voile magique echappé des mains d#{sb?(target, nil).apos} vous entoure."
				each_close_heroe do |heroe|
					if heroe != target
						heroe.wiz "Un voile magique s'échappe des mains \
d#{sb?(heroe, nil).apos} et entoure #{target.sb? heroe, nil}."
					end
				end
				target.affect :bouclier, power, power /2
			else
				wiz 'Vous encerclez votre corps physique d\'un voile magique teinté de bleu.'
				each_close_heroe do |heroe|
					heroe.wiz "#{sb? heroe} s'entoure d'un voile magique teinté de bleu."
				end
				affect :bouclier, power, power /2
			end
		else
			wiz 'Un voile magique sort de vos mains et manque de vous étrangler.'
			each_close_heroe do |heroe|
				heroe.wiz "Un voile magique sort des mains d#{sb?(heroe).apos} et manque de l'étrangler."
	end end end
	
	def cast_soin success, power, target = nil
		if success
			if target
				wiz "Une énergie blanche émane de vos mains et \
	vous soignez #{target}. ~ #{power} points"

				target.wiz "Une énergie blanche émane des mains \
	d#{sb?(target, nil).apos} et vous soigne. ~ #{power} points"

				each_close_heroe do |heroe|
					if heroe != target
						heroe.wiz "Une énergie blanche émane des mains \
	#{@name} et soigne #{target.sb? heroe, nil}. ~ #{power} points"

				end end
				target.heal power
			else
				wiz "Vos plaies s'illuminent d'une lueur blanche et se referment. ~ #{power} points"
				each_close_heroe do |heroe|
					heroe.wiz "Les plaies d#{sb?(heroe, nil).apos} s'illuminent \
	d'une lueur blanche et se referment. ~ #{power} points"
				end
				heal power
			end
		else
			if target
				wiz "Une énergie blanche émane de vos mains \
et crépite dans l'air avant de disparaître."
			else
				wiz 'Vos plaies s\'adoucirent une court instant sans avoir eu le temps de guérir.'
			end
			each_close_heroe do |heroe|
				heroe.wiz "Une énergie blanche émane des mains \
d#{sb?(heroe, nil).apos} et crépite dans l'air avant de disparaître."
	end end end
end
