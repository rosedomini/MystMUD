

def tata
	p "tata"
	toto = ->{ p 'toto'}
	toto[]
end

tata
toto