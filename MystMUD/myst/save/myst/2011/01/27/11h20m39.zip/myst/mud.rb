
=begin

	Script principal

	Arguments :
		check_cmd pour vérifier la liste des commandes
		
=end

$utf8 = ''.force_encoding('UTF-8').encoding

GC.disable # Le nettoyage sera réactivé ponctuellement

trap 'SIGINT', ->{shutdown} # Ctrl+C appelle la méthode Kernel#shutdown

$actor			= {}
$avatar		= {}
$body			= {}
$book			= {}
$command	= {}
$data			= {}
$guest			= []
$heroe			= {}
$icon			= []
$item			= {}
$mob			= {}
$power			= {}
$race			= {}
$room			= {}
$shop			= {}
$skin			= {}
$spell			= {}
$system		= {}
$world			= {}
$area			= {}

require 'srv/settings'

require 'digest/md5'
require 'net/http'
require 'date'
require 'cgi'
require 'uri'
require 'socket'
include Socket::Constants

Time_start = Time.now.to_f

require 'world/Area'
require 'world/Avatar'
require 'world/Body'
require 'world/Item'
require 'world/Race'
require 'world/Room'
require 'world/Shop'
require 'world/Skin'
require 'world/Spell'
require 'world/Team'
require 'world/World'

require 'srv/Dat'
require 'srv/Dat.clone'
require 'srv/Dat.define'
require 'srv/Dat.load'
require 'srv/Dat.save'
require 'srv/Load'
require 'srv/Log'
require 'srv/Save'
require 'srv/Guest'
require 'srv/Task'

require Cache_dir

require 'cmd/action'
require 'cmd/admin'
require 'cmd/Command'
require 'srv/globals'
require 'cmd/communication'
require 'cmd/divers'
require 'cmd/divers_a'
require 'cmd/gestion'
require 'cmd/gestion_a'
require 'cmd/olc'
require 'cmd/check'
require 'cmd/check_admin'

require 'func/Error'
require 'func/Fight'
require 'func/Kernel'
require 'func/lists'
require 'func/modifications'
require 'func/Power'
require 'func/System'
require 'func/time'

require 'proc/power'

require 'actor/Actor'
require 'actor/Heroe'
require 'actor/Mob'
require 'actor/Fist'

require 'spells'

Dat.define
Load.world

check_cmd if ARGV[0] == 'check_cmd'

flood_time= 0
$lastsave	= 0
time			= 0

$guest << $srv = $server = TCPServer.new(Hostname, Port)

puts "Server started at #{Hostname}:#{Port}"
		
task_time = Time.now.to_f

loop do
	if task_time + 0.1 < now = Time.now.to_f
		Task.execute(task_time = now)
	end
	
	next unless ready = select($guest, nil, nil, 0.2)
	
	now = Time.now.to_f
	
	for sock in ready[0]
		if sock == $server
			begin
				sock = $server.accept #_nonblock
				sock.write "#{Server_policy}\0#{Server_MOTD}"
				sock.init_guest
				$guest << sock
				puts 'Client joined'
			rescue
				puts "#{__FILE__}:#{__LINE__} #{$!.inspect}"
			end
		elsif sock.off then sock.eject
		elsif (arg = sock.read_nonblock 2048).length == 2048
			sock.eject 'N\'envoyez pas de commandes aussi longues !'
		else
			begin
				arg = CGI.escapeHTML arg.force_encoding($utf8).strip
			rescue; next end
			
			# next if arg == '&lt;policy-file-request/&gt;'
			
			if flood_time <= now
				flood_time = now + 1
				$guest.each{|x| x.flood = 0 }
			end
			
			if (sock.flood += 1) > FloodLimit
				sock.eject 'Flood interdit'
				next
			end
			
			sock.__send__ sock.control, arg
			
			send_all
			
			puts "Executed #{arg} in #{(1000000*(Time.now.to_f - now)).round}us"
		end
	end
end
