﻿
class Dat
	attr_reader :name, :hash, :class, :table, :data
	
	def initialize name, hash, klass, table = nil
		@name = name
		@class = klass
		@table = table ? table : name
		@hash = hash
		@data = []
		@queries = []
	end
	
	def add priority, name, type, &check_proc
		@data << ({
			:priority=>priority,
			:name=>name,
			:type=>type,
			:check_proc=>check_proc,
		})
	end
	
	def after_load
		print "#{@name}, "
		
		hash.each_value do |object|
			object.after_load if object.respond_to? :after_load
	end end
	
	def copy_from object
		new_object = object.clone
		@data.each do |var|
			name = "@#{var[:name]}"
			new_value = Dat.clone var[:type], object.instance_variable_get(name)
			new_object.instance_variable_set name, new_value
		end
		new_object
	end
	
	def from_olc object, var, value
		var = var.to_sym
		if data = @data.find{|x| x[:name] == var}
			value = eval value unless data[:type] == 'String'
			Dat.load data[:type], value, true
		else
			raise "Error@#{__FILE__}:#{__LINE__}\n\tObject: #{object.inspect}\n\tVariable: #{var}\n\tValue: #{value}"
	end end
	
	def load priority
		print "#{@name}, "
		@data.each do |var|
			next if var[:priority] != priority
			name = "@#{var[:name]}"
			type = var[:type]
			check_proc = var[:check_proc]
			@hash.each_value do |x|
				$x = x
				value = Dat.load(type, x.instance_variable_get(name))
				check_proc.call value if check_proc
				x.instance_variable_set name, value
		end end
	end
	
	def make to_add
		to_add.each do |var_data| add var_data
	end end
	
	def pre_load
		file = File.open "#{Data_path}/#{@class}.rb", 'a+'
		file.set_encoding 'UTF-8'
		data = file.read
		file.close
		data.insert 0, '['
		data << ']'
		list = eval data
		data.clear
		list.each do |values|
			# exeptions: $system and $command sort by name
			if @name == :System or @name == :Command
				id = values[:@name]
			else
				id = values[:@id]
			end
			
			object = @hash[id] = @class.new(id)
			
			values.each do |name, value|
				object.instance_variable_set name, value
	end end end
	
	def save
		print "#{@name}, "
		data = ''
	
		@hash.each do |id, object|
			data << "##{@class} #{object.instance_variable_get :@id}\n{\n"
		
			@data.each do |var|
				name = "@#{var[:name]}"
				type = var[:type]
				value = object.instance_variable_get name
				data << "\t:#{name} => #{Dat.save(type, value).inspect},\n"
			end
			
			# Ajout d'un champs
				# if @class == Item
					# data << "\t:@implantation => \"% est posé là\",\n"
				# end
			
			
			data.chop
			data << "},\n\n"
		end
		
		return "#{Data_path}/#{@class}.rb", data
	end
	
	def to_olc var, value
		if data = @data.find{|x| x[:name] == var}
			value = Dat.save(data[:type], value, true)
			return data[:type] == 'String' ? value.to_s : value.inspect, data[:type]
		end
		"Error: #{__FILE__}:#{__LINE__}"
	end
end
