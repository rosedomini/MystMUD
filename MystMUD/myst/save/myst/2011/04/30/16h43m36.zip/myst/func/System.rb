﻿
class System
	attr_reader :id, :name, :value
	attr_writer :value
	
	def initialize id; @id = id end
end
