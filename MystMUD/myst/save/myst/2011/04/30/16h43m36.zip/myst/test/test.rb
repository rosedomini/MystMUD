﻿
matières = {
	'Languages et automates CC' => [1.5, 10, 11, 12, 0],
	'Languages et automates ET' => [1.5, 7, 10, 14, 1],
	'Programmation système CC' => [1.5, 7, 10, 15, 1],
	'Programmation système ET' => [1.5, 7, 11, 14, 0],
	'Intégration ET' => [6, 4, 9, 13, 0],
	'Algèbre bilinéaire ET' => [6, 8, 14, 18.5, 2],
	'Types Abstraits CC' => [3, 13, 13, 13, 2],
	'Types Abstraits ET' => [3, 7, 11, 15, 1],
	'Anglais' => [3, 15, 15, 15, 2],
	'Sport' => [3, 14, 14, 14, 2]
}

note = 0.0

matières.each do |matière, tableau|
	# note += tableau[1]*tableau[0]
	# note += tableau[2]*tableau[0]
	# note += tableau[3]*tableau[0]
	note += tableau[tableau[4]+1]*tableau[0]
end

puts note/30.0