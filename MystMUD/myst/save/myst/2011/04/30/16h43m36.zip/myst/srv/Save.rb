﻿
class Save
	@@dir = ''
	
	def self.world
		now = Time.now.to_f
		
		return if now - $lastsave < 2 
		
		$lastsave = now
		puts "\t__Recuperation des donnees de l'ancien monde__"
		
		begin Save.createBackup
		rescue
			Error.display
			puts "Erreur lors de la creation du backup. Sauvegarde annulee. Nouvel essai dans 3 minutes."
			if $task then $task.repeat = 180 end
			return
		end
		
		puts "\t__Sauvegarde de l'instance actuelle du monde__"
		
		begin
			$system['world_time'].value = wtime
			
			classes = [:Area, :Body, :Heroe, :Item, :Mob, :Room, :Shop, :Spell, :System, :World]
			
			files_content = {}
			classes.each{|klass| files_content.store *$data[klass].save}
			
			print "\n\t\tEcriture des donnees"
			
			files_content.each do |file_path, data|
				file = File.open file_path, 'w+'
				file.set_encoding 'UTF-8'
				file.write data
				file.close
				data.clear
			end
			files_content.clear
			
		rescue
			Error.display
			puts "Sauvegarde echouee. Nouvel essai dans 3 minutes. (#{$query})"
			if $task then $task.repeat = 180 end
			return
		end
		
		print "\n* Termine en #{((Time.now.to_f - now) * 1000).round}ms\n\n"
		
		$actor.each_value do |actor|
			if actor.immortal?
				actor.wiz "Vous voyez le temps se figer un instant \
avant de reprendre son cours normal.", 'red'
		end end
		
		if $task then $task.repeat = 1200 end
	end

	def self.createBackup
		my = Date::ABBR_MONTHNAMES[Date.today.mon]+Date.today.year.to_s[2..4]
		unless File.exists?(dir = "#{Backup_path}/#{my}") then Dir.mkdir(dir) end
		unless File.exists?(dir << "/#{Date.today.day}") then Dir.mkdir(dir) end
		tn = "#{(t = Time.now).hour}h#{t.min}m#{t.sec}"
		Dir.mkdir @@dir = "#{dir}/#{tn}"
		dir = Dir.open Data_path
		dir.each do |filename|
			if filename =~ /\.rb$/
				File.open "#{@@dir}/#{filename}", 'w+' do |new_file|
					new_file.set_encoding 'UTF-8'
					File.open "#{Data_path}/#{filename}" do |file|
						file.set_encoding 'UTF-8'
						new_file.write file.read
					end
				end
			end
		end
		dir.close
	end
	
	def self.restoreBackup
		return if @@dir.empty?
		begin
			dir = Dir.open @@dir
			dir.each do |filename|
				if filename =~ /\.rb$/
					File.open "#{Data_path}/#{filename}", 'w+' do |new_file|
						new_file.set_encoding 'UTF-8'
						File.open "#{@@dir}/#{filename}" do |file|
							file.set_encoding 'UTF-8'
							new_file.write file.read
						end
					end
				end
			end
			dir.close
		rescue
			Error.display
			puts 'Echec de la restauration du backup\n'
		end
	end
end
