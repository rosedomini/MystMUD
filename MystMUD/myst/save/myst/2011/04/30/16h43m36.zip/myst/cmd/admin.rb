﻿
class Heroe < Actor
	def cmd_help command
		if command = $command[command]
			wiz "<font color=\"orange\">Syntaxe: </font>#{command.syntax}<br> ¤ #{command.help}"
		else
			s = '<br><u>Commandes des immortels :</u><br><br><table style="width:80%;border:none"><tr>'
			i = 0
			$command.each do |name, command|
				next if command.authlevel.zero?
				i += 1
				s << '</tr><tr>' if (i%4).zero?
				s << "<td width=\"25%\"><a href=\"javascript:p('help #{name}')\">#{name}</a></td>"
			end
			echo :top_show, "#{s}</tr></table>"
		end
	end
	
	def rcreate direction
		x, y, z = @room.x, @room.y, @room.z
		
		direction = case direction
			when :n then y += 1; :nord
			when :s then y -= 1; :sud
			when :o then x -= 1; :ouest
			when :e then x += 1; :est
			when :h then z += 1; :haut
			when :b then z -= 1; :bas
		end
		
		if $w[x, y, z] then wiz 'Il existe déjà une salle à cet endroit.'
		else $w.create_room x, y, z end
		move direction
	end
	
	def redit show = nil
		if (show.nil? and @redit) or show == false
			@redit = false
			echo :top_clear
			return
		end
		
		s = "<p>\
<a href=\"javascript:top_clear();p('redit close')\">fermer</a>\
 - Créer une salle : \
 <a href=\"javascript:p('rcreate n')\">n</a>\
 <a href=\"javascript:p('rcreate s')\">s</a>\
 <a href=\"javascript:p('rcreate o')\">o</a>\
 <a href=\"javascript:p('rcreate e')\">e</a>\
 <a href=\"javascript:p('rcreate h')\">h</a>\
 <a href=\"javascript:p('rcreate b')\">b</a>\
 <a href=\"javascript:p('delete room #{@room.id}')\">supprimer</a>\
</p><p><font color=\"black\">room[#{@room.id}] :</b> #{@room}</font></p>\
<br><table style=\"width:100%;border:none\" class=\"default\"><tr>\
<td align=\"center\" width=\"100\"><b><font color=\"black\">Variable<br></font></b></td>\
<td width=\"100%\" align=\"center\"><b><font color=\"black\">Valeur<br></font></td>\
<td width=\"22\" align=\"center\"></td>\
<td align=center width=\"100\"><b><font color=\"black\">Type<br></font></b></td>"
		
		[:name, :desc, :exits, :items, :x, :y, :z].each do |var|
			v, type = $data[:Room].to_olc(var, @room.instance_variable_get("@#{var}"))
			rows = 1
			v_rows = v.split "\n"
			v_rows.each{ |row| rows += row.length / 68 }
			rows = 5 if var == :desc
			s << "</tr><tr>\
<td align=right>#{var}</td>\
<td><form><textarea rows=\"#{rows}\" id=\"olcv_#{var}\" cols=\"68\">#{v}</textarea></td>\
<td><input type=\"button\" value=\"OK\" onclick=\"p('set Room #{@room.id} #{var} '\
+replacen(el('olcv_#{var}').value))\"/></td>\
<td align=\"center\">#{type}</td>"
		end
		
		echo :top_show, "#{s}</tr></table>"
		@redit = true
	end
	
	def goto room = nil
		if room and room.is_a? Room
			@room >> self
			(@room = room) << self
			look_around
			redit if @redit
		else
			s = '<p>Aller à :</p><br>'
			
			room.each_value do |room|
				s << "<p>#{room.id} - <a href=\"javascript:p('goto #{room.id}')\">#{room}</a></p>"
			end
			
			echo :top_show, s
		end
	end

	def ruby script = nil
		if script
			begin
				begin
					eval script
					wiz 'Terminé'
				rescue SyntaxError
					wiz 'Syntax Error.'
				end
			rescue
				wiz "Exécution échouée : #{CGI.escapeHTML $!.to_s}"
			end
		else
			echo :top_show, "<u>Script multi lignes</u><br><br>\
<textarea id=\"ruby\" style=\"width:80%;height:200px\"></textarea><br>\
<a href=\"javascript:p('ruby '+nreplace(el('ruby').value))\">Exécuter</a>"
		end
	end
end