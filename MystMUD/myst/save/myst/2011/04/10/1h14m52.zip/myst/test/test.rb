﻿
def pretty_time s
	j = h = n = nil
	 if s >= 86400 then j = s/86400; s %= 86400 end
	 if s >= 3600 then h = s/3600; s %= 3600 end
	 if s >= 60 then m = s/60; s %= 60 end
	 "#{"#{j}j " if j}#{"#{h}h " if h}#{"#{m}min " if m}#{s}s"
end

p pretty_time 0
p pretty_time 10
p pretty_time 60
p pretty_time 119
p pretty_time 3600
p pretty_time 7777
p pretty_time 86400