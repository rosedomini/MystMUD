﻿
class << Load
	undef books, icons, set_cmd_globals, system, tasks, world #, races
end
