print load_html "#{ROOT}/site/index.rhtml",
 'categories'=> Tree.describe($cgi['index'].split '|')